package com.ge.analytic.sentimate;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.analytic.dto.SentimentDTO;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.util.CoreMap;

@RestController
public class AnalyticService {

	@RequestMapping(value = "/getAnalyticResult/{sentimentString}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SentimentDTO> getAnalyticResultDetails(
			@PathVariable("sentimentString") String sentimentString) {
		
		final Logger LOGGER = Logger.getLogger(AnalyticService.class);

		List<SentimentDTO> resultList = new ArrayList<SentimentDTO>();
		SentimentDTO snmtntString = new SentimentDTO();

		StanfordCoreNLP pipeline;

		Properties props = new Properties();
		props.setProperty("annotators", "tokenize, ssplit, parse, sentiment");

		pipeline = new StanfordCoreNLP(props);
		float mainSentiment = 0;

		int longest = 0;
		Annotation annotation = pipeline.process(sentimentString);
		for (CoreMap sentence : annotation.get(CoreAnnotations.SentencesAnnotation.class)) {
			/*
			 * Tree tree = sentence
			 * .get(SentimentCoreAnnotations.AnnotatedTree.class);
			 */
			Tree tree = sentence.get(SentimentCoreAnnotations.SentimentAnnotatedTree.class);
			int sentiment = RNNCoreAnnotations.getPredictedClass(tree) - 2;
			LOGGER.info("Sentiment Result " + sentiment);
			String partText = sentence.toString();
			if (partText.length() > longest) {
				mainSentiment = sentiment;
				longest = partText.length();
			}

		}
		snmtntString.setAnalyticResult(mainSentiment);
		resultList.add(snmtntString);
		return resultList;
	}

}
