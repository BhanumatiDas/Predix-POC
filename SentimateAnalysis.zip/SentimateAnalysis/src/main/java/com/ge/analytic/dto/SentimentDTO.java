package com.ge.analytic.dto;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SentimentDTO {
	
	private float analyticResult;

	public float getAnalyticResult() {
		return analyticResult;
	}

	public void setAnalyticResult(float analyticResult) {
		this.analyticResult = analyticResult;
	}
	
	

}
