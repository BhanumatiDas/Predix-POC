package com.app.struts.form;

import org.apache.struts.action.ActionForm;

/**
 * Form bean class for search user form.
 * 
 * @author Bhanumati
 * 
 */
public class SearchForm extends ActionForm {

	private static final long serialVersionUID = 7352021000623040587L;
	private String email;
	private String salon;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSalon() {
		return salon;
	}

	public void setSalon(String salon) {
		this.salon = salon;
	}

}
