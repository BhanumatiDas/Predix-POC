package com.app.struts.form;

import org.apache.struts.action.ActionForm;

/**
 * Form bean class for SALON table.
 * 
 * @author Bhanumati
 * 
 */
public class SalonForm extends ActionForm {
	private static final long serialVersionUID = 7352021000623040587L;
	private int salonId;
	private String salonName;

	public int getSalonId() {
		return salonId;
	}

	public void setSalonId(int salonId) {
		this.salonId = salonId;
	}

	public String getSalonName() {
		return salonName;
	}

	public void setSalonName(String salonName) {
		this.salonName = salonName;
	}

}
