package com.app.struts.form;

import org.apache.struts.action.ActionForm;

/**
 * Form bean class for user form.
 * 
 * @author Bhanumati
 * 
 */
public class AddUserForm extends ActionForm {

	private static final long serialVersionUID = 7352021000623040587L;
	private String userName;
	private String gender;
	private String salon;
	private String dob;
	private String email;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSalon() {
		return salon;
	}

	public void setSalon(String salon) {
		this.salon = salon;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
