package com.app.struts.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.app.struts.dao.SalonDao;
import com.app.struts.form.SalonForm;
/**
 * Action class to get all the records from SALON table..
 * 
 * @author Bhanumati
 * 
 */
public class SalonAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		System.out.println("******* Inside Salon Action ************");
		HttpSession session = request.getSession(true);
		List<SalonForm> salonList = new ArrayList<SalonForm>();
		SalonDao dao = new SalonDao();
		salonList = dao.getSalonList();
		System.out.println("No Of Salons : " + salonList.size());

		session.setAttribute("salonList", salonList);

		return mapping.findForward("success");

	}
}
