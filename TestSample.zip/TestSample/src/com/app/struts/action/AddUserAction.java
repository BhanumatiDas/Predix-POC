package com.app.struts.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.app.struts.dao.AddUserDao;
import com.app.struts.form.AddUserForm;

/**
 * Action class to add a user in USER_DETAILS table.
 * 
 * @author Bhanumati
 * 
 */
public class AddUserAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		System.out.println("******* Inside AddUser Action ************");
		HttpSession session = request.getSession(true);
		List<AddUserForm> userList = new ArrayList<AddUserForm>();
		AddUserForm registerForm = (AddUserForm) form;
		String name = registerForm.getUserName();
		String gender = registerForm.getGender();
		String salon = registerForm.getSalon();
		String dateOfBirth = registerForm.getDob();
		String email = registerForm.getEmail();
		System.out.println("Name : " + name + "\nGender : " + gender
				+ "\nSalon Name : " + salon + "\nDate Of Birth : "
				+ dateOfBirth + "\nEmail : " + email);
		AddUserDao dao = new AddUserDao();
		userList = dao.checkUser(name, email);
		if (userList.size() > 0) {
			System.out.println("User already exist.");
			request.setAttribute("userExistResult", 1);
			session.setAttribute("result", 0);
			return mapping.findForward("success");
		} else {
			int result = dao
					.insertData(name, gender, salon, dateOfBirth, email);

			session.setAttribute("result", result);
			session.setAttribute("userExistResult", 0);

			return mapping.findForward("success");
		}

	}

}
