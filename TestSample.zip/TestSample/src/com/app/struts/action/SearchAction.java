package com.app.struts.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.app.struts.dao.SearchDao;
import com.app.struts.form.AddUserForm;
import com.app.struts.form.SearchForm;

/**
 * Action class to search user details in USER_DETAILS table.
 * 
 * @author Bhanumati
 * 
 */
public class SearchAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		System.out.println("******* Inside Search Action ************");
		HttpSession session = request.getSession(true);
		List<AddUserForm> userList = new ArrayList<AddUserForm>();
		SearchForm searchUser = (SearchForm) form;
		String salon = searchUser.getSalon().trim();
		String email = searchUser.getEmail().trim();
		System.out.println("Email : " + email + "\nSalon : " + salon);
		SearchDao dao = new SearchDao();
		userList = dao.searchUser(email, salon);
		session.setAttribute("userListSize", userList.size());
		session.setAttribute("userList", userList);

		return mapping.findForward("success");

	}

}
