package com.app.struts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.app.struts.form.AddUserForm;

/**
 * Database access class to make a connection with database and search user
 * details in USER_DETAILS table.
 * 
 * @author Bhanumati
 * 
 */
public class SearchDao {

	public List<AddUserForm> searchUser(String email, String salon)
			throws Exception {
		System.out
				.println("************** Insidr Search Dao to search the user ******************");
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/mysql", "root", "root");
		ResultSet rs = null;
		List<AddUserForm> userList = new ArrayList<AddUserForm>();
		try {

			try {
				Statement st = con.createStatement();

				String sqlQuery = "SELECT u.NAME,u.GENDER,u.DATE_OF_BIRTH,u.EMAIL,s.SALON_NAME from USER_DETAILS u, SALON s where s.SALON_ID=u.SALON_ID and ";
				if (!(email.isEmpty()) && !(salon.isEmpty())) {
					sqlQuery = sqlQuery + "u.EMAIL='" + email
							+ "' and u.SALON_ID=" + salon;
				} else {
					if (!(email.isEmpty())) {
						sqlQuery = sqlQuery + "u.EMAIL='" + email + "'";
					}
					if (!(salon.isEmpty())) {
						sqlQuery = sqlQuery + "u.SALON_ID=" + salon;
					}
				}
				System.out.println("QUERY : " + sqlQuery);
				rs = st.executeQuery(sqlQuery);
				while (rs.next()) {
					final AddUserForm user = new AddUserForm();
					user.setUserName(rs.getString("NAME"));
					user.setGender(rs.getString("GENDER"));
					user.setSalon(rs.getString("SALON_NAME"));
					user.setDob(rs.getString("DATE_OF_BIRTH"));
					user.setEmail(rs.getString("EMAIL"));
					userList.add(user);
				}

			} catch (SQLException ex) {
				System.out.println("SQL statement is not executed!" + ex);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userList;
	}

}
