package com.app.struts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.app.struts.form.SalonForm;

/**
 * Database access class to make a connection to database and get all the
 * records from SALON table.
 * 
 * @author Bhanumati
 * 
 */
public class SalonDao {
	public List<SalonForm> getSalonList() throws Exception {
		System.out
				.println("***************** Inside Salon dao to get all the records *****************");
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/mysql", "root", "root");
		ResultSet rs = null;
		List<SalonForm> salonList = new ArrayList<SalonForm>();
		try {

			try {
				Statement st = con.createStatement();
				String sqlQuery = "SELECT * FROM SALON";
				rs = st.executeQuery(sqlQuery);
				while (rs.next()) {
					final SalonForm salon = new SalonForm();
					salon.setSalonId(rs.getInt("SALON_ID"));
					salon.setSalonName(rs.getString("SALON_NAME"));

					salonList.add(salon);
				}

			} catch (SQLException ex) {
				System.out.println("SQL statement is not executed!" + ex);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return salonList;
	}

}
