package com.app.struts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.app.struts.form.AddUserForm;

/**
 * Database access class to make a connection to database and insert a record in
 * USER_DETAILS table.
 * 
 * @author Bhanumati
 * 
 */
public class AddUserDao {

	public int insertData(String name, String gender, String salon,
			String dateOfBirth, String email) throws Exception {
		System.out
				.println("************ Inside Adduser Dao  to insert a record *******************");
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/mysql", "root", "root");
		int result = 0;
		try {

			try {
				Statement st = con.createStatement();
				result = st
						.executeUpdate("INSERT INTO USER_DETAILS(NAME,GENDER,SALON_ID,DATE_OF_BIRTH,EMAIL) "
								+ "VALUES('"
								+ name
								+ "','"
								+ gender
								+ "','"
								+ salon
								+ "','"
								+ dateOfBirth
								+ "','"
								+ email
								+ "')");
				System.out.println("1 row affected : " + result);
			} catch (SQLException ex) {
				System.out.println("SQL statement is not executed!" + ex);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public List<AddUserForm> checkUser(String name, String email)
			throws Exception {
		System.out
				.println("*****************Inside Adduser Dao to ckeck user exist *******************");
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/mysql", "root", "root");
		List<AddUserForm> userList = new ArrayList<AddUserForm>();
		ResultSet rs = null;
		try {

			try {
				String query = "SELECT * FROM USER_DETAILS WHERE NAME='" + name
						+ "' and email='" + email + "'";
				Statement st = con.createStatement();
				System.out.println("exist query : " + query);
				rs = st.executeQuery(query);
				while (rs.next()) {
					final AddUserForm user = new AddUserForm();
					user.setUserName(rs.getString("NAME"));
					user.setGender(rs.getString("GENDER"));
					user.setSalon(rs.getString("SALON_ID"));
					user.setDob(rs.getString("DATE_OF_BIRTH"));
					user.setEmail(rs.getString("EMAIL"));
					userList.add(user);
				}
			} catch (SQLException ex) {
				System.out.println("SQL statement is not executed!" + ex);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userList;
	}

}
