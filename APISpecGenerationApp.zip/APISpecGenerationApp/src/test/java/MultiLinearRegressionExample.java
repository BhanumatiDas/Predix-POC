
/*

July 2006. Annie Che <chea@stat.ucla.edu>. UCLA Statistics.

Source of example data: 
An Introduction to Computational Statitics by Robert I Jennrich,
Page 5, example of regression on students' midterm and final scores.

*/

import java.util.HashMap;
import edu.ucla.stat.SOCR.analyses.data.Data;
import edu.ucla.stat.SOCR.analyses.data.DataType;
import edu.ucla.stat.SOCR.analyses.result.MultiLinearRegressionResult;


public class MultiLinearRegressionExample {
	public static void main(String args[]) {
		double[] x1 = 
                         {68,49,60,68,97,82,59,50,73,39,71,95,61,72,87,40,66,58,58,77};
		double[] x2 = 
                         {60,94,91,81,80,92,74,89,96,87,86,94,94,94,79,50,92,82,94,78};
		
		double[] y = {75,63,57,88,88,79,82,73,90,62,70,96,76,75,85,40,74,70,75,72};

		// you'll need to instantiate a data instance first.
		Data data = new Data();

		/*********************************************************************
		then put the data into the Data Object.
		append the predictor data using method "addPredictor".
		append the response data using method "addResponse".
		**********************************************************************/
		data.addPredictor("var 1", x1, DataType.QUANTITATIVE);
		data.addPredictor("var 2", x2, DataType.QUANTITATIVE);
		data.addResponse("var y", y, DataType.QUANTITATIVE);

		try {
			MultiLinearRegressionResult result = data.modelMultiLinearRegression();
			if (result != null) {

				// Getting the model's parameter estiamtes and statistics.
				String[] varList = result.getVariableList();
				double[] beta = result.getBeta();
				double[] seBeta =result.getBetaSE();
				double[] tStat = result.getBetaTStat();
				String[] pValue = result.getBetaPValue();
				int dfError = result.getDF();

				double[] predicted = result.getPredicted();
				double[] residuals = result.getResiduals();

				// residuals after being sorted ascendantly.
				double[] sortedResiduals = result.getSortedResiduals();

				// sortedResiduals after being standardized.
				double[] sortedStandardizedResiduals = 
                                         result.getSortedStandardizedResiduals();

				// the original index of sortedResiduals, stored as integer array.
				int[] sortedResidualsIndex = result.getSortedResidualsIndex();

				// the normal quantiles of sortedResiduals.
				double[] sortedNormalQuantiles = result.getSortedNormalQuantiles();

				// sortedNormalQuantiles after being standardized.
				double[] sortedStandardizedNormalQuantiles = 
                                         result.getSortedStandardizedNormalQuantiles();

				System.out.println("dfError = " + dfError);

				for (int i = 0; i < varList.length; i++) {
					System.out.println("varList["+i+"] = " + varList[i]);
				}
				for (int i = 0; i < beta.length; i++) {
					System.out.println("beta["+i+"] = " + beta[i]);
				}
				for (int i = 0; i < residuals.length; i++) {
					System.out.println("residuals["+i+"] = " + residuals[i]);
				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}