/**
 * A sample bean class
 */
package com.geaviation.api.bean;

public class SampleBean {

	/**
	 * Holds sample name
	 */
	private String name;

	/**
	 * Holds sample short name
	 */
	private String shortName;

	/**
	 * Holds description
	 */
	private String description;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "SampleBean [name=" + name + ", shortName=" + shortName + ", description=" + description + "]";
	}

}
