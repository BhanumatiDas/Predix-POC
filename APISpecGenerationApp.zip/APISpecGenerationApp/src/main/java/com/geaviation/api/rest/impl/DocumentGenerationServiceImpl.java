package com.geaviation.api.rest.impl;

import javax.jws.WebService;
import javax.ws.rs.Path;

import com.geaviation.api.bean.SampleBean;
import com.geaviation.api.rest.DocumentGenerationService;

/**
 * This is the implementation class for DocumentGenerationService interface
 * 
 * @author BD470389
 *
 */
@WebService(endpointInterface = "com.geaviation.api.rest.DocumentGenerationService")
@Path("/sampleServiceApi")
public class DocumentGenerationServiceImpl implements DocumentGenerationService {

	public SampleBean createSample() {
		SampleBean sample = new SampleBean();

		// ... store the sample details in the db...

		return sample;

	}

	public SampleBean updateSample(SampleBean editedSample) {
		SampleBean newSample = new SampleBean();

		// ... update the sample details in the db...

		return newSample;

	}

	public void deleteSample(int sampleId) {

		// ... delete sample details from db ...

	}

}
