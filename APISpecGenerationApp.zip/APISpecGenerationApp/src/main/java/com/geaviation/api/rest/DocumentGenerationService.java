package com.geaviation.api.rest;

import javax.jws.WebService;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import com.geaviation.api.bean.SampleBean;

/**
 * This service is used to perform actions on the data associated with the
 * sample.
 * 
 * @author BD470389
 *
 */
@WebService
public interface DocumentGenerationService {

	/**
	 * This service is used to create a new sample.
	 * 
	 * @return return created Sample details
	 */
	@Path("/create")
	@GET
	public SampleBean createSample();

	/**
	 * This service is to update the existing Sample details.
	 * 
	 * @param editedSample
	 *            -- Holds the edited Sample details.
	 * 
	 * @return return updated sample details
	 */
	@Path("/update")
	@GET
	public SampleBean updateSample(SampleBean editedSample);

	/**
	 * This service is used to delete a Sample with the given id.
	 * 
	 * @param sampleId
	 *            -- Holds deleted sample id
	 */
	@Path("/{id}")
	@POST
	public void deleteSample(int sampleId);
}
