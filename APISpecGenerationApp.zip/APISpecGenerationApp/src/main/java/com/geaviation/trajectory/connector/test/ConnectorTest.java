package com.geaviation.trajectory.connector.test;

import com.geaviation.trajectory.connector.TrajectoryConnector;
import com.geaviation.trajectory.connector.bean.MicroserviceBean;
import com.geaviation.trajectory.connector.bean.MicrosvcRuntimeInfo;
import com.geaviation.trajectory.connector.bean.MicrosvcSwaggerSpec;

/**
 * A test class to test the Trajectory Connector REST API's.
 * 
 * @author BD470389
 *
 */
public class ConnectorTest {

	public static void main(String args[]) {
		//callAddMicroservice();
		// callAddPayLoad();
		// callAddRuntime();
		callUpdateMicroservice();
	}

	/**
	 * Method to test add microservice REST api.
	 */
	public static void callAddMicroservice() {
		MicrosvcSwaggerSpec swaggerSpec = new MicrosvcSwaggerSpec();
		MicroserviceBean microserviceBean = new MicroserviceBean();
		microserviceBean.setSwaggerSpec(swaggerSpec);
		microserviceBean.setMicroserviceName("ConnectorTestService28thFeb");
		microserviceBean.setMicroserviceShortName("CTS28");
		microserviceBean.setTagName("");
		microserviceBean.setContextName("DevTestContext");
		microserviceBean.setDomainName("DevTestDomain");
		microserviceBean.setDocumentationUrl("");
		microserviceBean.setOwner("");
		microserviceBean.setProject("");
		microserviceBean.setDescription("Creating microservice from Trajectory Connector");
		microserviceBean.setApproval("APR");
		microserviceBean.getSwaggerSpec().setUrl("");
		microserviceBean.getSwaggerSpec().setAutoSync("");
		microserviceBean.getSwaggerSpec().setAutoSyncValue("");
		microserviceBean.getSwaggerSpec().setSecurity("");
		microserviceBean.getSwaggerSpec().setBuild("");
		microserviceBean.setApiKey("RGFhUyw1MDIzMTI1MTIsRGFzLlR1c2hhckBnZS5jb20sREFTLFRVU0hBUg==");
		TrajectoryConnector.addMicroService(microserviceBean);
	}

	/**
	 * Method to test update microservice REST api.
	 */
	public static void callUpdateMicroservice() {
		MicrosvcSwaggerSpec swaggerSpec = new MicrosvcSwaggerSpec();
		MicroserviceBean microserviceBean = new MicroserviceBean();
		microserviceBean.setSwaggerSpec(swaggerSpec);
		microserviceBean.setMicroserviceName("Core Customer API-Edited");
		microserviceBean.setMicroserviceShortName("CUST");
		microserviceBean.setMicroserviceNewName("");
		microserviceBean.setTagName("");
		microserviceBean.setContextName("TestContext27thFeb");
		microserviceBean.setDomainName("DomainForRESTServiceTest");
		microserviceBean.setDocumentationUrl("https://www.google.com");
		microserviceBean.setOwner("BHANUMATI");
		microserviceBean.setProject("");
		microserviceBean.setDescription("updating microservice from Trajectory Connector");
		microserviceBean.setApproval("APR");
		microserviceBean.getSwaggerSpec()
				.setUrl("https://dev-dds.api.aviation.ge.com/services/data/core/customers/swagger");
		microserviceBean.getSwaggerSpec().setAutoSync("");
		microserviceBean.getSwaggerSpec().setAutoSyncValue("");
		microserviceBean.getSwaggerSpec().setSecurity("");
		microserviceBean.getSwaggerSpec().setBuild("");
		microserviceBean.setApiKey("RGFhUyw1MDIzMTI1MTIsRGFzLlR1c2hhckBnZS5jb20sREFTLFRVU0hBUg==");
		TrajectoryConnector.updateMicroService(microserviceBean);
	}

	/**
	 * Method to test add payload REST api.
	 */
	public static void callAddPayLoad() {
		MicrosvcSwaggerSpec microsvcSwaggerSpec = new MicrosvcSwaggerSpec();
		microsvcSwaggerSpec.setUrl("https://dev-dds.api.aviation.ge.com/services/data/core/events/swagger ");
		microsvcSwaggerSpec.setPayload("");
		microsvcSwaggerSpec.setAutoSync("true");
		microsvcSwaggerSpec.setAutoSyncValue("daily");
		microsvcSwaggerSpec.setSecurity("");
		microsvcSwaggerSpec.setBuild("");
		microsvcSwaggerSpec
				.setApiKey("TXlUZXN0Q29udGV4dCw1MDI2NDk4ODYsRGFzLkJoYW51bWF0aUBnZS5jb20sREFTLEJIQU5VTUFUSQ==");
		TrajectoryConnector.addPayload(microsvcSwaggerSpec);
	}

	/**
	 * Method to test add runtime information REST api.
	 */
	public static void callAddRuntime() {
		MicrosvcRuntimeInfo microsvcRunTimeInfo = new MicrosvcRuntimeInfo();
		microsvcRunTimeInfo.setEnvName("QA");
		microsvcRunTimeInfo.setNoOfInstances(10);
		microsvcRunTimeInfo.setDomainName("TestDomain23Jan");
		microsvcRunTimeInfo.setBaseUrl("");
		microsvcRunTimeInfo.setAvgHitPerDay(20);
		microsvcRunTimeInfo.setPerformance(5.7);
		microsvcRunTimeInfo.setAvailabilty(4.0);
		microsvcRunTimeInfo
				.setApiKey("TXlUZXN0Q29udGV4dCw1MDI2NDk4ODYsRGFzLkJoYW51bWF0aUBnZS5jb20sREFTLEJIQU5VTUFUSQ==");
		TrajectoryConnector.addRunTime(microsvcRunTimeInfo);
	}

}
