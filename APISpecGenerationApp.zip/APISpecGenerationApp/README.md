# Reference app to demonestrate Swagger spec API generation & to test the Trajectory Connector REST API's


Sample application to demonstrate API spec generation in java and to test the Trajectory Connector REST API's

STEPS TO GENERTAE THE SWAGGER SPEC API:

- Use the below command in command prompt to generate the document.
mvn clean install enunciate:docs -Denvironment=local -DskipTests=true -T 8 -Dmaven.artifact.threads=50

STEPS TO TEST TRAJECTORY CONNECTOR REST API's
- Keep trajectory.connector-0.0.1.jar and application.properties file in src/main/resources folder
- Add the required dependencies in pom.xml file
- Run ConnectorTest class to test the REST API's
- IN DEV & QA it'll throw SSL certificate error as we are not handling that exception in DEV & QA.

