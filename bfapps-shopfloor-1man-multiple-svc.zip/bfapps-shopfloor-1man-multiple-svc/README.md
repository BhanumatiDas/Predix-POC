Aviation Brilliant Facotry Shop Floor One Man Multiple Projects Micro Service.

How to compile and run
======================
1. Run "gradlew clean distZip" to compile and generate distribution
2. Distribution is available in build/distributions
4. to deploy to CF simply push the Zip distribution using "cf push" , you need to provide a manifest file
