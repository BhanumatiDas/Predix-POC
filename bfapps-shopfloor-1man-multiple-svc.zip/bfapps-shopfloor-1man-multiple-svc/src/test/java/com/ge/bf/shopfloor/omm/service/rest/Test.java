/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public final class Test {

  public static void main(String[] args) {
    String dateFormat = "yyyyMMdd";
    SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
    Calendar c1 = Calendar.getInstance(); // today
    System.out.println("Today is " + sdf.format(c1.getTime()));
  }

  private Test() {

  }

}
