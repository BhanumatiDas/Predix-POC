/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest;

import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;

public final class HalUtils {
  private HalUtils() {
  }

  /**
   * This method takes in parameter a regular HAL templated url, a map
   * containing all the expected parameters and their values. It builds a final
   * url by removing the parameters that were not provided from the template url
   * and setting the values of the ones that are present.
   *
   * @param templatedUrl
   * @param parameters
   * @return
   */
  public static String buildTemplatedUrl(String templatedUrl, Map<String, String> parameters) {
    String[] urlParts = StringUtils.split(templatedUrl, "{?");
    String finalUrl = urlParts[0];

    if (urlParts.length > 1) {
      String requestParams = urlParts[1];
      requestParams = StringUtils.remove(requestParams, "}");
      StringBuilder finalRequestParams = new StringBuilder();
      StringTokenizer tokenizer = new StringTokenizer(requestParams, ",");

      while (tokenizer.hasMoreTokens()) {
        String paramName = tokenizer.nextToken().trim();
        String paramValue = parameters.get(paramName);
        if (StringUtils.isNotEmpty(paramValue)) {
          finalRequestParams.append(paramName).append('=').append(paramValue).append('&');
        }
      }
      if (finalRequestParams.length() > 0) {
        finalRequestParams.deleteCharAt(finalRequestParams.length() - 1).insert(0, '?').insert(0, urlParts[0]);
      }
      finalUrl = finalRequestParams.toString();
    }
    return finalUrl;
  }
}
