/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class ServiceControllerTest extends TemplateControllerTest {
  @Test
  @Ignore("not implemented")
  public void testGetService() throws Exception {
    //    mockMvc.perform(get("/v1/")).andExpect(status().isOk())
    //        .andExpect(content().contentType(new MediaType("application", "hal+json")))
    //        .andExpect(jsonPath("$._links.fake_data.href", endsWith("fake_data")));
  }
}
