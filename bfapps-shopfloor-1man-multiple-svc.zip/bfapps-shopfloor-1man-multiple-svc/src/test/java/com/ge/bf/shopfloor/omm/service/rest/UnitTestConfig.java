/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest;

import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.sql.DataSource;

import org.flywaydb.core.Flyway;
import org.h2.server.web.WebServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.mock.env.MockEnvironment;
import org.springframework.orm.jpa.JpaTransactionManager;

import com.ge.bf.shopfloor.omm.service.OneManMultipleApplication;
import com.ge.bf.shopfloor.omm.service.TenantContextProvider;
import com.ge.bf.shopfloor.omm.service.exception.InvalidScopeException;

@SpringApplicationConfiguration
@ComponentScan(basePackages = { "com.ge.bf.shopfloor.omm.service" }, excludeFilters = {
    @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = OneManMultipleApplication.class),
    @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = TenantContextProvider.class),
    @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = Environment.class) })
@Configuration
@EnableAutoConfiguration
// @EntityScan(basePackages = "com.ge.bf.shopfloor.omm.service.entities")
@EnableJpaRepositories(basePackages = "com.ge.bf.shopfloor.omm.service.repository")
@Profile("unittest")
public class UnitTestConfig {
  private static final String SCOPE = "sample.scope";

  @Bean
  public ServletRegistrationBean h2servletRegistration() {
    ServletRegistrationBean registration = new ServletRegistrationBean(new WebServlet());
    registration.addUrlMappings("/console/*");
    return registration;
  }


  @Bean(initMethod = "migrate")
  Flyway flyway() {
    Flyway flyway = new Flyway();
    flyway.setSchemas("SHOPFLOOR");
    flyway.setBaselineOnMigrate(true);
    flyway.setLocations("classpath:db");
    flyway.setDataSource(dataSource());
    return flyway;
  }


  @Bean(destroyMethod = "shutdown")
  public DataSource dataSource() {
    return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.H2).build();
  }

  @Bean
  @Autowired
  public EntityManager entityManager(EntityManagerFactory entityManagerFactory) {
    return entityManagerFactory.createEntityManager();
  }

  @Bean
  @DependsOn("flyway")
  public EntityManagerFactory entityManagerFactory() {
    Properties jpaProps = new Properties();
    jpaProps.put("openjpa.ConnectionFactory", dataSource());
    jpaProps.put("openjpa.Log", "log4j");
    jpaProps.put("openjpa.ConnectionFactoryProperties", "true");
    return Persistence.createEntityManagerFactory("OMMPersistenceUnit", jpaProps);
  }

  @Bean
  public Environment environment() {
    return new MockEnvironment().withProperty("scope", SCOPE);
  }


  @Bean
  public TenantContextProvider tenantContextProvider() throws InvalidScopeException {
    TenantContextProvider tenantContextProvider = spy(TenantContextProvider.class);
    when(tenantContextProvider.getTenantId()).thenReturn("1");

    List<String> scope = new ArrayList<>();
    scope.add(SCOPE);
    when(tenantContextProvider.getTokenScope()).thenReturn(scope);

    return tenantContextProvider;
  }

  @Bean
  @Autowired
  public JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
    JpaTransactionManager txManager = new JpaTransactionManager();
    txManager.setEntityManagerFactory(entityManagerFactory);

    return txManager;
  }
}
