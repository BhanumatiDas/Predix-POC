/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.ge.bf.shopfloor.omm.service.rest.UnitTestConfig;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@WebAppConfiguration
@ContextConfiguration(classes = { UnitTestConfig.class })
@ActiveProfiles(profiles = { "unittest" })
public class TemplateControllerTest {
  @Autowired
  private WebApplicationContext webApplicationContext;

  @Autowired
  private Environment environment;

  protected MockMvc mockMvc;

  public WebApplicationContext getWebApplicationContext() {
    return webApplicationContext;
  }

  public void setWebApplicationContext(WebApplicationContext webApplicationContext) {
    this.webApplicationContext = webApplicationContext;
  }

  public Environment getEnvironment() {
    return environment;
  }

  public void setEnvironment(Environment environment) {
    this.environment = environment;
  }

  public MockMvc getMockMvc() {
    return mockMvc;
  }

  public void setMockMvc(MockMvc mockMvc) {
    this.mockMvc = mockMvc;
  }

  @Before
  public void setUp() throws Exception {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
  }
}
