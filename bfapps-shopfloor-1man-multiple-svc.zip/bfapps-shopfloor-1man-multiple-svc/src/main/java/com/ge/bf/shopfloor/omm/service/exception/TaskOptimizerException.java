/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

public class TaskOptimizerException extends OneManMultipleServiceException {
  public TaskOptimizerException(String message) {
    super(message);
  }

  public TaskOptimizerException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public TaskOptimizerException(Throwable throwable) {
    super(throwable);
  }
}
