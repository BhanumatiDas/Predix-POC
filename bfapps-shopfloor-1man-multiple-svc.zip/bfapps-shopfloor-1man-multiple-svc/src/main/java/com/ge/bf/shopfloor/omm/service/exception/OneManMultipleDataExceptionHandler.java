/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.ge.bf.shopfloor.omm.service.rest.resources.ErrorResourceOutput;
import com.ge.bf.shopfloor.omm.service.rest.util.ExceptionUtils;

@ControllerAdvice
public class OneManMultipleDataExceptionHandler extends ResponseEntityExceptionHandler {

  private static final Logger LOGGER = LoggerFactory.getLogger(OneManMultipleDataExceptionHandler.class);

  /**
   * Handler for generic exception.
   *
   * @param exception
   * @return
   */
  @ExceptionHandler(value = Exception.class)
  @ResponseBody
  public ResponseEntity<ErrorResourceOutput> handleException(Exception exception) {
    LOGGER.info("Handling Exception");
    return handleExceptionInternal(exception, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * Single place to customize the response body of all Exception types.
   *
   * @param exception
   * @return
   */
  public ResponseEntity<ErrorResourceOutput> handleExceptionInternal(Exception exception, HttpStatus httpStatus) {
    ExceptionUtils exceptionUtils = new ExceptionUtils();

    // Log the exception
    exceptionUtils.logException(exception);

    // Set the error message in the object
    ErrorResourceOutput errorResourceOutput = exceptionUtils.setErrorObject(exception.getMessage(), httpStatus);

    // Get the status code from request
    HttpStatus status = exceptionUtils.getStatus(httpStatus);
    return new ResponseEntity<ErrorResourceOutput>(errorResourceOutput, status);
  }

  /**
   * Handler for WorkGroupDataServiceException.
   *
   * @param exception
   * @return
   */
  @ExceptionHandler(value = MachineDataServiceException.class)
  @ResponseBody
  public ResponseEntity<ErrorResourceOutput> handleFakeDataServiceException(MachineDataServiceException exception) {
    LOGGER.info("Handling WorkGroupDataServiceException");
    return handleExceptionInternal(exception, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * Handler for WorkGroupDataServiceException.
   *
   * @param exception
   * @return
   */
  @ExceptionHandler(value = WorkGroupDataServiceException.class)
  @ResponseBody
  public ResponseEntity<ErrorResourceOutput> handleFakeDataServiceException(WorkGroupDataServiceException exception) {
    LOGGER.info("Handling WorkGroupDataServiceException");
    return handleExceptionInternal(exception, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @ExceptionHandler(value = MissingTenantIdException.class)
  @ResponseBody
  public ResponseEntity<ErrorResourceOutput> handleMissingTenantIdException(MissingTenantIdException exception) {
    LOGGER.info("Handling MissingTenantIdException");
    return handleExceptionInternal(exception, HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(value = PartDataNotFoundException.class)
  @ResponseBody
  public ResponseEntity<ErrorResourceOutput> handlePartNotFoundException(PartDataNotFoundException exception) {
    LOGGER.info("Handling PartDataNotFoundException");
    return handleExceptionInternal(exception, HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(value = WorkGroupDataNotFoundException.class)
  @ResponseBody
  public ResponseEntity<ErrorResourceOutput> handleWorkOrderNotFoundException(
      WorkGroupDataNotFoundException exception) {
    LOGGER.info("Handling WorkGroupDataNotFoundException");
    return handleExceptionInternal(exception, HttpStatus.NOT_FOUND);
  }

}
