/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.ITaskDataService;
import com.ge.bf.shopfloor.omm.service.entity.Task;
import com.ge.bf.shopfloor.omm.service.exception.DataFormatException;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.TaskDataServiceException;
import com.ge.bf.shopfloor.omm.service.util.IOneManMultipleConstants;

/**
 * @author 221032148
 *
 */
@Component
@SuppressWarnings({ "nls", "unused" })
public class TaskDataInitialization extends AbstractDataInitialization {
  private static final Logger LOG = LoggerFactory.getLogger(TaskDataInitialization.class);
  private static final int OPERATION_CODE = 0;
  private static final int TASK_CODE = 1;
  private static final int TASK_SEQUENCE = 2;
  private static final int TASK_DESC = 3;
  private static final int MANUAL_TIME = 4;
  private static final int AUTO_TIME = 5;
  private static final int TRAVEL_TIME = 6;
  private static final int FLAG = 7;

  @Autowired
  private ITaskDataService iTaskDataService;

  @Override
  protected String saveData(Map<String, String[][]> content) throws DataFormatException, TaskDataServiceException {
    String[][] taskData = content.get(IOneManMultipleConstants.TASK_DATA);
    Task data = null;
    List<Task> taskDataSet = new ArrayList<Task>(10);
    String msg = null;
    msg = "Zero records exists in the Task Data Worksheet";
    if (taskData == null) {
      return msg;
    }
    for (String[] row : taskData) {
      Task task = iTaskDataService.getTaskByCode(row[TASK_CODE]);
      data = (task != null) ? task : new Task();

      if ((row[OPERATION_CODE] == null) || (row[OPERATION_CODE].trim().length() == 0)) {
        throw new TaskDataServiceException(ErrorMessage.NO_OPERATION_CODE);
      } else {
        if (row[OPERATION_CODE].matches("[0-9.]*")) {
          data.setOperationCode(String.valueOf(Float.valueOf(row[OPERATION_CODE]).intValue()));
        } else {
          data.setOperationCode(row[OPERATION_CODE]);
        }
      }

      if ((row[TASK_SEQUENCE] == null) || (row[TASK_SEQUENCE].trim().length() == 0)) {
        throw new TaskDataServiceException(ErrorMessage.NO_TASK_SEQUENCE);
      } else {
        if (row[TASK_SEQUENCE].matches("[0-9.]*")) {
          data.setTaskSequence(String.valueOf(Float.valueOf(row[TASK_SEQUENCE]).intValue()));
        } else {
          data.setTaskSequence(row[TASK_SEQUENCE]);
        }
      }

      if ((row[TASK_CODE] == null) || (row[TASK_CODE].trim().length() == 0)) {
        throw new TaskDataServiceException(ErrorMessage.NO_TASK_CODE);
      } else {
        if (row[TASK_CODE].matches("[0-9.]*")) {
          data.setTaskCode(String.valueOf(Float.valueOf(row[TASK_CODE]).intValue()));
        } else {
          data.setTaskCode(row[TASK_CODE]);
        }

      }
      data.setTaskDesc(row[TASK_DESC]);
      data.setManualTime(
          Double.valueOf((row[MANUAL_TIME] == null || row[MANUAL_TIME].trim().length() == 0) ? "0.0" : row[MANUAL_TIME])
          .doubleValue());
      data.setAutoTime(
          Double.valueOf((row[AUTO_TIME] == null || row[AUTO_TIME].trim().length() == 0) ? "0.0" : row[AUTO_TIME])
          .doubleValue());
      data.setTravelTime(
          Double.valueOf((row[TRAVEL_TIME] == null || row[TRAVEL_TIME].trim().length() == 0) ? "0.0" : row[TRAVEL_TIME])
          .doubleValue());
      data.setFlag((row[FLAG] == null || row[FLAG].trim().length() == 0) ? "N" : row[FLAG]);
      taskDataSet.add(data);
    }

    if (!taskDataSet.isEmpty()) {
      msg = taskDataSet.size() + " records exists in the Task Data Worksheet";
      LOG.info(msg);
      iTaskDataService.createTaskData(taskDataSet);
    }
    return msg;
  }
}
