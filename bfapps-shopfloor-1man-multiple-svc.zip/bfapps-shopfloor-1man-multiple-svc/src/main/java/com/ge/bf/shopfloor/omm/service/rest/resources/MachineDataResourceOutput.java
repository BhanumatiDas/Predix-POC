/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.resources;

import java.sql.Timestamp;

import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.core.Relation;

import com.fasterxml.jackson.annotation.JsonInclude;

@Relation(collectionRelation = "machineData")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MachineDataResourceOutput extends ResourceSupport {
  private String machineCode;
  private String machineDesc;
  private String machineColor;
  private String workgroupCode;
  private String plantCode;
  private String partNumber;
  private String createdBy;
  private String updatedBy;
  private Timestamp createdDate;
  private Timestamp updatedDate;

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (!super.equals(obj)) {
      return false;
    }
    if (!(obj instanceof MachineDataResourceOutput)) {
      return false;
    }
    MachineDataResourceOutput other = (MachineDataResourceOutput)obj;
    if (machineCode == null) {
      if (other.machineCode != null) {
        return false;
      }
    } else if (!machineCode.equals(other.machineCode)) {
      return false;
    }
    return true;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public Timestamp getCreatedDate() {
    return (Timestamp)createdDate.clone();
  }

  public String getMachineCode() {
    return machineCode;
  }

  public String getMachineColor() {
    return machineColor;
  }

  public String getMachineDesc() {
    return machineDesc;
  }

  public String getPartNumber() {
    return partNumber;
  }

  public String getPlantCode() {
    return plantCode;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public Timestamp getUpdatedDate() {
    return (Timestamp)updatedDate.clone();
  }

  public String getWorkgroupCode() {
    return workgroupCode;
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ((machineCode == null) ? 0 : machineCode.hashCode());
    return result;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = (Timestamp)createdDate.clone();
  }

  public void setMachineCode(String machineCode) {
    this.machineCode = machineCode;
  }

  public void setMachineColor(String machineColor) {
    this.machineColor = machineColor;
  }

  public void setMachineDesc(String machineDesc) {
    this.machineDesc = machineDesc;
  }

  public void setPartNumber(String partNumber) {
    this.partNumber = partNumber;
  }

  public void setPlantCode(String plantCode) {
    this.plantCode = plantCode;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public void setUpdatedDate(Timestamp updatedDate) {
    this.updatedDate = (Timestamp)updatedDate.clone();
  }

  public void setWorkgroupCode(String workgroupCode) {
    this.workgroupCode = workgroupCode;
  }

}
