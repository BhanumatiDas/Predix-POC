/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.assembler;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

import com.ge.bf.shopfloor.omm.service.entity.Operation;
import com.ge.bf.shopfloor.omm.service.rest.controller.OperationDataController;
import com.ge.bf.shopfloor.omm.service.rest.resources.OperationDataResourceOutput;

/**
 * 
 * @author BD470389
 *
 */
public class OperationDataResourceAssembler extends ResourceAssemblerSupport<Operation, OperationDataResourceOutput> {

  public OperationDataResourceAssembler() {
    super(OperationDataController.class, OperationDataResourceOutput.class);
  }

  @Override
  public OperationDataResourceOutput toResource(Operation operation) {

    OperationDataResourceOutput resource;

    resource = createResourceWithId("id/" + operation.getId(), operation);

    BeanUtils.copyProperties(operation, resource);
    return resource;
  }

}
