/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IMachineDataService;
import com.ge.bf.shopfloor.omm.service.IPartDataService;
import com.ge.bf.shopfloor.omm.service.IWorkGroupDataService;
import com.ge.bf.shopfloor.omm.service.entity.MachineData;
import com.ge.bf.shopfloor.omm.service.exception.DataFormatException;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.MachineDataServiceException;
import com.ge.bf.shopfloor.omm.service.exception.OneManMultipleServiceException;
import com.ge.bf.shopfloor.omm.service.util.IOneManMultipleConstants;

/**
 * @author 221032148
 *
 */
@Component
@SuppressWarnings({ "nls", "unused" })
public class MachineDataInitialization extends AbstractDataInitialization {
  private static final Logger LOGGER = LoggerFactory.getLogger(MachineDataInitialization.class);
  private static final int MACHINE_CODE = 0;
  private static final int MACHINE_DESC = 1;
  private static final int MACHINE_COLOR = 2;
  private static final int WORKGROUP_CODE = 3;
  private static final int PART_CODE = 4;
  private static final int PLANT_CODE = 5;

  @Autowired
  private IMachineDataService iMachineDataService;

  @Autowired
  private IPartDataService iPartDataService;

  @Autowired
  private IWorkGroupDataService iWorkGroupDataService;

  @Override
  protected String saveData(Map<String, String[][]> content)
      throws DataFormatException, MachineDataServiceException, OneManMultipleServiceException {
    String[][] machineData = content.get(IOneManMultipleConstants.MACHINE_DATA);
    MachineData data = null;
    List<MachineData> machineDataSet = new ArrayList<MachineData>(10);
    String msg = "Zero records exists in the Machine Data Worksheet";
    if (machineData == null) {
      return msg;
    }

    for (String[] row : machineData) {
      // check for existing record with same machine code
      List<MachineData> machine = iMachineDataService.getMachineDataByCode(row[MACHINE_CODE]);
      data = (machine != null && !machine.isEmpty()) ? machine.get(0) : new MachineData();
      // check if PLANT_CODE, PART_NUMBER and WORK_GROUP exists, otherwise throw
      // an error.
      // validate WORKGROUP_CODE, PART_CODE and PLAT_CODE
      if ((row[MACHINE_CODE] == null) || (row[MACHINE_CODE].trim().length() == 0)) {
        throw new MachineDataServiceException(ErrorMessage.NO_MACHINE_CODE);
      } else {
        if (row[MACHINE_CODE].matches("[0-9.]*")) {
          data.setMachineCode(String.valueOf(Float.valueOf(row[MACHINE_CODE]).intValue()));
        } else {
          data.setMachineCode(row[MACHINE_CODE]);
        }
      }
      LOGGER.debug("Machine Code" + row[MACHINE_CODE]);

      data.setMachineDesc(row[MACHINE_DESC]);
      data.setMachineColor(row[MACHINE_COLOR]);

      // workgroup code validation
      if ((row[WORKGROUP_CODE] == null) || (row[WORKGROUP_CODE].trim().length() == 0)) {
        throw new MachineDataServiceException(ErrorMessage.NO_WORKGROUP_CODE);
      } else {
        // check the workgroup is valid
        // TODO iWorkGroupDataService.
        String workGroupCode = (row[WORKGROUP_CODE].matches("[0-9.]*"))
            ? (String.valueOf(Float.valueOf(row[WORKGROUP_CODE]).intValue())) : row[WORKGROUP_CODE];

            if (iWorkGroupDataService.getWorkGroupDataByCode(workGroupCode) == null) {
              throw new MachineDataServiceException(ErrorMessage.NONEXISTANT_WORKGROUPDATA);
            } else {
              data.setWorkgroupCode(workGroupCode);
            }
      }
      LOGGER.debug("WorkGroup Code" + row[WORKGROUP_CODE]);
      // part number validation
      if ((row[PART_CODE] == null) || (row[PART_CODE].trim().length() == 0)) {
        throw new MachineDataServiceException(ErrorMessage.NO_PART_CODE);
      } else {
        String partCode = (row[PART_CODE].matches("[0-9.]*"))
            ? (String.valueOf(Float.valueOf(row[PART_CODE]).intValue())) : row[PART_CODE];
            // check PART code is valid
            LOGGER.debug("Part Code " + partCode);
            if (iPartDataService.getPartDataByCode(partCode) == null) {
              throw new MachineDataServiceException(ErrorMessage.NO_PART_CODE);
            } else {
              data.setPartCode(partCode);
            }
      }

      // plant code validation
      if ((row[PLANT_CODE] == null) || (row[PLANT_CODE].trim().length() == 0)) {
        throw new MachineDataServiceException(ErrorMessage.NO_PLANT_CODE);
      } else {
        String plantCode = (row[PLANT_CODE].matches("[0-9.]*"))
            ? (String.valueOf(Float.valueOf(row[PLANT_CODE]).intValue())) : row[PLANT_CODE];
            // TODO
            // check PART code is valid
            /*
             * if (iPartDataService.getPartDataByCode(partCode) == null) { throw new
             * MachineDataServiceException(ErrorMessage.NO_PART_CODE); } else {
             * data.setPartCode(row[PLANT_CODE]); }
             */

            data.setPlantCode(plantCode);
      }

      machineDataSet.add(data);
    }

    if (!machineDataSet.isEmpty()) {
      msg = machineDataSet.size() + " records exists in the Machine Data Worksheet";
      LOGGER.info(msg);
      iMachineDataService.createMachineData(machineDataSet);
    }
    return msg;
  }
}
