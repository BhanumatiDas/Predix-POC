/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

/**
 * 
 * @author BD470389
 *
 */
public class ScheduleDataServiceException extends OneManMultipleServiceException {

  public ScheduleDataServiceException(String message) {
    super(message);
  }

  public ScheduleDataServiceException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public ScheduleDataServiceException(Throwable throwable) {
    super(throwable);
  }

}
