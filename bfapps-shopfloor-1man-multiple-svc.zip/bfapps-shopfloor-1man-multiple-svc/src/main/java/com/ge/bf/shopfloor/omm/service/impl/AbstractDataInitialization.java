/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.exception.DataFormatException;
import com.ge.bf.shopfloor.omm.service.exception.OneManMultipleServiceException;

/**
 * @author 221032148
 *
 */
@Component
public abstract class AbstractDataInitialization {

  /**
   * 
   * @param content
   * @throws DataFormatException
   * @throws OneManMultipleServiceException
   */
  protected abstract String saveData(Map<String, String[][]> content)
      throws DataFormatException, OneManMultipleServiceException;
}
