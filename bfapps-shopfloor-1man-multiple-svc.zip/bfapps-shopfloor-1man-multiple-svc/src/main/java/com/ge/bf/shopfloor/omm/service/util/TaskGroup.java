/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;

import com.ge.bf.shopfloor.omm.service.entity.Task;

/**
 * @author 221032148
 *
 */
public class TaskGroup {
  /**
   * Creates the Wait Task.
   *
   * @param waitTime
   * @return
   */
  public static TaskWrapper createWaitTask(double waitTime) {
    TaskWrapper waitTask = new TaskWrapper();
    waitTask.setManualTime(waitTime);
    waitTask.setOperationCode("W");
    waitTask.setTaskCode("W");
    waitTask.setTaskDesc("Wait");
    return waitTask;
  }

  private List<TaskWrapper> taskList;
  private double opsTotalTime;
  private double opsRemaningTime;
  private boolean isCompleted;

  private String opsCode;

  public TaskGroup() {
    taskList = new ArrayList<TaskWrapper>(10);
  }

  /**
   * Utility method to copy the Task to TaskWrapper.
   *
   * @param tasks
   * @return
   */
  public List<TaskWrapper> createTaskWrappers(List<Task> tasks) {

    if (tasks == null || tasks.isEmpty()) {
      return null;
    }
    List<TaskWrapper> tws = new ArrayList<TaskWrapper>(10);
    for (Task t : tasks) {
      TaskWrapper tw = new TaskWrapper();
      BeanUtils.copyProperties(t, tw);
      tw.setRemainingTime(0.0);
      tws.add(tw);
    }
    return tws;
  }

  /**
   * @return the opsTotalTime
   */
  /*
   * public double getOpsTotalTime() { if (this.taskList == null ||
   * this.taskList.isEmpty()) return 0.0; for (TaskWrapper task : taskList) {
   * opsRemaningTime += task.getTotalTime(); } return opsRemaningTime; }
   */

  /**
   * @return the opsCode
   */
  public String getOpsCode() {
    return opsCode;
  }

  /**
   * @return the opsRemaningTime
   */
  public double getOpsRemaningTime() {
    if (this.taskList == null || this.taskList.isEmpty()) {
      return 0.0;
    }
    opsRemaningTime = 0.0;
    for (TaskWrapper task : taskList) {
      if (!task.isTaskScheduled()) {
        opsRemaningTime += task.getTotalTime();
      }
    }
    return opsRemaningTime;
  }

  /**
   * @return the taskList
   */
  public List<TaskWrapper> getTaskList() {
    return taskList;
  }

  /**
   * @return the isCompleted
   */
  public boolean isCompleted() {
    return (getOpsRemaningTime() <= 0.0) ? true : false;
  }

  /**
   * Utility method to check the Operation is scheduled and still running.
   *
   * @return
   */

  public boolean isOperationRunning() {
    boolean flag = true;
    if (this.getTaskList() == null || this.getTaskList().isEmpty()) {
      return false;
    }

    for (TaskWrapper task : getTaskList()) {
      if (task.isTaskScheduled() && !task.isTaskCompleted()) {
        flag = true;
        break;
      } else {
        flag = false;
      }
    }
    return flag;
  }

  /**
   * @param opsCode
   *          the opsCode to set
   */
  public void setOpsCode(String opsCode) {
    this.opsCode = opsCode;
  }

  /**
   * @param taskList
   *          the taskList to set
   */
  public void setTaskList(List<TaskWrapper> taskList) {
    this.taskList = taskList;
  }
}
