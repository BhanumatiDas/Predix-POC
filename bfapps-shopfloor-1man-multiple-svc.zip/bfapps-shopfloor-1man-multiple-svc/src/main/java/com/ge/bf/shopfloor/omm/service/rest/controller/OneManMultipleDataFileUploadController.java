/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.ge.bf.shopfloor.omm.service.IOneManMultipleDataService;
import com.ge.bf.shopfloor.omm.service.TenantContextProvider;
import com.ge.bf.shopfloor.omm.service.exception.DataFormatException;
import com.ge.bf.shopfloor.omm.service.exception.MachineDataServiceException;
import com.ge.bf.shopfloor.omm.service.exception.OneManMultipleServiceException;

@Controller
public class OneManMultipleDataFileUploadController {

  private static final Logger LOGGER = LoggerFactory.getLogger(OneManMultipleDataFileUploadController.class);

  @Autowired
  private IOneManMultipleDataService iOneManMultipleDataService;

  @Autowired
  private TenantContextProvider tenantContextProvider;

  @SuppressWarnings("nls")
  private List<String> uploadDataFile(MultipartFile file) throws OneManMultipleServiceException {
    List<String> messages = new ArrayList<String>(5);
    if (!StringUtils.isNotEmpty(file.getOriginalFilename())) {
      throw new DataFormatException(
          "You failed to upload " + file.getOriginalFilename() + " because the file was empty.");
    }
    try {

      if (!file.getOriginalFilename().toLowerCase().endsWith("xls")
          && !file.getOriginalFilename().toLowerCase().endsWith("xlsx")) {
        String errorMsg = "You failed to upload " + file.getOriginalFilename()
        + " because the unsupported file format, currently supported files are Excel format.";
        throw new DataFormatException(errorMsg);
      }
      messages = iOneManMultipleDataService.uploadXlsData(file.getOriginalFilename(), file.getInputStream());
    } catch (IOException e) {
      String errorMsg = "You failed to upload file" + file.getOriginalFilename() + " due to IOException => " //$NON-NLS-1$ //$NON-NLS-2$
          + e.getMessage();
      LOGGER.error(errorMsg, e);
      throw new MachineDataServiceException(errorMsg, e);
    }
    return messages;
  }

  @SuppressWarnings("nls")
  @RequestMapping(value = "/omm/v1/uploadommdata", method = POST)
  @ResponseBody
  public List<String> uploadOneManMultipleData(@RequestParam(value = "file", required = true) MultipartFile file)
      throws OneManMultipleServiceException {

    // TO-DO Need to implement security check to see if the user is allowed to
    // upload a file.
    return uploadDataFile(file);
  }
}
