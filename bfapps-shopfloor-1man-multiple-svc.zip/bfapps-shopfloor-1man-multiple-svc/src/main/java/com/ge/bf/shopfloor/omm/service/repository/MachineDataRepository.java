/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ge.bf.shopfloor.omm.service.entity.MachineData;
import com.ge.bf.shopfloor.omm.service.exception.MachineDataServiceException;

public interface MachineDataRepository extends JpaRepository<MachineData, String> {
  MachineData findById(@Param("id") String id);

  @Query("SELECT md FROM MachineData md" + " WHERE md.machineCode = :machineCode")
  List<MachineData> getMachineDataByCode(@Param("machineCode") String machineCode) throws MachineDataServiceException;

  @Query("SELECT md FROM MachineData md" + " WHERE md.plantCode = :plantCode")
  List<MachineData> getMachineDataByPlant(@Param("plantCode") String plantCode) throws MachineDataServiceException;

  @Query("SELECT md FROM MachineData md" + " WHERE md.partCode = :partCode")
  List<MachineData> getMachineDataPartNumber(@Param("partCode") String partCode) throws MachineDataServiceException;

}
