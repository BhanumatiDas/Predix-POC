/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

public class MachineDataServiceException extends OneManMultipleServiceException {
  public MachineDataServiceException(String message) {
    super(message);
  }

  public MachineDataServiceException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public MachineDataServiceException(Throwable throwable) {
    super(throwable);
  }
}
