/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.assembler;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

import com.ge.bf.shopfloor.omm.service.entity.Task;
import com.ge.bf.shopfloor.omm.service.rest.controller.TaskDataController;
import com.ge.bf.shopfloor.omm.service.rest.resources.TaskDataResourceOutput;

/**
 * 
 * @author BD470389
 *
 */
public class TaskDataResourceAssembler extends ResourceAssemblerSupport<Task, TaskDataResourceOutput> {

  public TaskDataResourceAssembler() {
    super(TaskDataController.class, TaskDataResourceOutput.class);
  }

  @Override
  public TaskDataResourceOutput toResource(Task task) {

    TaskDataResourceOutput resource;

    resource = createResourceWithId("id/" + task.getId(), task);

    BeanUtils.copyProperties(task, resource);
    return resource;
  }

}
