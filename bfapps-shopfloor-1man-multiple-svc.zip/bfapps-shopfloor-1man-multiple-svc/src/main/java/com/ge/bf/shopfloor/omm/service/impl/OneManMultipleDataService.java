/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IOneManMultipleDataService;
import com.ge.bf.shopfloor.omm.service.exception.OneManMultipleServiceException;
import com.ge.bf.shopfloor.omm.service.util.IOneManMultipleConstants;
import com.ge.bf.shopfloor.omm.service.util.SpreadSheetParser;

/**
 * @author 221032148
 *
 */
@Component
public class OneManMultipleDataService implements IOneManMultipleDataService {

  @Autowired
  private MachineDataInitialization machineData;

  @Autowired
  private OperationDataInitialization operationData;

  @Autowired
  private TaskDataInitialization taskData;

  @Autowired
  private PartDataInitialization partData;

  @Autowired
  private WorkGroupDataInitialization workGroupData;

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.ge.bf.shopfloor.omm.service.IOneManMultipleDataService#uploadXlsData(
   * java.lang.String, java.io.InputStream)
   */
  @Override
  public List<String> uploadXlsData(String name, InputStream data) throws OneManMultipleServiceException {
    List<String> workSheets = new ArrayList<String>();
    workSheets.add(IOneManMultipleConstants.PART_DATA); // $NON-NLS-1$
    workSheets.add(IOneManMultipleConstants.WORKGROUP_DATA); // $NON-NLS-1$
    workSheets.add(IOneManMultipleConstants.MACHINE_DATA); // $NON-NLS-1$
    workSheets.add(IOneManMultipleConstants.OPERATION_DATA); // $NON-NLS-1$
    workSheets.add(IOneManMultipleConstants.TASK_DATA); // $NON-NLS-1$

    SpreadSheetParser parser = new SpreadSheetParser();
    Map<String, String[][]> content = parser.parseInputFile(data, workSheets);
    List<String> msg = new ArrayList<String>(5);
    // Order of the worksheet data to save.
    // 1.Save Plant, 2. Part 3. Work Group, 4. Machine, 5. Operation 6. Tasks
    // 2. save machine data

    // 1. save Plant data

    // 2. Save Part Data
    msg.add(partData.saveData(content));

    // 3. Save Work Group
    msg.add(workGroupData.saveData(content));

    // 4. Save Machine data
    msg.add(machineData.saveData(content));

    // 5. save operations data
    msg.add(operationData.saveData(content));

    // 6. save task data
    msg.add(taskData.saveData(content));

    msg.add("You have successfully uploaded " + name + "!");
    return msg;
  }

}
