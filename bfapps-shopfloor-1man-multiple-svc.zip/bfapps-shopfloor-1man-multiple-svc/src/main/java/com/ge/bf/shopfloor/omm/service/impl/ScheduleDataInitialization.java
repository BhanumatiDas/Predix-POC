/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IScheduleDataService;
import com.ge.bf.shopfloor.omm.service.entity.Schedule;
import com.ge.bf.shopfloor.omm.service.entity.ScheduleHistory;
import com.ge.bf.shopfloor.omm.service.exception.ScheduleDataServiceException;
import com.ge.bf.shopfloor.omm.service.util.IOneManMultipleConstants;
import com.ge.bf.shopfloor.omm.service.util.TaskWrapper;

/**
 *
 * @author BD470389
 *
 */
@Component
@SuppressWarnings({ "nls", "unused" })
public class ScheduleDataInitialization {

  private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleDataInitialization.class);

  @Autowired
  private IScheduleDataService iScheduleDataService;

  /**
   * This method will copy the schedule data into Schedule History.
   *
   * @param scheduleList
   * @return
   * @throws ScheduleDataServiceException
   */
  public List<ScheduleHistory> copyScheduleObject(List<Schedule> scheduleList) throws ScheduleDataServiceException {

    List<ScheduleHistory> scheduleHistroyList = new ArrayList<ScheduleHistory>();
    for (int i = 0; i < scheduleList.size(); i++) {
      ScheduleHistory scheduleHistory = new ScheduleHistory();
      scheduleHistory.setId(scheduleList.get(i).getId());
      scheduleHistory.setRunId(scheduleList.get(i).getRunId());
      scheduleHistory.setScheduleSequence(scheduleList.get(i).getScheduleSequence());
      scheduleHistory.setTaskCode(scheduleList.get(i).getTaskCode());
      scheduleHistory.setTaskSequence(scheduleList.get(i).getTaskSequence());
      scheduleHistory.setOperationCode(scheduleList.get(i).getOperationCode());
      scheduleHistory.setMachineCode(scheduleList.get(i).getMachineCode());
      scheduleHistory.setPartCode(scheduleList.get(i).getPartCode());
      scheduleHistory.setManualStartTime(scheduleList.get(i).getManualStartTime());
      scheduleHistory.setManualEndTime(scheduleList.get(i).getManualEndTime());
      scheduleHistory.setCompleteFlag(scheduleList.get(i).getCompleteFlag());
      scheduleHistory.setCreatedBy(scheduleList.get(i).getCreatedBy());
      scheduleHistory.setUpdatedBy(scheduleList.get(i).getUpdatedBy());
      scheduleHistory.setCreatedDate(scheduleList.get(i).getCreatedDate());
      scheduleHistory.setUpdatedDate(scheduleList.get(i).getUpdatedDate());

      scheduleHistroyList.add(scheduleHistory);
    }

    return scheduleHistroyList;

  }

  /**
   * Method to create the runId sequentially for SCHEDULE table.
   *
   * @return
   */
  public String createRunId(List<Schedule> scheduleList) throws ScheduleDataServiceException {
    String runId = null;
    String dateFormat = "yyyyMMdd";
    SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
    Calendar c1 = Calendar.getInstance(); // today
    // LOGGER.info("Today is " + sdf.format(c1.getTime()));
    if (scheduleList.size() > 0) {
      String latestRunId = scheduleList.get(scheduleList.size() - 1).getRunId();
      String latestRunIndex = latestRunId.substring(latestRunId.indexOf("R") + 1);
      runId = sdf.format(c1.getTime()) + "R" + (Integer.parseInt(latestRunIndex) + 1);
    } else {
      runId = sdf.format(c1.getTime()) + "R1";
    }
    return runId;
  }

  /**
   * This method is to initialize the Schedule Data.
   *
   * @param sequencedTasks
   * @param scheduleDataList
   * @return
   * @throws ScheduleDataServiceException
   */
  public List<Schedule> intializeScheduleDataSet(List<TaskWrapper> sequencedTasks, List<Schedule> scheduleDataList)
      throws ScheduleDataServiceException {
    List<Schedule> newScheduleList = new ArrayList<Schedule>(100);
    for (int i = 0; i < sequencedTasks.size(); i++) {
      Schedule data = new Schedule();
      data.setRunId(createRunId(scheduleDataList));
      data.setScheduleSequence(i + 1);
      data.setTaskCode(sequencedTasks.get(i).getTaskCode());
      data.setOperationCode(sequencedTasks.get(i).getOperationCode());
      data.setPartCode(sequencedTasks.get(i).getPartCode());
      data.setMachineCode(sequencedTasks.get(i).getMachineCode());
      if (sequencedTasks.get(i).getTaskCode().equalsIgnoreCase(IOneManMultipleConstants.WAIT_TASK)) {
        data.setTaskSequence("null");
      } else {
        data.setTaskSequence(sequencedTasks.get(i).getTaskSequence());
      }
      data.setCompleteFlag(IOneManMultipleConstants.SCHEDULE_INCOMPLETE);
      data.setManualStartTime(sequencedTasks.get(i).getManualStartTime());
      data.setManualEndTime(sequencedTasks.get(i).getManualEndTime());
      newScheduleList.add(data);
    }
    return newScheduleList;
  }

  /**
   * This method will reschedule the task list whose status is 'N'.
   *
   * @param scheduleListByStatus
   * @return
   * @throws ScheduleDataServiceException
   */
  public List<Schedule> rescheduleTaskList(List<Schedule> scheduleListByStatus) throws ScheduleDataServiceException {
    List<Schedule> reScheduleList = new ArrayList<Schedule>(100);
    for (int i = 0; i < scheduleListByStatus.size(); i++) {
      Schedule data = new Schedule();
      data.setRunId(scheduleListByStatus.get(i).getRunId());
      data.setScheduleSequence(i + 1);
      data.setTaskCode(scheduleListByStatus.get(i).getTaskCode());
      data.setOperationCode(scheduleListByStatus.get(i).getOperationCode());
      data.setPartCode(scheduleListByStatus.get(i).getPartCode());
      data.setMachineCode(scheduleListByStatus.get(i).getMachineCode());
      if (scheduleListByStatus.get(i).getTaskCode().equalsIgnoreCase(IOneManMultipleConstants.WAIT_TASK)) {
        data.setTaskSequence("null");
      } else {
        data.setTaskSequence(scheduleListByStatus.get(i).getTaskSequence());
      }
      data.setCompleteFlag(scheduleListByStatus.get(i).getCompleteFlag());
      data.setManualStartTime(scheduleListByStatus.get(i).getManualStartTime());
      data.setManualEndTime(scheduleListByStatus.get(i).getManualEndTime());
      reScheduleList.add(data);
    }
    return reScheduleList;
  }

  /**
   * This method is to save the task sequences in the Schedule table.
   *
   * @param sequencedTasks
   * @return
   * @throws ScheduleDataServiceException
   */
  public List<Schedule> saveSequencedTasks(List<TaskWrapper> sequencedTasks) throws ScheduleDataServiceException {
    List<Schedule> oldScheduleDataList = iScheduleDataService.getScheduleDataSet();
    List<Schedule> newScheduleList = null;
    List<Schedule> newList = null;
    if (oldScheduleDataList.size() > 0) {

      List<Schedule> scheduleListByStatus = iScheduleDataService
          .getScheduleByStatus(IOneManMultipleConstants.SCHEDULE_INCOMPLETE);
      if (scheduleListByStatus.size() > 0) {
        newScheduleList = rescheduleTaskList(scheduleListByStatus);
        iScheduleDataService.deleteScheduleDataSet(scheduleListByStatus);
      } else {
        List<ScheduleHistory> scheduleHistoryList = copyScheduleObject(oldScheduleDataList);
        iScheduleDataService.removeDataFromSchedule(oldScheduleDataList, scheduleHistoryList);
        newScheduleList = intializeScheduleDataSet(sequencedTasks, oldScheduleDataList);
      }
    } else {
      newScheduleList = intializeScheduleDataSet(sequencedTasks, oldScheduleDataList);
    }

    newList = iScheduleDataService.createScheduleData(newScheduleList);

    return newList;

  }

}
