/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IWorkGroupDataService;
import com.ge.bf.shopfloor.omm.service.entity.WorkGroupData;
import com.ge.bf.shopfloor.omm.service.exception.DataFormatException;
import com.ge.bf.shopfloor.omm.service.exception.WorkGroupDataServiceException;
import com.ge.bf.shopfloor.omm.service.util.IOneManMultipleConstants;

@Component
@SuppressWarnings({ "nls", "unused" })
public class WorkGroupDataInitialization extends AbstractDataInitialization {

  private static final Logger LOGGER = LoggerFactory.getLogger(MachineDataInitialization.class);
  private static final int WORKGROUP_ID = 0;
  private static final int WORKGROUP_CODE = 1;
  private static final int WORKGROUP_DESC = 2;
  private static final int ACTIVE_FLAG = 3;

  @Autowired
  private IWorkGroupDataService iWorkGroupDataService;

  @Override

  protected String saveData(Map<String, String[][]> content) throws DataFormatException, WorkGroupDataServiceException {
    String[][] workGroupData = content.get(IOneManMultipleConstants.WORKGROUP_DATA);
    WorkGroupData data = null;
    List<WorkGroupData> workGroupDataset = new ArrayList<WorkGroupData>(7);
    String msg = "Zero records exists in WorkGroupData Worksheet";
    if (workGroupData == null) {
      return msg;
    }

    for (String[] row : workGroupData) {
      List<WorkGroupData> workGroup = iWorkGroupDataService.getWorkGroupDataByCode(row[WORKGROUP_CODE]);
      data = (workGroup != null && !workGroup.isEmpty()) ? workGroup.get(0) : new WorkGroupData();
 //   data.setId(row[WORKGROUP_ID]);
      data.setWorkGroupCode(row[WORKGROUP_CODE]);
      data.setWorkGroupDesc(row[WORKGROUP_DESC]);
      data.setActiveFlag(row[ACTIVE_FLAG]);

      workGroupDataset.add(data);
    }

    if (!workGroupDataset.isEmpty()) {
      msg = workGroupDataset.size() + " records exists in the WorkGroup Data Worksheet";
      LOGGER.info(msg);
      iWorkGroupDataService.createWorkGroupData(workGroupDataset);
    }
    return msg;
  }

}
