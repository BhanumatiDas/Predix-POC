/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.entity;

import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.hateoas.Identifiable;

import com.ge.bf.shopfloor.omm.service.rest.util.ResourcesUtils;

/**
 * @author 221032148
 *
 */
@Entity
@Table(name = "operation", schema = "omm")
public class Operation implements Identifiable<String> {

  @Id
  @Column(name = "operation_id")
  private String id;
  @Column(name = "operation_code")
  private String operationCode;
  @Column(name = "operation_desc")
  private String operationDesc;
  @Column(name = "machine_code")
  private String machineCode;
  @Column(name = "created_by")
  private String createdBy;
  @Column(name = "updated_by")
  private String updatedBy;
  @Column(name = "created_date")
  private Timestamp createdDate;
  @Column(name = "updated_date")
  private Timestamp updatedDate;

  @Override
  public String getId() {
    return id;
  }

  @PrePersist
  void onCreate() {
    this.setId(UUID.randomUUID().toString());
    this.setCreatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setCreatedBy("internal");
  }

  @PreUpdate
  void onUpdate() {
    this.setUpdatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setUpdatedBy("internal");
  }

  /**
   * @return the operationCode
   */
  public String getOperationCode() {
    return operationCode;
  }

  /**
   * @param operationCode
   *          the operationCode to set
   */
  public void setOperationCode(String operationCode) {
    this.operationCode = operationCode;
  }

  /**
   * @return the operationDesc
   */
  public String getOperationDesc() {
    return operationDesc;
  }

  /**
   * @param operationDesc
   *          the operationDesc to set
   */
  public void setOperationDesc(String operationDesc) {
    this.operationDesc = operationDesc;
  }

  /**
   * @return the machineCode
   */
  public String getMachineCode() {
    return machineCode;
  }

  /**
   * @param machineCode
   *          the machineCode to set
   */
  public void setMachineCode(String machineCode) {
    this.machineCode = machineCode;
  }

  /**
   * @return the createdBy
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * @param createdBy
   *          the createdBy to set
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * @return the updatedBy
   */
  public String getUpdatedBy() {
    return updatedBy;
  }

  /**
   * @param updatedBy
   *          the updatedBy to set
   */
  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  /**
   * @return the createdDate
   */
  public Timestamp getCreatedDate() {
    return createdDate;
  }

  /**
   * @param createdDate
   *          the createdDate to set
   */
  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = createdDate;
  }

  /**
   * @return the updatedDate
   */
  public Timestamp getUpdatedDate() {
    return updatedDate;
  }

  /**
   * @param updatedDate
   *          the updatedDate to set
   */
  public void setUpdatedDate(Timestamp updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(String id) {
    this.id = id;
  }

}
