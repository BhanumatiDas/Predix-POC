/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.resources;

import java.sql.Timestamp;

import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.core.Relation;

import com.fasterxml.jackson.annotation.JsonInclude;

@Relation(collectionRelation = "workGroupData")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkGroupDataResourceOutput extends ResourceSupport {

  private String workGroupCode;
  private String workGroupDesc;
  private String activeFlag;
  private String createByUser;
  private Timestamp createByDate;
  private String updatedByUser;
  private Timestamp updatedByDate;

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!super.equals(o)) {
      return false;
    }
    if (!(o instanceof WorkGroupDataResourceOutput)) {
      return false;
    }
    WorkGroupDataResourceOutput other = (WorkGroupDataResourceOutput)o;
    if (workGroupCode == null) {
      if (other.workGroupCode != null) {
        return false;
      }
    } else if (!workGroupCode.equals(other.workGroupCode)) {
      return false;
    }
    return true;
  }

  public String getActiveFlag() {
    return activeFlag;
  }

  public Timestamp getCreateByDate() {
    return (Timestamp)createByDate.clone();
  }

  public String getCreateByUser() {
    return createByUser;
  }

  public Timestamp getUpdatedByDate() {
    return (Timestamp)updatedByDate.clone();
  }

  public String getUpdatedByUser() {
    return updatedByUser;
  }

  public String getWorkGroupCode() {
    return workGroupCode;
  }

  public String getWorkGroupDesc() {
    return workGroupDesc;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ((workGroupCode == null) ? 0 : workGroupCode.hashCode());
    return result;
  }

  public void setActiveFlag(String activeFlag) {
    this.activeFlag = activeFlag;
  }

  public void setCreateByDate(Timestamp createByDate) {
    this.createByDate = (Timestamp)createByDate.clone();
  }

  public void setCreateByUser(String createByUser) {
    this.createByUser = createByUser;
  }

  public void setUpdatedByDate(Timestamp updatedByDate) {
    this.updatedByDate = (Timestamp)updatedByDate.clone();
  }

  public void setUpdatedByUser(String updatedByUser) {
    this.updatedByUser = updatedByUser;
  }

  public void setWorkGroupCode(String workGroupCode) {
    this.workGroupCode = workGroupCode;
  }

  public void setWorkGroupDesc(String workGroupDesc) {
    this.workGroupDesc = workGroupDesc;
  }

}
