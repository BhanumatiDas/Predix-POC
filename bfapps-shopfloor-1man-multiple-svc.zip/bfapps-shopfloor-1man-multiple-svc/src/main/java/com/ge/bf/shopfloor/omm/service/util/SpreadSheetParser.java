/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/**
 *
 * @author 221032148
 *
 */
@SuppressWarnings("nls")
public class SpreadSheetParser {

  /**
   * @param str
   *          -
   * @return -
   */
  public static boolean isInteger(String str) {
    return str.matches("^-?[0-9]+(\\.[0-9]+)?$");
  }

  /**
   * Unit Testing.
   *
   * @param args
   */
  public static void main(String[] args) {
    SpreadSheetParser parser = new SpreadSheetParser();
    List<String> workSheets = new ArrayList<String>();
    workSheets.add(IOneManMultipleConstants.MACHINE_DATA);
    workSheets.add(IOneManMultipleConstants.OPERATION_DATA);
    Map<String, String[][]> doc = parser
        .parseInputFile("/Tools/githubrepo/bfapps-shopfloor-1man-multiple-svc/conf/1manmultipledata.xlsx", workSheets);
    // System.err.println("Doc Output : " + doc.toString());
    String[][] data = doc.get("MachineData");
    for (String[] row : data) {
      System.err.println("Row : " + row[0] + " " + row[1]);
    }
    // log.debug(doc);
  }

  /**
   *
   */
  public SpreadSheetParser() {
  }

  /**
   * @param cell
   * @return
   */

  private String cellToString(Cell cell) {

    if (cell == null) {
      return null;
    }
    int cellType = cell.getCellType();
    if (cellType == Cell.CELL_TYPE_FORMULA) {
      int formulaResultType = cell.getCachedFormulaResultType();
      if (formulaResultType == Cell.CELL_TYPE_BOOLEAN) {
        return cell.getBooleanCellValue() + "";
      } else if (formulaResultType == Cell.CELL_TYPE_NUMERIC) {
        return cell.getNumericCellValue() + "";
      } else if (formulaResultType == Cell.CELL_TYPE_STRING) {
        return cell.getStringCellValue();
      }
    } else if (cellType == Cell.CELL_TYPE_BLANK) {
      return null;
    } else if (cellType == Cell.CELL_TYPE_BOOLEAN) {
      return cell.getBooleanCellValue() + "";
    } else if (cellType == Cell.CELL_TYPE_NUMERIC) {
      return cell.getNumericCellValue() + "";
    } else if (cellType == Cell.CELL_TYPE_STRING) {
      return cell.getStringCellValue();
    }
    return null;
  }

  /**
   * Returns the worksheet as String array.
   *
   * @param worksheetName
   * @param wb
   * @param skipFirstRow
   * @return
   */
  private String[][] getWorksheetRowsAsStrings(String worksheetName, Workbook wb, boolean skipFirstRow) {

    Sheet ws = wb.getSheet(worksheetName);
    if (ws == null) {
      return null; // worksheet not found.
    }

    int rowNum = ws.getLastRowNum() + 1;
    if (ws.getRow(0) == null) {
      return null;
    }
    int colNum = ws.getRow(0).getLastCellNum();
    String[][] data = new String[rowNum][colNum];

    int start = 0;
    if (skipFirstRow) {
      start = 1;
    }

    for (int i = start; i < rowNum; i++) {
      Row row = ws.getRow(i);
      if (row != null) {
        for (int j = 0; j < colNum; j++) {
          Cell cell = row.getCell(j);
          String value = cellToString(cell);
          // System.err.println("Cell Value : " + value);
          if (value != null) {
            data[i][j] = value.trim().replaceAll("[^\\x0A\\x0D\\x20-\\x7E]", "");
          }
        }
      }
    }

    return data;
  }

  /**
   * get the count of non-null rows in the data set.
   *
   * @param dataSet
   * @return
   */
  private int numNonNullRow(String[][] dataSet) {
    int ret = 0;

    for (String[] row : dataSet) {
      if (!rowIsNull(row)) {
        ret++;
      }
    }

    return ret;
  }

  /**
   * @param fis
   *          -
   * @param inputFile
   *          -
   * @param inputWorksheets
   *          -
   * @return -
   * @throws IOException
   *           -
   */
  public Map<String, String[][]> parseInputFile(InputStream fis, List<String> inputWorksheets) {

    try {
      Workbook wb = WorkbookFactory.create(fis);

      Map<String, String[][]> map = new LinkedHashMap<String, String[][]>();

      for (String worksheet : inputWorksheets) {
        String[][] data = getWorksheetRowsAsStrings(worksheet, wb, true);
        if (data != null) {
          data = removeBlankRows(data);
          map.put(worksheet, data);
        }
      }

      return map;
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    } catch (IOException e) {
      throw new RuntimeException(e);
    } catch (InvalidFormatException ife) {
      throw new RuntimeException(ife);
    }

  }

  /**
   * @param inputFile
   *          -
   * @param inputWorksheets
   *          -
   * @return -
   * @throws IOException
   *           -
   */
  @SuppressWarnings("resource")
  public Map<String, String[][]> parseInputFile(String inputFile, List<String> inputWorksheets) {
    File excel = new File(inputFile);
    Map<String, String[][]> retMap = null;
    try (FileInputStream fis = new FileInputStream(excel)) {
      retMap = parseInputFile(fis, inputWorksheets);
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    } catch (IOException e) { // thrown if fis.close() throws exception
      throw new RuntimeException(e);
    }
    return retMap;
  }

  /**
   * remove null rows from the data set (rows, whose cells are all null or the
   * empty string (after trim)).
   *
   * @param dataSet
   * @return
   */
  private String[][] removeBlankRows(String[][] dataSet) {
    int numNonNullRows = numNonNullRow(dataSet);

    String[][] retVals = new String[numNonNullRows][dataSet[0].length];

    int nextRow = 0;
    for (String[] row : dataSet) {
      if (!rowIsNull(row)) {
        retVals[nextRow++] = row;
      }
    }

    return retVals;
  }

  /**
   * does the row contain all null or empty strings (after trim).
   *
   * @param row
   * @return
   */
  private boolean rowIsNull(String[] row) {
    boolean allNull = true;
    for (String cell : row) {
      if (cell != null && cell.trim().length() != 0) {
        allNull = false;
        break;
      }
    }

    return allNull;
  }
}
