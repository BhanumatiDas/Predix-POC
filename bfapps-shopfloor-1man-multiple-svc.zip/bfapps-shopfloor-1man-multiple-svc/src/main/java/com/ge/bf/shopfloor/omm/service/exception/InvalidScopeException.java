/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

public class InvalidScopeException extends WorkGroupDataServiceException {

  public InvalidScopeException(String message) {
    super(message);
  }

  public InvalidScopeException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public InvalidScopeException(Throwable throwable) {
    super(throwable);
  }

}
