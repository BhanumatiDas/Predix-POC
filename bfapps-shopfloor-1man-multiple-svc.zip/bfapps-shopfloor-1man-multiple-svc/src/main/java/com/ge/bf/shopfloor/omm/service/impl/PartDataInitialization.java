/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IPartDataService;
import com.ge.bf.shopfloor.omm.service.entity.PartData;
import com.ge.bf.shopfloor.omm.service.exception.DataFormatException;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.PartDataServiceException;
import com.ge.bf.shopfloor.omm.service.util.IOneManMultipleConstants;

/**
 * @author 221032148
 *
 */
@Component
@SuppressWarnings({ "nls", "unused" })
public class PartDataInitialization extends AbstractDataInitialization {
  private static final Logger LOGGER = LoggerFactory.getLogger(PartDataInitialization.class);
  private static final int PART_CODE = 0;
  private static final int PART_DESC = 1;

  @Autowired
  private IPartDataService iPartDataService;

  @Override
  protected String saveData(Map<String, String[][]> content) throws DataFormatException, PartDataServiceException {
    String[][] partData = content.get(IOneManMultipleConstants.PART_DATA);
    PartData data = null;
    List<PartData> partDataSet = new ArrayList<PartData>(10);
    String msg = "Zero records exists in Part Data Worksheet";
    if (partData == null) {
      return msg;
    }

    for (String[] row : partData) {
      PartData part = iPartDataService.getPartDataByCode(row[PART_CODE]);
      data = (part != null) ? part : new PartData();
      if ((row[PART_CODE] == null) || (row[PART_CODE].trim().length() == 0)) {
        throw new PartDataServiceException(ErrorMessage.NO_PART_CODE);
      } else {
        data.setPartCode(row[PART_CODE]);
      }
      data.setPartDesc(row[PART_DESC]);
      partDataSet.add(data);
    }

    if (!partDataSet.isEmpty()) {
      msg = partDataSet.size() + " records exists in the Part Data Worksheet";
      LOGGER.info(msg);
      iPartDataService.createPartData(partDataSet);
    }
    return msg;
  }
}
