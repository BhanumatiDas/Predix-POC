/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.bf.shopfloor.omm.service.IPartDataService;
import com.ge.bf.shopfloor.omm.service.TenantContextProvider;
import com.ge.bf.shopfloor.omm.service.entity.PartData;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.PartDataServiceException;
import com.ge.bf.shopfloor.omm.service.rest.assembler.PartDataResourceAssembler;
import com.ge.bf.shopfloor.omm.service.rest.resources.PartDataResourceOutput;

@Controller
@RequestMapping(value = "/omm/v1/parts", produces = { MediaTypes.HAL_JSON_VALUE })
public class PartDataController {

  private static final Logger LOGGER = LoggerFactory.getLogger(PartDataController.class);

  @Autowired
  private IPartDataService iPartDataService;

  @Autowired
  private TenantContextProvider tenantContextProvider;

  /**
   * 
   * @param partDataResource
   * @return
   * @throws PartDataServiceException
   */
  private PartData buildPartData(PartDataResourceOutput partDataResource) throws PartDataServiceException {
    PartData partData = new PartData();
    BeanUtils.copyProperties(partDataResource, partData);
    return partData;
  }

  @RequestMapping(method = POST, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<PartDataResourceOutput> createPartData(@RequestBody PartDataResourceOutput partDataResourceInput)
      throws PartDataServiceException {

    /*
     * String tenantId = tenantContextProvider.getTenantId(); if (tenantId ==
     * null) { throw new MissingTenantIdException(NO_TENANT_ID); }
     */

    PartData partData = buildPartData(partDataResourceInput);
    PartData newPartData = iPartDataService.createPartData(partData);
    PartDataResourceAssembler assembler = new PartDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(newPartData), CREATED);
  }

  @RequestMapping(value = "/all", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<PartDataResourceOutput>> getPartData() throws PartDataServiceException {

    try {
      /*
       * String tenantId = tenantContextProvider.getTenantId(); hardcode, remove
       * this line when tennant context is implemented. String tenantId =
       * "12abedfr"; if (tenantId == null) { throw new
       * MissingTenantIdException(NO_TENANT_ID); }
       */

      List<PartData> partData = iPartDataService.getPartDataSet();
      if (CollectionUtils.isEmpty(partData)) {
        return new ResponseEntity<>(NO_CONTENT);
      }

      PartDataResourceAssembler assembler = new PartDataResourceAssembler();
      List<PartDataResourceOutput> partDataResource = assembler.toResources(partData);

      return new ResponseEntity<>(partDataResource, OK);
    } catch (Exception e) {
      throw new PartDataServiceException(ErrorMessage.PARTDATA_RETRIEVAL_FAILURE, e);
    }
  }

  @RequestMapping(value = "/id/{id}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<PartDataResourceOutput> getPartData(@PathVariable("id") String id) throws PartDataServiceException {

    PartData partData = isValidPartData(id);

    PartDataResourceAssembler assembler = new PartDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(partData), OK);
  }

  @RequestMapping(value = "/search", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<PartDataResourceOutput> searchPartData(
      @RequestParam(value = "filter", required = true) String filter) throws PartDataServiceException {

    if (filter == null) {
      return null;
    }
    PartData partData = null;
    String[] tokens = filter.split("=");
    for (String token : tokens) {
      LOGGER.info("filters = " + token);
    }
    if (tokens[0].startsWith("part")) {
      partData = isValidPartDataByCode(tokens[1]);
    } else {
      throw new PartDataServiceException("Invalid filter passed...supported filters are 'partcode' ");
    }
    PartDataResourceAssembler assembler = new PartDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(partData), OK);
  }

  /**
   * 
   * @param partDataId
   * @return
   * @throws PartDataServiceException
   */
  private PartData isValidPartData(String partDataId) throws PartDataServiceException {
    PartData partData = iPartDataService.getPartData(partDataId);
    if (partData == null) {
      throw new PartDataServiceException(ErrorMessage.NONEXISTANT_PARTDATA);
    }
    return partData;
  }

  @RequestMapping(value = "/partCode/{partCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<PartDataResourceOutput> getPartDataByCode(@PathVariable("partCode") String partCode)
      throws PartDataServiceException {

    try {

      PartData part = isValidPartDataByCode(partCode);

      PartDataResourceAssembler assembler = new PartDataResourceAssembler();
      return new ResponseEntity<>(assembler.toResource(part), OK);
    } catch (Exception e) {
      throw new PartDataServiceException(ErrorMessage.PARTDATA_RETRIEVAL_FAILURE, e);
    }
  }

  /**
   * 
   * @param partcode
   * @return
   * @throws PartDataServiceException
   */
  private PartData isValidPartDataByCode(String partcode) throws PartDataServiceException {
    PartData partData = iPartDataService.getPartDataByCode(partcode);
    if (partData == null) {
      throw new PartDataServiceException(ErrorMessage.NONEXISTANT_PARTDATA);
    }
    return partData;
  }

}
