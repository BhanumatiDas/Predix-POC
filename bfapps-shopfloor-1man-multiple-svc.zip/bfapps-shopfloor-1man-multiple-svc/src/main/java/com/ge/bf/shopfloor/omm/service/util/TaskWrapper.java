/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.util;

import java.sql.Timestamp;
import java.util.Comparator;
import java.util.Date;

/**
 * @author 221032148 This is wrapper class to hold list of Tasks for a operation
 *         and implements the logic to sort tasks.
 *
 */
public class TaskWrapper implements Comparable<TaskWrapper> {

  private static Comparator<TaskWrapper> taskSequenceComparator = new Comparator<TaskWrapper>() {

    @Override
    public int compare(TaskWrapper task1, TaskWrapper task2) {
      String seq1 = task1.getTaskSequence().toUpperCase();
      String seq2 = task2.getTaskSequence().toUpperCase();
      // ascending order
      return seq1.compareTo(seq2);

      // descending order
      // return seq2 - seq1;
    }
  };

  public static Comparator<TaskWrapper> getTaskSequenceComparator() {
    return taskSequenceComparator;
  }

  public static void setTaskSequenceComparator(Comparator<TaskWrapper> taskSequenceComparator) {
    TaskWrapper.taskSequenceComparator = taskSequenceComparator;
  }

  private String id;
  private String taskCode;
  private String taskDesc;
  private String operationCode;
  private String taskSequence;
  private double manualTime;

  private double autoTime;
  private double travelTime;
  private String flag;

  private double remainingTime;

  private boolean isTaskCompleted;

  private int myInt = 1;
  private Date taskAutoStartTime;

  private boolean isTaskScheduled;

  private String partCode;

  private String machineCode;

  private Timestamp manualStartTime;
  private Timestamp manualEndTime;

  @Override
  public int compareTo(TaskWrapper compareTask) {
    int compareTaskInt = compareTask.getMyInt();

    // ascending order
    return myInt - compareTaskInt;
  }

  /**
   * @return the autoTime
   */
  public double getAutoTime() {
    return autoTime;
  }

  /**
   * @return the flag
   */
  public String getFlag() {
    return flag;
  }

  /**
   * @return the id
   */
  public String getId() {
    return id;
  }

  public String getMachineCode() {
    return machineCode;
  }

  /**
   * @return the manualTime
   */
  public double getManualTime() {
    return manualTime;
  }

  /**
   * @return the myInt
   */
  public int getMyInt() {
    return myInt;
  }

  /**
   * @return the operationCode
   */
  public String getOperationCode() {
    return operationCode;
  }

  public String getPartCode() {
    return partCode;
  }

  /**
   * @return the remainingTime
   */
  public double getRemainingTime() {
    return remainingTime;
  }

  /**
   * @return the taskAutoStartTime
   */
  public Date getTaskAutoStartTime() {
    return (Date)taskAutoStartTime.clone();
  }

  /**
   * @return the taskCode
   */
  public String getTaskCode() {
    return taskCode;
  }

  /**
   * @return the taskDesc
   */
  public String getTaskDesc() {
    return taskDesc;
  }

  /**
   * @return the taskSequence
   */
  public String getTaskSequence() {
    return taskSequence;
  }

  /**
   * @return the totalTime
   */
  public double getTotalTime() {
    return this.manualTime + this.autoTime + this.travelTime;
  }

  /**
   * @return the travelTime
   */
  public double getTravelTime() {
    return travelTime;
  }

  /**
   * @return the isTaskCompleted
   */
  public boolean isTaskCompleted() {
    isTaskCompleted = (getRemainingTime() <= 0.0) ? true : false;
    return isTaskCompleted;
  }

  /**
   * @return the isTaskScheduled
   */
  public boolean isTaskScheduled() {
    return isTaskScheduled;
  }

  /**
   * @param autoTime
   *          the autoTime to set
   */
  public void setAutoTime(double autoTime) {
    this.autoTime = autoTime;
  }

  /**
   * @param flag
   *          the flag to set
   */
  public void setFlag(String flag) {
    this.flag = flag;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * @param isTaskScheduled
   *          the isTaskScheduled to set
   */
  public void setIsTaskScheduled(boolean isTaskScheduled) {
    this.isTaskScheduled = isTaskScheduled;
  }

  public void setMachineCode(String machineCode) {
    this.machineCode = machineCode;
  }

  /**
   * @param manualTime
   *          the manualTime to set
   */
  public void setManualTime(double manualTime) {
    this.manualTime = manualTime;
  }

  /**
   * @param myInt
   *          the myInt to set
   */
  public void setMyInt(int myInt) {
    this.myInt = myInt;
  }

  /**
   * @param operationCode
   *          the operationCode to set
   */
  public void setOperationCode(String operationCode) {
    this.operationCode = operationCode;
  }

  public void setPartCode(String partCode) {
    this.partCode = partCode;
  }

  /**
   * @param remainingTime
   *          the remainingTime to set
   */
  public void setRemainingTime(double elaspedTime) {
    if (remainingTime == 0.0) {
      remainingTime = this.autoTime + this.travelTime;
    }
    this.remainingTime = this.remainingTime - elaspedTime;
  }

  /**
   * @param taskAutoStartTime
   *          the taskAutoStartTime to set
   */
  public void setTaskAutoStartTime(Date taskAutoStartTime) {
    this.taskAutoStartTime = (Date)taskAutoStartTime.clone();
  }

  /**
   * @param taskCode
   *          the taskCode to set
   */
  public void setTaskCode(String taskCode) {
    this.taskCode = taskCode;
  }

  /**
   * @param taskDesc
   *          the taskDesc to set
   */
  public void setTaskDesc(String taskDesc) {
    this.taskDesc = taskDesc;
  }

  /**
   * @param taskSequence
   *          the taskSequence to set
   */
  public void setTaskSequence(String taskSequence) {
    this.taskSequence = taskSequence;
  }

  /**
   * @param travelTime
   *          the travelTime to set
   */
  public void setTravelTime(double travelTime) {
    this.travelTime = travelTime;
  }

  @Override
  public String toString() {
    StringBuffer sb = new StringBuffer();

    /*
     * sb.append(" Ops No     : " + this.getOperationCode());
     * sb.append(" Task Code  : " + this.getTaskCode());
     * sb.append(" Task Desc  : " + this.getTaskDesc());
     * sb.append(" Manul Time : " + this.getManualTime());
     * sb.append(" Auto Time  : " + this.getAutoTime());
     * //sb.append(" Remaining Time: " + this.getRemainingTime());
     */
    sb.append(this.getOperationCode() + ",");
    sb.append(this.getTaskCode() + ",");
    sb.append(this.getTaskDesc() + ",");
    sb.append(this.getPartCode() + ",");
    sb.append(this.getMachineCode() + ",");
    sb.append(this.getManualTime() + ",");
    sb.append(this.getAutoTime() + ",");
    sb.append(this.getRemainingTime());

    return sb.toString();
	}

	public Timestamp getManualStartTime() {
		return manualStartTime;
	}

	public void setManualStartTime(Timestamp manualStartTime) {
		this.manualStartTime = manualStartTime;
	}

	public Timestamp getManualEndTime() {
		return manualEndTime;
	}

	public void setManualEndTime(Timestamp manualEndTime) {
		this.manualEndTime = manualEndTime;
	}


}
