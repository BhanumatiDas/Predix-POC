/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorResourceOutput extends ResourceSupport {

  private String timestamp;
  private String path;
  private List<Map<String, String>> errors = new ArrayList<Map<String, String>>();

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
      return false;
    }

    ErrorResourceOutput other = (ErrorResourceOutput)obj;

    return new EqualsBuilder().append(this.timestamp, other.timestamp).append(this.path, other.path)
        .append(this.errors, other.errors).isEquals();
  }

  public List<Map<String, String>> getErrors() {
    return errors;
  }

  public String getPath() {
    return path;
  }

  public String getTimestamp() {
    return timestamp;
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.timestamp).append(this.path).append(this.errors).toHashCode();
  }

  public void setErrors(List<Map<String, String>> errors) {
    this.errors = errors;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this).append(timestamp).append(path).append(errors).toString();
  }

}
