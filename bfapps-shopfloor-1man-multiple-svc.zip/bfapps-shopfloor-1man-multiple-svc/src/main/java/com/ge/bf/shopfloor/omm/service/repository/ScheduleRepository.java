/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ge.bf.shopfloor.omm.service.entity.Schedule;
import com.ge.bf.shopfloor.omm.service.exception.ScheduleDataServiceException;

/**
 * 
 * @author BD470389
 *
 */
public interface ScheduleRepository extends JpaRepository<Schedule, String> {

	Schedule findById(@Param("id") String id);

	@Query("SELECT sd FROM Schedule sd" + " WHERE sd.taskCode = :taskCode")
	Schedule getScheduleByTaskCode(@Param("taskCode") String taskCode) throws ScheduleDataServiceException;

	@Query("SELECT sd FROM Schedule sd" + " WHERE sd.partCode = :partCode")
	List<Schedule> getScheduleByPartCode(@Param("partCode") String partCode) throws ScheduleDataServiceException;

	@Query("SELECT sd FROM Schedule sd" + " WHERE sd.machineCode = :machineCode")
	List<Schedule> getScheduleByMachineCode(@Param("machineCode") String machineCode)
			throws ScheduleDataServiceException;

	@Query("SELECT sd FROM Schedule sd" + " WHERE sd.operationCode = :operationCode")
	List<Schedule> getScheduleByOperationCode(@Param("operationCode") String operationCode)
			throws ScheduleDataServiceException;

	@Query("SELECT sd FROM Schedule sd" + " WHERE sd.runId = :runId")
	List<Schedule> getScheduleByRunId(@Param("runId") String runId) throws ScheduleDataServiceException;

	@Query("SELECT sd FROM Schedule sd" + " WHERE sd.completeFlag = :completeFlag")
	List<Schedule> getScheduleByStatus(@Param("completeFlag") String completeFlag) throws ScheduleDataServiceException;

	@Query("SELECT sd FROM Schedule sd" + " WHERE sd.runId = :runId AND sd.completeFlag = :completeFlag")
	List<Schedule> getScheduleDataSet(@Param("runId") String runId, @Param("completeFlag") String completeFlag)
			throws ScheduleDataServiceException;

}
