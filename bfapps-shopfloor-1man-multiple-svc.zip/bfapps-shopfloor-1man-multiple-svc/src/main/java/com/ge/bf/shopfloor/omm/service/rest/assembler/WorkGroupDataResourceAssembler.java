/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.assembler;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

import com.ge.bf.shopfloor.omm.service.entity.WorkGroupData;
import com.ge.bf.shopfloor.omm.service.rest.controller.WorkGroupDataController;
import com.ge.bf.shopfloor.omm.service.rest.resources.WorkGroupDataResourceOutput;

public class WorkGroupDataResourceAssembler
    extends ResourceAssemblerSupport<WorkGroupData, WorkGroupDataResourceOutput> {

  public WorkGroupDataResourceAssembler() {
    super(WorkGroupDataController.class, WorkGroupDataResourceOutput.class);
  }

  @Override
  public WorkGroupDataResourceOutput toResource(WorkGroupData workGroupData) {

    WorkGroupDataResourceOutput resource;

    resource = createResourceWithId(workGroupData.getId(), workGroupData);

    BeanUtils.copyProperties(workGroupData, resource);
    return resource;
  }
}
