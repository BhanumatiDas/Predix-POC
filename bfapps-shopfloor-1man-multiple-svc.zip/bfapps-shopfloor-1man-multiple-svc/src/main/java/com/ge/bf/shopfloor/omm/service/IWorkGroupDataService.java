/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

import java.util.List;

import com.ge.bf.shopfloor.omm.service.entity.WorkGroupData;
import com.ge.bf.shopfloor.omm.service.exception.WorkGroupDataServiceException;

public interface IWorkGroupDataService {
  List<WorkGroupData> createWorkGroupData(List<WorkGroupData> workGroupData) throws WorkGroupDataServiceException;

  WorkGroupData createWorkGroupData(WorkGroupData workGroupData) throws WorkGroupDataServiceException;

  WorkGroupData getWorkGroupData(String workGroupId) throws WorkGroupDataServiceException;

  List<WorkGroupData> getWorkGroupDataByCode(String workGroupCode) throws WorkGroupDataServiceException;

  // List<WorkGroupData> getWorkGroupDataSet(String tenantId) throws
  // WorkGroupDataServiceException;

  List<WorkGroupData> getWorkGroupDataSet() throws WorkGroupDataServiceException;

}
