/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ge.bf.shopfloor.omm.service.entity.Operation;
import com.ge.bf.shopfloor.omm.service.exception.OperationDataServiceException;

public interface OperationRepository extends JpaRepository<Operation, String> {
  Operation findById(@Param("id") String id);

  @Query("SELECT o FROM Operation o " + "WHERE o.operationCode = :operationCode")
  Operation getOperationByCode(@Param("operationCode") String operationCode) throws OperationDataServiceException;

  @Query("SELECT o FROM Operation o " + "WHERE o.machineCode = :machineCode")
  List<Operation> getOperationsByMachineCode(@Param("machineCode") String machineCode)
      throws OperationDataServiceException;

  @Query("SELECT o FROM Operation o, MachineData m "
      + "WHERE o.machineCode = m.machineCode AND m.workgroupCode = :workgroupCode ")
  List<Operation> findValidOperationByWorkGroup(@Param("workgroupCode") String workgroupCode)
      throws OperationDataServiceException;

}
