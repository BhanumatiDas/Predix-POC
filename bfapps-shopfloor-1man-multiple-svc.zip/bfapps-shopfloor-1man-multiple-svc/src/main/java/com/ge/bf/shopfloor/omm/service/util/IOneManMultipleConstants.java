/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.util;

/**
 * @author 221032148
 *
 */
public interface IOneManMultipleConstants {
  String MACHINE_DATA = "MachineData"; //$NON-NLS-1$
  String OPERATION_DATA = "OperationData"; //$NON-NLS-1$
  String TASK_DATA = "TaskData"; //$NON-NLS-1$
  String PART_DATA = "PartData"; //$NON-NLS-1$
  String WORKGROUP_DATA = "WorkgroupData"; //$NON-NLS-1$

  String WORKGROUP_ACTIVE = "Y";
  String WORKGROUP_INACTIVE = "N";

  String SCHEDULE_COMELETE = "Y";
  String SCHEDULE_INCOMPLETE = "N";

  String WAIT_TASK = "W";
}
