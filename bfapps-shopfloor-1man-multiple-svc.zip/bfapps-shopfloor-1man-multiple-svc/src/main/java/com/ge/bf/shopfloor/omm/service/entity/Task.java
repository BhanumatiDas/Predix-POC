/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.entity;

import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.hateoas.Identifiable;

import com.ge.bf.shopfloor.omm.service.rest.util.ResourcesUtils;

/**
 * @author 221032148
 *
 */
@Entity
@Table(name = "task", schema = "omm")
public class Task implements Identifiable<String> {

  @Id
  @Column(name = "task_id")
  private String id;
  @Column(name = "task_code")
  private String taskCode;
  @Column(name = "task_desc")
  private String taskDesc;
  @Column(name = "operation_code")
  private String operationCode;
  @Column(name = "task_sequence")
  private String taskSequence;
  @Column(name = "manual_time")
  private double manualTime;
  @Column(name = "auto_time")
  private double autoTime;
  @Column(name = "travel_time")
  private double travelTime;
  @Column(name = "flag")
  private String flag;
  @Column(name = "created_by")
  private String createdBy;
  @Column(name = "updated_by")
  private String updatedBy;
  @Column(name = "created_date")
  private Timestamp createdDate;
  @Column(name = "updated_date")
  private Timestamp updatedDate;

  @Override
  public String getId() {
    return id;
  }

  @PrePersist
  void onCreate() {
    this.setId(UUID.randomUUID().toString());
    this.setCreatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setCreatedBy("internal");
  }

  @PreUpdate
  void onUpdate() {
    this.setUpdatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setUpdatedBy("internal");
  }

  /**
   * @return the taskCode
   */
  public String getTaskCode() {
    return taskCode;
  }

  /**
   * @param taskCode
   *          the taskCode to set
   */
  public void setTaskCode(String taskCode) {
    this.taskCode = taskCode;
  }

  /**
   * @return the taskDesc
   */
  public String getTaskDesc() {
    return taskDesc;
  }

  /**
   * @param taskDesc
   *          the taskDesc to set
   */
  public void setTaskDesc(String taskDesc) {
    this.taskDesc = taskDesc;
  }

  /**
   * @return the taskSequence
   */
  public String getTaskSequence() {
    return taskSequence;
  }

  /**
   * @param taskSequence
   *          the taskSequence to set
   */
  public void setTaskSequence(String taskSequence) {
    this.taskSequence = taskSequence;
  }

  /**
   * @return the manualTime
   */
  public double getManualTime() {
    return manualTime;
  }

  /**
   * @param manualTime
   *          the manualTime to set
   */
  public void setManualTime(double manualTime) {
    this.manualTime = manualTime;
  }

  /**
   * @return the autoTime
   */
  public double getAutoTime() {
    return autoTime;
  }

  /**
   * @param autoTime
   *          the autoTime to set
   */
  public void setAutoTime(double autoTime) {
    this.autoTime = autoTime;
  }

  /**
   * @return the travelTime
   */
  public double getTravelTime() {
    return travelTime;
  }

  /**
   * @param travelTime
   *          the travelTime to set
   */
  public void setTravelTime(double travelTime) {
    this.travelTime = travelTime;
  }

  /**
   * @return the flag
   */
  public String getFlag() {
    return flag;
  }

  /**
   * @param flag
   *          the flag to set
   */
  public void setFlag(String flag) {
    this.flag = flag;
  }

  /**
   * @return the createdBy
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * @param createdBy
   *          the createdBy to set
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * @return the updatedBy
   */
  public String getUpdatedBy() {
    return updatedBy;
  }

  /**
   * @param updatedBy
   *          the updatedBy to set
   */
  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  /**
   * @return the createdDate
   */
  public Timestamp getCreatedDate() {
    return createdDate;
  }

  /**
   * @param createdDate
   *          the createdDate to set
   */
  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = createdDate;
  }

  /**
   * @return the updatedDate
   */
  public Timestamp getUpdatedDate() {
    return updatedDate;
  }

  /**
   * @param updatedDate
   *          the updatedDate to set
   */
  public void setUpdatedDate(Timestamp updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * @return the operationCode
   */
  public String getOperationCode() {
    return operationCode;
  }

  /**
   * @param operationCode
   *          the operationCode to set
   */
  public void setOperationCode(String operationCode) {
    this.operationCode = operationCode;
  }

}
