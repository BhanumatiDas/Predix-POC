/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.bf.shopfloor.omm.service.IMachineDataService;
import com.ge.bf.shopfloor.omm.service.TenantContextProvider;
import com.ge.bf.shopfloor.omm.service.entity.MachineData;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.MachineDataServiceException;
import com.ge.bf.shopfloor.omm.service.rest.assembler.MachineDataResourceAssembler;
import com.ge.bf.shopfloor.omm.service.rest.resources.MachineDataResourceOutput;

@Controller
@RequestMapping(value = "/omm/v1/machines", produces = { MediaTypes.HAL_JSON_VALUE })
public class MachineDataController {

  private static final Logger LOGGER = LoggerFactory.getLogger(MachineDataController.class);

  @Autowired
  private IMachineDataService iMachineDataService;

  @Autowired
  private TenantContextProvider tenantContextProvider;

  /**
   * 
   * @param machineDataResource
   * @return
   * @throws MachineDataServiceException
   */
  private MachineData buildMachineData(MachineDataResourceOutput machineDataResource)
      throws MachineDataServiceException {
    MachineData machineData = new MachineData();
    BeanUtils.copyProperties(machineDataResource, machineData);
    return machineData;
  }

  @RequestMapping(method = POST, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<MachineDataResourceOutput> createMachineData(
      @RequestBody MachineDataResourceOutput machineDataResourceInput) throws MachineDataServiceException {

    /*
     * String tenantId = tenantContextProvider.getTenantId(); if (tenantId ==
     * null) { throw new MissingTenantIdException(NO_TENANT_ID); }
     */

    MachineData workGroupData = buildMachineData(machineDataResourceInput);
    MachineData newMachineData = iMachineDataService.createMachineData(workGroupData);
    MachineDataResourceAssembler assembler = new MachineDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(newMachineData), CREATED);
  }

  @RequestMapping(method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<MachineDataResourceOutput>> getMachineData() throws MachineDataServiceException {

    try {
      /*
       * String tenantId = tenantContextProvider.getTenantId(); hardcode, remove
       * this line when tennant context is implemented. String tenantId =
       * "12abedfr"; if (tenantId == null) { throw new
       * MissingTenantIdException(NO_TENANT_ID); }
       */

      List<MachineData> machineData = iMachineDataService.getMachineDataSet();

      if (CollectionUtils.isEmpty(machineData)) {
        return new ResponseEntity<>(NO_CONTENT);
      }

      MachineDataResourceAssembler assembler = new MachineDataResourceAssembler();
      List<MachineDataResourceOutput> machineDataResource = assembler.toResources(machineData);

      return new ResponseEntity<>(machineDataResource, OK);
    } catch (Exception e) {
      throw new MachineDataServiceException(ErrorMessage.MACHINEDATA_RETRIEVAL_FAILURE, e);
    }
  }

  @RequestMapping(value = "/id/{id}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<MachineDataResourceOutput> getMachineData(@PathVariable("id") String id)
      throws MachineDataServiceException {

    MachineData machineData = isValidMachineData(id);

    MachineDataResourceAssembler assembler = new MachineDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(machineData), OK);
  }

  @RequestMapping(value = "/search", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<MachineDataResourceOutput>> searchMachineData(
      @RequestParam(value = "filter", required = true) String filter) throws MachineDataServiceException {

    if (filter == null) {
      return null;
    }
    List<MachineData> machineData = null;
    String[] tokens = filter.split("=");
    for (String token : tokens) {
      LOGGER.info("filters = " + token);
    }
    if (tokens[0].startsWith("machine")) {
      machineData = isValidMachineDataByCode(tokens[1]);
    } else if (tokens[0].startsWith("plant")) {
      machineData = isValidMachineDataByPlantCode(tokens[1]);
    } else if (tokens[0].startsWith("part")) {
      machineData = isValidMachineDataByPartNumber(tokens[1]);
    } else {
      throw new MachineDataServiceException(
          "Invalid filter passed...supported filters are 'machinecode , partnumber, plantcode' ");
    }
    MachineDataResourceAssembler assembler = new MachineDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResources(machineData), OK);
  }

  /**
   * 
   * @param machineDataId
   * @return
   * @throws MachineDataServiceException
   */
  private MachineData isValidMachineData(String machineDataId) throws MachineDataServiceException {
    MachineData machineData = iMachineDataService.getMachineData(machineDataId);
    if (machineData == null) {
      throw new MachineDataServiceException(ErrorMessage.NONEXISTANT_MACHINEDATA);
    }
    return machineData;
  }

  /**
   * 
   * @param machinecode
   * @return
   * @throws MachineDataServiceException
   */
  private List<MachineData> isValidMachineDataByCode(String machinecode) throws MachineDataServiceException {
    List<MachineData> machineData = iMachineDataService.getMachineDataByCode(machinecode);
    if (machineData == null) {
      throw new MachineDataServiceException(ErrorMessage.NONEXISTANT_MACHINEDATA);
    }
    return machineData;
  }

  /**
   * 
   * @param machinecode
   * @return
   * @throws MachineDataServiceException
   */
  private List<MachineData> isValidMachineDataByPlantCode(String platcode) throws MachineDataServiceException {
    List<MachineData> machineData = iMachineDataService.getMachineDataByPlant(platcode);
    if (machineData == null) {
      throw new MachineDataServiceException(ErrorMessage.NONEXISTANT_MACHINEDATA);
    }
    return machineData;
  }

  /**
   * 
   * @param machinecode
   * @return
   * @throws MachineDataServiceException
   */
  private List<MachineData> isValidMachineDataByPartNumber(String partNumber) throws MachineDataServiceException {
    List<MachineData> machineData = iMachineDataService.getMachineDataPartNumber(partNumber);
    if (machineData == null) {
      throw new MachineDataServiceException(ErrorMessage.NONEXISTANT_MACHINEDATA);
    }
    return machineData;
  }

}
