/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

import java.io.InputStream;
import java.util.List;

import com.ge.bf.shopfloor.omm.service.exception.OneManMultipleServiceException;

/**
 * @author 221032148
 *
 */
public interface IOneManMultipleDataService {

  /**
   * Method to upload the execl file data.
   * 
   * @param name
   * @param data
   * @return
   * @throws OneManMultipleServiceException
   */
  List<String> uploadXlsData(String name, InputStream data) throws OneManMultipleServiceException;
}
