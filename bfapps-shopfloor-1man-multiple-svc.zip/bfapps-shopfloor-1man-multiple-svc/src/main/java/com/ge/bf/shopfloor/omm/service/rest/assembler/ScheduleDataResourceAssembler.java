/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.assembler;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

import com.ge.bf.shopfloor.omm.service.entity.Schedule;
import com.ge.bf.shopfloor.omm.service.rest.controller.ScheduleDataController;
import com.ge.bf.shopfloor.omm.service.rest.resources.ScheduleDataResourceOutput;

/**
 * 
 * @author BD470389
 *
 */
public class ScheduleDataResourceAssembler extends ResourceAssemblerSupport<Schedule, ScheduleDataResourceOutput> {

  public ScheduleDataResourceAssembler() {
    super(ScheduleDataController.class, ScheduleDataResourceOutput.class);
  }

  @Override
  public ScheduleDataResourceOutput toResource(Schedule schedule) {

    ScheduleDataResourceOutput resource;

    resource = createResourceWithId("id/" + schedule.getId(), schedule);

    BeanUtils.copyProperties(schedule, resource);
    return resource;
  }

}
