/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

/**
 * Exception for non existent work orders.
 *
 * @author 212556687
 */
public class WorkGroupDataNotFoundException extends WorkGroupDataServiceException {

  public WorkGroupDataNotFoundException(String message) {
    super(message);
  }

  public WorkGroupDataNotFoundException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public WorkGroupDataNotFoundException(Throwable throwable) {
    super(throwable);
  }

}
