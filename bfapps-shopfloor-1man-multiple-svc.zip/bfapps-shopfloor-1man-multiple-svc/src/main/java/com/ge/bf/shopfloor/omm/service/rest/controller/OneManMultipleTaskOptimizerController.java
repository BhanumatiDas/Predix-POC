/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.bf.shopfloor.omm.service.IOneManMultipleTaskOptimizer;
import com.ge.bf.shopfloor.omm.service.IWorkGroupDataService;
import com.ge.bf.shopfloor.omm.service.entity.Schedule;
import com.ge.bf.shopfloor.omm.service.entity.WorkGroupData;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.OneManMultipleServiceException;
import com.ge.bf.shopfloor.omm.service.exception.WorkGroupDataServiceException;
import com.ge.bf.shopfloor.omm.service.impl.ScheduleDataInitialization;
import com.ge.bf.shopfloor.omm.service.rest.assembler.ScheduleDataResourceAssembler;
import com.ge.bf.shopfloor.omm.service.rest.resources.ScheduleDataResourceOutput;
import com.ge.bf.shopfloor.omm.service.rest.util.ResourcesUtils;
import com.ge.bf.shopfloor.omm.service.util.IOneManMultipleConstants;
import com.ge.bf.shopfloor.omm.service.util.TaskWrapper;

@Controller
@RequestMapping(value = "/omm/v1/taskoptimizer", produces = { MediaTypes.HAL_JSON_VALUE })
public class OneManMultipleTaskOptimizerController {

  private static final Logger LOGGER = LoggerFactory.getLogger(OneManMultipleTaskOptimizerController.class);

  @Autowired
  private IOneManMultipleTaskOptimizer taskOptimizer;

  @Autowired
  private ScheduleDataInitialization scheduleData;

  @Autowired
  private IWorkGroupDataService iWorkGroupDataService;

  private List<TaskWrapper> sequencedTasks;

  @SuppressWarnings("nls")
  @RequestMapping(value = "/{workgroup}/sequencetasks/{taskid}/nexttask", method = GET, produces = {
      MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public List<String> getNextScheduleOperationTask(@PathVariable("workgroup") String workgroup,
      @PathVariable("taskid") String taskid) throws OneManMultipleServiceException {

    // TODO Need to implement security check to see if the user is allowed
    // to
    // optimize the tasks.
    // return taskOptimizer.generateTaskOptimization(work group);
    // messages.add("Operations are successfully sequenced.");
    // return messages;
    List<String> messages = new ArrayList<String>(10);
    TaskWrapper nextTask = null;
    int i = 0;
    if (sequencedTasks == null) {
      messages.add("Zero Tasks found !!");
      return messages;
    }
    for (TaskWrapper task : sequencedTasks) {
      i += 1;
      if (task.getTaskCode().equals(taskid)) {
        nextTask = sequencedTasks.get(i);
        nextTask.setTaskAutoStartTime(ResourcesUtils.getUTCCurrentDate());
        break;
      }
    }
    messages.add("Step " + i + " of " + sequencedTasks.size());
    if (nextTask != null) {
      messages.add(nextTask.toString());
    }
    return messages;
  }

  @SuppressWarnings("nls")
  @RequestMapping(value = "/{workgroup}/sequencetasks", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  /*
   * public @ResponseBody List<String>
   * scheduleOperations(@PathVariable("workgroup") String workgroup) throws
   * OneManMultipleServiceException {
   */
  public HttpEntity<List<ScheduleDataResourceOutput>> scheduleOperations(@PathVariable("workgroup") String workgroup)
      throws OneManMultipleServiceException {

    List<WorkGroupData> workGroupList = iWorkGroupDataService.getWorkGroupDataByCode(workgroup);
    if (workGroupList.get(0).getActiveFlag().equalsIgnoreCase(IOneManMultipleConstants.WORKGROUP_ACTIVE)) {
      // TODO Need to implement security check to see if the user is
      // allowed to
      // optimize the tasks.
      sequencedTasks = taskOptimizer.generateTaskOptimization(workgroup);
      // end of all tasks are sequenced and scheduled.
      List<String> seqTasks = new ArrayList<String>(100);
      // List<Schedule> scheduleList = new ArrayList<Schedule>(100);
      int cnt = 0;
      int totalTime = 0;
      for (TaskWrapper t : sequencedTasks) {
        cnt += 1;
        seqTasks.add(cnt + "," + t.toString());
        LOGGER.debug("Task Seq: " + cnt + " " + t.toString());
        totalTime += t.getManualTime() + t.getAutoTime();

      }
      List<Schedule> scheduleList = scheduleData.saveSequencedTasks(sequencedTasks);

      seqTasks.add("Total Time took to run : " + totalTime);
      // return sequencedTasks;
      // return seqTasks;

      ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
      List<ScheduleDataResourceOutput> scheduleDataResource = assembler.toResources(scheduleList);

      return new ResponseEntity<>(scheduleDataResource, OK);
    } else {
      throw new WorkGroupDataServiceException(ErrorMessage.INACTIVE_WORKGROUPDATA);
    }

  }

}
