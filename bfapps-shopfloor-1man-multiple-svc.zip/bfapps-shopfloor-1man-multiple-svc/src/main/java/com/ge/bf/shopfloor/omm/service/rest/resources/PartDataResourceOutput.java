/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.resources;

import java.sql.Timestamp;

import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.core.Relation;

import com.fasterxml.jackson.annotation.JsonInclude;

@Relation(collectionRelation = "partData")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartDataResourceOutput extends ResourceSupport {
  private String partCode;
  private String partDesc;
  private String createUser;
  private String updateUser;
  private Timestamp createDate;
  private Timestamp updateDate;

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (!super.equals(obj)) {
      return false;
    }
    if (!(obj instanceof PartDataResourceOutput)) {
      return false;
    }
    PartDataResourceOutput other = (PartDataResourceOutput)obj;
    if (partCode == null) {
      if (other.partCode != null) {
        return false;
      }
    } else if (!partCode.equals(other.partCode)) {
      return false;
    }
    return true;
  }

  public Timestamp getCreateDate() {
    return (Timestamp)createDate.clone();
  }

  public String getCreateUser() {
    return createUser;
  }

  public String getPartCode() {
    return partCode;
  }

  public String getPartDesc() {
    return partDesc;
  }

  public Timestamp getUpdateDate() {
    return (Timestamp)updateDate.clone();
  }

  public String getUpdateUser() {
    return updateUser;
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ((partCode == null) ? 0 : partCode.hashCode());
    return result;
  }

  public void setCreateDate(Timestamp createDate) {
    this.createDate = (Timestamp)createDate.clone();
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public void setPartCode(String partCode) {
    this.partCode = partCode;
  }

  public void setPartDesc(String partDesc) {
    this.partDesc = partDesc;
  }

  public void setUpdateDate(Timestamp updateDate) {
    this.updateDate = (Timestamp)updateDate.clone();
  }

  public void setUpdateUser(String updateUser) {
    this.updateUser = updateUser;
  }

}
