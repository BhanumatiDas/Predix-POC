/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ge.bf.shopfloor.omm.service.entity.PartData;
import com.ge.bf.shopfloor.omm.service.exception.PartDataServiceException;

public interface PartDataRepository extends JpaRepository<PartData, String> {
  PartData findById(@Param("id") String id);

  @Query("SELECT pd FROM PartData pd" + " WHERE pd.partCode = :partCode")
  PartData getPartDataByCode(@Param("partCode") String partCode) throws PartDataServiceException;

}
