/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.entity;

import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.hateoas.Identifiable;

import com.ge.bf.shopfloor.omm.service.rest.util.ResourcesUtils;

@Entity
@Table(name = "workgroup", schema = "omm")
public class WorkGroupData implements Identifiable<String> {

  @Id
  @Column(name = "workGroup_id")
  private String id;
  @Column(name = "workGroup_code")
  private String workGroupCode;
  @Column(name = "workGroup_desc")
  private String workGroupDesc;
  @Column(name = "active_flag")
  private String activeFlag;
  @Column(name = "created_by")
  private String createdBy;
  @Column(name = "created_date")
  private Timestamp createdDate;
  @Column(name = "updated_by")
  private String updatedBy;
  @Column(name = "updated_date")
  private Timestamp updatedDate;

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Timestamp getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public Timestamp getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Timestamp updatedDate) {
    this.updatedDate = updatedDate;
  }

  @Override
  public String getId() {
    return id;
  }

  public String getWorkGroupCode() {
    return workGroupCode;
  }

  public String getWorkGroupDesc() {
    return workGroupDesc;
  }

  public String getActiveFlag() {
    return activeFlag;
  }

  @PrePersist
  void onCreate() {
    this.setId(UUID.randomUUID().toString());
    this.setCreatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setCreatedBy("internal");
  }

  @PreUpdate
  void onUpdate() {
    this.setUpdatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setUpdatedBy("internal");
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setWorkGroupCode(String workGroupCode) {
    this.workGroupCode = workGroupCode;
  }

  public void setWorkGroupDesc(String workGroupDesc) {
    this.workGroupDesc = workGroupDesc;
  }

  public void setActiveFlag(String activeFlag) {
    this.activeFlag = activeFlag;
  }

}
