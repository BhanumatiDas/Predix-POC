/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.bf.shopfloor.omm.service.ITaskDataService;
import com.ge.bf.shopfloor.omm.service.TenantContextProvider;
import com.ge.bf.shopfloor.omm.service.entity.Task;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.TaskDataServiceException;
import com.ge.bf.shopfloor.omm.service.rest.assembler.TaskDataResourceAssembler;
import com.ge.bf.shopfloor.omm.service.rest.resources.TaskDataResourceOutput;

/**
 *
 * @author BD470389
 *
 */
@Controller
@RequestMapping(value = "/omm/v1/tasks", produces = { MediaTypes.HAL_JSON_VALUE })
public class TaskDataController {

  private static final Logger LOGGER = LoggerFactory.getLogger(TaskDataController.class);

  @Autowired
  private ITaskDataService iTaskDataService;

  @Autowired
  private TenantContextProvider tenantContextProvider;

  /**
   *
   * @param taskDataResource
   * @return
   * @throws TaskDataServiceException
   */
  private Task buildTaskData(TaskDataResourceOutput taskDataResource) throws TaskDataServiceException {
    Task task = new Task();
    BeanUtils.copyProperties(taskDataResource, task);
    return task;
  }

  /**
   *
   * @param taskDataResourceInput
   * @return
   * @throws TaskDataServiceException
   */
  @RequestMapping(method = POST, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<TaskDataResourceOutput> createTaskData(@RequestBody TaskDataResourceOutput taskDataResourceInput)
      throws TaskDataServiceException {

    /*
     * String tenantId = tenantContextProvider.getTenantId(); if (tenantId ==
     * null) { throw new MissingTenantIdException(NO_TENANT_ID); }
     */

    Task task = buildTaskData(taskDataResourceInput);
    Task newTaskData = iTaskDataService.createTaskData(task);
    TaskDataResourceAssembler assembler = new TaskDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(newTaskData), CREATED);
  }

  /**
   *
   * @return
   * @throws TaskDataServiceException
   */
  @RequestMapping(value = "/all", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<TaskDataResourceOutput>> getAllTaskData() throws TaskDataServiceException {

    try {

      List<Task> task = iTaskDataService.getTaskDataSet();

      if (CollectionUtils.isEmpty(task)) {
        return new ResponseEntity<>(NO_CONTENT);
      }

      TaskDataResourceAssembler assembler = new TaskDataResourceAssembler();
      List<TaskDataResourceOutput> taskDataResource = assembler.toResources(task);

      return new ResponseEntity<>(taskDataResource, OK);
    } catch (Exception e) {
      throw new TaskDataServiceException(ErrorMessage.TASKDATA_RETRIEVAL_FAILURE, e);
    }
  }

  /**
   *
   * @param operationCode
   * @return
   * @throws TaskDataServiceException
   */
  @RequestMapping(value = "/operationCode/{operationCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<TaskDataResourceOutput>> getTaskByOperationCode(
      @PathVariable("operationCode") String operationCode) throws TaskDataServiceException {

    List<Task> taskList = isValidTaskByOperationCode(operationCode);

    TaskDataResourceAssembler assembler = new TaskDataResourceAssembler();
    List<TaskDataResourceOutput> taskDataResource = assembler.toResources(taskList);

    return new ResponseEntity<>(taskDataResource, OK);

  }

  /**
   *
   * @param taskCode
   * @return
   * @throws TaskDataServiceException
   */
  @RequestMapping(value = "/taskCode/{taskCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<TaskDataResourceOutput> getTaskDataByCode(@PathVariable("taskCode") String taskCode)
      throws TaskDataServiceException {

    Task task = isValidTaskByCode(taskCode);

    TaskDataResourceAssembler assembler = new TaskDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(task), OK);

  }

  /**
   *
   * @param id
   * @return
   * @throws TaskDataServiceException
   */
  @RequestMapping(value = "/id/{id}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<TaskDataResourceOutput> getTaskDataById(@PathVariable("id") String id)
      throws TaskDataServiceException {

    Task task = isValidTaskData(id);

    TaskDataResourceAssembler assembler = new TaskDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(task), OK);
  }

  /**
   *
   * @param taskCode
   * @return
   * @throws TaskDataServiceException
   */
  private Task isValidTaskByCode(String taskCode) throws TaskDataServiceException {
    Task task = iTaskDataService.getTaskByCode(taskCode);
    if (task == null) {
      throw new TaskDataServiceException(ErrorMessage.NONEXISTANT_TASKDATA);
    }
    return task;
  }

  /**
   *
   * @param operationCode
   * @return
   * @throws TaskDataServiceException
   */
  private List<Task> isValidTaskByOperationCode(String operationCode) throws TaskDataServiceException {
    List<Task> taskList = iTaskDataService.getTasksByOperationCode(operationCode);

    if (taskList == null || taskList.size() == 0) {
      throw new TaskDataServiceException(ErrorMessage.NONEXISTANT_TASKDATA);
    }
    return taskList;
  }

  /**
   *
   * @param taskId
   * @return
   * @throws TaskDataServiceException
   */
  private Task isValidTaskData(String taskId) throws TaskDataServiceException {
    Task task = iTaskDataService.getTaskById(taskId);
    if (task == null) {
      throw new TaskDataServiceException(ErrorMessage.NONEXISTANT_TASKDATA);
    }
    return task;
  }

}
