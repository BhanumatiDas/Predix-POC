/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

public class OperationDataServiceException extends OneManMultipleServiceException {
  public OperationDataServiceException(String message) {
    super(message);
  }

  public OperationDataServiceException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public OperationDataServiceException(Throwable throwable) {
    super(throwable);
  }
}
