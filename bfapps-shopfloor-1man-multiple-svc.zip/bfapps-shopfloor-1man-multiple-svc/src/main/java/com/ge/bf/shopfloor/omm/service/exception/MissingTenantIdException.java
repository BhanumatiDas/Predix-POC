/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

/**
 * Exception class for request made without using the tenant id.
 *
 * @author 212556687
 */
public class MissingTenantIdException extends OneManMultipleServiceException {

  public MissingTenantIdException(String message) {
    super(message);
  }

  public MissingTenantIdException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public MissingTenantIdException(Throwable throwable) {
    super(throwable);
  }

}
