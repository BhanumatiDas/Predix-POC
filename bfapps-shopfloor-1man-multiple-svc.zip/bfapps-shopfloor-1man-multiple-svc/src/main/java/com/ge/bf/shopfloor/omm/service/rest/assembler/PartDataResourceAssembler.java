/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.assembler;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

import com.ge.bf.shopfloor.omm.service.entity.PartData;
import com.ge.bf.shopfloor.omm.service.rest.controller.PartDataController;
import com.ge.bf.shopfloor.omm.service.rest.resources.PartDataResourceOutput;

/**
 * 
 * @author 221032148
 *
 */
public class PartDataResourceAssembler extends ResourceAssemblerSupport<PartData, PartDataResourceOutput> {

  public PartDataResourceAssembler() {
    super(PartDataController.class, PartDataResourceOutput.class);
  }

  @Override
  public PartDataResourceOutput toResource(PartData partData) {

    PartDataResourceOutput resource;

    resource = createResourceWithId("id/" + partData.getId(), partData);

    BeanUtils.copyProperties(partData, resource);
    return resource;
  }
}
