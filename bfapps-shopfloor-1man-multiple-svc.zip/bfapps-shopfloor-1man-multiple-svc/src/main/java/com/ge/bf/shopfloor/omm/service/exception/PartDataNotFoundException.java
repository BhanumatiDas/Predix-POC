/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

/**
 * Exception for non existent work orders.
 *
 * @author 212556687
 */
public class PartDataNotFoundException extends PartDataServiceException {

  public PartDataNotFoundException(String message) {
    super(message);
  }

  public PartDataNotFoundException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public PartDataNotFoundException(Throwable throwable) {
    super(throwable);
  }

}
