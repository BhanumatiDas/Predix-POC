/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.ITaskDataService;
import com.ge.bf.shopfloor.omm.service.entity.Task;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.TaskDataServiceException;
import com.ge.bf.shopfloor.omm.service.repository.TaskRepository;

@Component
public class TaskDataServiceImpl implements ITaskDataService {
  private static final Logger LOGGER = LoggerFactory.getLogger(TaskDataServiceImpl.class);

  @Autowired
  private TaskRepository taskRepository;

  @Override
  public List<Task> createTaskData(List<Task> task) throws TaskDataServiceException {
    List<Task> currentSet;
    try {
      currentSet = taskRepository.save(task);
    } catch (Exception e) {
      throw new TaskDataServiceException("Error creating Task Data", e);
    }
    return currentSet;
  }

  @Override
  public Task createTaskData(Task task) throws TaskDataServiceException {
    Task current;
    try {
      current = taskRepository.save(task);
      LOGGER.debug("Task Data created: " + current.getId());
    } catch (Exception e) {
      throw new TaskDataServiceException("Error creating Task Data", e);
    }
    return current;
  }

  @Override
  public Task getTaskByCode(String taskCode) throws TaskDataServiceException {
    if (taskCode == null || taskCode.trim().length() == 0) {
      throw new TaskDataServiceException(ErrorMessage.NO_TASK_CODE);
    }
    Task taskData;
    try {
      if (taskCode.matches("[0-9.]*")) {
        taskData = taskRepository.getTaskByCode(String.valueOf(Float.valueOf(taskCode).intValue()));
      } else {
        taskData = taskRepository.getTaskByCode(taskCode);
      }
    } catch (Exception e) {
      throw new TaskDataServiceException("Error fetching Task Data by Task Code", e);
    }
    return taskData;
  }

  @Override
  public Task getTaskById(String taskId) {
    return taskRepository.findById(taskId);
  }

  @Override
  public List<Task> getTaskDataSet() throws TaskDataServiceException {
    List<Task> taskSet;
    try {
      taskSet = taskRepository.findAll();
    } catch (Exception e) {
      throw new TaskDataServiceException("Error fetching Task Data", e);
    }
    return taskSet;
  }

  @Override
  public List<Task> getTasksByOperationCode(String operationCode) throws TaskDataServiceException {
    if (operationCode == null || operationCode.trim().length() == 0) {
      throw new TaskDataServiceException(ErrorMessage.NO_OPERATION_CODE);
    }
    List<Task> taskSet;
    try {
      taskSet = taskRepository.findTasksByOperationCode(operationCode);
    } catch (Exception e) {
      throw new TaskDataServiceException("Error fetching Task Data by Operation Code", e);
    }
    return taskSet;
  }
}
