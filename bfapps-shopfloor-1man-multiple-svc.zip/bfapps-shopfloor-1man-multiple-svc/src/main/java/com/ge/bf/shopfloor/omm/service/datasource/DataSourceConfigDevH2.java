/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.datasource;

import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.sql.DataSource;

import org.flywaydb.core.Flyway;
import org.h2.server.web.WebServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.JpaTransactionManager;

@Configuration
@Profile({ "default" })
public class DataSourceConfigDevH2 {

  @Bean(destroyMethod = "shutdown")
  public DataSource dataSource() {
    return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.H2).build();
  }

  @Bean
  @Autowired
  public EntityManager entityManager(EntityManagerFactory entityManagerFactory) {
    return entityManagerFactory.createEntityManager();
  }

  @Bean
  @DependsOn("flyway")
  public EntityManagerFactory entityManagerFactory() {
    Properties jpaProps = new Properties();
    jpaProps.put("openjpa.ConnectionFactory", dataSource());
    jpaProps.put("openjpa.Log", "log4j");
    jpaProps.put("openjpa.ConnectionFactoryProperties", "true");
    return Persistence.createEntityManagerFactory("OMMPersistenceUnit", jpaProps);
  }

  /**
   * http://blog.trifork.com/2014/12/09/integrating-flywaydb-in-a-spring-framework-application/
   * .
   *
   * @return
   */
  @Bean(initMethod = "migrate")
  Flyway flyway() {
    Flyway flyway = new Flyway();
    flyway.setSchemas("OMM");
    flyway.setLocations("classpath:db/migration/h2");
    flyway.setBaselineOnMigrate(true);
    flyway.setDataSource(dataSource());
    return flyway;
  }

  /**
   * 
   * .
   *
   * @return
   */
  @Bean
  public ServletRegistrationBean h2servletRegistration() {
    ServletRegistrationBean registration = new ServletRegistrationBean(new WebServlet());
    registration.addUrlMappings("/console/*");
    registration.addInitParameter("webAllowOthers", "true");
    return registration;
  }

  @Bean
  @Autowired
  public JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
    JpaTransactionManager txManager = new JpaTransactionManager();
    txManager.setEntityManagerFactory(entityManagerFactory);

    return txManager;
  }
}
