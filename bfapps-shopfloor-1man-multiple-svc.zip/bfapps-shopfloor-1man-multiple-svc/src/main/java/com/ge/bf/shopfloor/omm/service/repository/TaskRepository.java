/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ge.bf.shopfloor.omm.service.entity.Task;
import com.ge.bf.shopfloor.omm.service.exception.TaskDataServiceException;

public interface TaskRepository extends JpaRepository<Task, String> {

  Task findById(@Param("id") String id);

  @Query("SELECT t FROM Task t " + " WHERE t.operationCode = :operationCode")
  List<Task> findTasksByOperationCode(@Param("operationCode") String operationCode) throws TaskDataServiceException;

  @Query("SELECT t FROM Task t " + " WHERE t.taskCode = :taskCode")
  Task getTaskByCode(@Param("taskCode") String taskCode) throws TaskDataServiceException;

  @Query("SELECT T FROM Task T WHERE t.flag = 'N' or t.flag is null ")
  List<Task> findAllValidTasks() throws TaskDataServiceException;

}
