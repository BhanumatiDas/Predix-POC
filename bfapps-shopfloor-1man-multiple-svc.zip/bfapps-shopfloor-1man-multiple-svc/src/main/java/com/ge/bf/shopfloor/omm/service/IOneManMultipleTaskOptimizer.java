/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

import java.util.List;

import com.ge.bf.shopfloor.omm.service.exception.OneManMultipleServiceException;
import com.ge.bf.shopfloor.omm.service.util.TaskWrapper;

/**
 * @author 221032148
 *
 */
public interface IOneManMultipleTaskOptimizer {

  List<TaskWrapper> generateTaskOptimization(String workGroup) throws OneManMultipleServiceException;

  // List<String> generateTaskOptimization(String workGroup) throws
  // OneManMultipleServiceException;

  void reGenerateTaskOptimization() throws OneManMultipleServiceException;

}
