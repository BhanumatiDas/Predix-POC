/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.datasource;

import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.sql.DataSource;

import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Profile;
import org.springframework.orm.jpa.JpaTransactionManager;

@Configuration
@Profile("localPostgres")
public class DataSourceConfigDevPostgres {
  @Bean
  public DataSource dataSource() {
    org.apache.tomcat.jdbc.pool.DataSource dataSource = new org.apache.tomcat.jdbc.pool.DataSource();
    dataSource.setDriverClassName("org.postgresql.Driver");
    dataSource.setUrl("jdbc:postgresql://3.60.6.196:5432/shopfloor");
    dataSource.setUsername("omm-dev");
    dataSource.setPassword("Omm123#");
    return dataSource;
  }

  @Bean
  @Autowired
  public EntityManager entityManager(EntityManagerFactory entityManagerFactory) {
    return entityManagerFactory.createEntityManager();
  }

  @Bean
  @DependsOn("flyway")
  public EntityManagerFactory entityManagerFactory() {
    Properties jpaProps = new Properties();
    jpaProps.put("openjpa.ConnectionFactory", dataSource());
    jpaProps.put("openjpa.Log", "log4j");
    jpaProps.put("openjpa.ConnectionFactoryProperties", "true");
    return Persistence.createEntityManagerFactory("OMMPersistenceUnitPostgres", jpaProps);
  }

  /**
   * http://blog.trifork.com/2014/12/09/integrating-flywaydb-in-a-spring-framework-application/
   * .
   *
   * @return
   */
  @Bean(initMethod = "migrate")
  Flyway flyway() {
    Flyway flyway = new Flyway();
    flyway.setSchemas("omm");
    flyway.setLocations("classpath:db/migration/pg");
    flyway.setBaselineOnMigrate(true);
    flyway.setDataSource(dataSource());
    return flyway;
  }

  @Bean
  @Autowired
  public JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
    JpaTransactionManager txManager = new JpaTransactionManager();
    txManager.setEntityManagerFactory(entityManagerFactory);

    return txManager;
  }
}
