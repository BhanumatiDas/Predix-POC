/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

public interface ErrorMessage {
  /* Fake data Exceptions */
  String FAKEDATA_RETRIEVAL_FAILURE = "The system cannot retrieve the fake data. Try again.";
  String NONEXISTANT_FAKEDATA = "The fake data you requested do not exist.";

  /* Tenant Management Exceptions */ String NO_TENANT_ID = "Could not determine tenant ID.";
  String INVALID_SCOPE = "Invalid scope.";

  String MACHINEDATA_RETRIEVAL_FAILURE = "The system cannot retrieve the machine data. Try again.";
  String NONEXISTANT_MACHINEDATA = "The machine data you requested do not exist.";

  String WORKGROUPDATA_RETRIEVAL_FAILURE = "The system cannot retrieve the workgroup data. Try again.";
  String NONEXISTANT_WORKGROUPDATA = "The workgroup data you requested do not exist.";
  String INACTIVE_WORKGROUPDATA = "The workgroup is inactive.";

  String NONEXISTANT_TASKDATA = "The task data you requested does not exist.";
  String TASKDATA_RETRIEVAL_FAILURE = "The system cannot retrieve the task data. Try again.";

  String PARTDATA_RETRIEVAL_FAILURE = "The system cannot retrieve the part data. Try again.";
  String NONEXISTANT_PARTDATA = "The part data you requested do not exist.";
  String NO_PART_CODE = "Failed to upload the file.Part Code can not be null or empty.";

  String NO_TASK_SEQUENCE = "Failed to upload the file.Task Sequence can not be null or empty.";
  String NO_OPERATION_CODE = "Failed to upload the file.Operation Code can not be null or empty.";
  String NO_TASK_CODE = "Failed to upload the file.Task Code can not be null or empty.";
  String NO_MACHINE_CODE = "Failed to upload the file.Machine Code can not be null or empty.";
  String NO_WORKGROUP_CODE = "Failed to upload the file.Workgroup Code can not be null or empty.";
  String NO_PLANT_CODE = "Failed to upload the file.Plat Code can not be null or empty.";

  String NONEXISTANT_OPERATIONDATA = "The operation data you requested does not exist.";
  String OPERATIONDATA_RETRIEVAL_FAILURE = "The system cannot retrieve the operation data. Try again.";

  String NONEXISTANT_SCHEDULEDATA = "The schedule data you requested does not exist.";
  String SCHEDULEDATA_RETRIEVAL_FAILURE = "The system cannot retrieve the schedule data. Try again.";
  String SCHEDULEDATA_UPDATE_FAILURE = "Failed to update the schedule data.";
  String SCHEDULEDATA_DELETE_FAILURE = "Failed to delete the schedule data.";

}
