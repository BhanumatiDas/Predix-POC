/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.bf.shopfloor.omm.service.IOperationDataService;
import com.ge.bf.shopfloor.omm.service.TenantContextProvider;
import com.ge.bf.shopfloor.omm.service.entity.Operation;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.OperationDataServiceException;
import com.ge.bf.shopfloor.omm.service.rest.assembler.OperationDataResourceAssembler;
import com.ge.bf.shopfloor.omm.service.rest.resources.OperationDataResourceOutput;

/**
 *
 * @author BD470389
 *
 */
@Controller
@RequestMapping(value = "/omm/v1/operations", produces = { MediaTypes.HAL_JSON_VALUE })
public class OperationDataController {
	private static final Logger LOGGER = LoggerFactory.getLogger(OperationDataController.class);

	@Autowired
	private IOperationDataService iOperationDataService;

	@Autowired
	private TenantContextProvider tenantContextProvider;

	/**
	 * 
	 * @param operationDataResource
	 * @return
	 * @throws OperationDataServiceException
	 */
	private Operation buildOperationData(OperationDataResourceOutput operationDataResource)
			throws OperationDataServiceException {
		Operation operation = new Operation();
		BeanUtils.copyProperties(operationDataResource, operation);
		return operation;
	}

	/**
	 * 
	 * @param operationDataResourceInput
	 * @return
	 * @throws OperationDataServiceException
	 */
	@RequestMapping(method = POST, produces = { MediaTypes.HAL_JSON_VALUE })
	@ResponseBody
	public HttpEntity<OperationDataResourceOutput> createOperationData(
			@RequestBody OperationDataResourceOutput operationDataResourceInput) throws OperationDataServiceException {

		/*
		 * String tenantId = tenantContextProvider.getTenantId(); if (tenantId
		 * == null) { throw new MissingTenantIdException(NO_TENANT_ID); }
		 */

		Operation operation = buildOperationData(operationDataResourceInput);
		Operation newOperationData = iOperationDataService.createOperation(operation);
		OperationDataResourceAssembler assembler = new OperationDataResourceAssembler();
		return new ResponseEntity<>(assembler.toResource(newOperationData), CREATED);
	}

	/**
	 *
	 * @return
	 * @throws OperationDataServiceException
	 */
	@RequestMapping(value = "/all", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
	@ResponseBody
	public HttpEntity<List<OperationDataResourceOutput>> getAllOperationData() throws OperationDataServiceException {

		try {

			List<Operation> operation = iOperationDataService.getOperationDataSet();

			if (CollectionUtils.isEmpty(operation)) {
				return new ResponseEntity<>(NO_CONTENT);
			}

			OperationDataResourceAssembler assembler = new OperationDataResourceAssembler();
			List<OperationDataResourceOutput> operationDataResource = assembler.toResources(operation);

			return new ResponseEntity<>(operationDataResource, OK);
		} catch (Exception e) {
			throw new OperationDataServiceException(ErrorMessage.OPERATIONDATA_RETRIEVAL_FAILURE, e);
		}
	}

	/**
	 *
	 * @param operationCode
	 * @return
	 * @throws OperationDataServiceException
	 */
	@RequestMapping(value = "/operationCode/{operationCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
	@ResponseBody
	public HttpEntity<OperationDataResourceOutput> getOperationByOperationCode(
			@PathVariable("operationCode") String operationCode) throws OperationDataServiceException {

		Operation operation = isValidOperationByOperationCode(operationCode);

		OperationDataResourceAssembler assembler = new OperationDataResourceAssembler();
		return new ResponseEntity<>(assembler.toResource(operation), OK);

	}

	/**
	 * 
	 * @param id
	 * @return
	 * @throws OperationDataServiceException
	 */
	@RequestMapping(value = "/id/{id}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
	@ResponseBody
	public HttpEntity<OperationDataResourceOutput> getOperationDataById(@PathVariable("id") String id)
			throws OperationDataServiceException {

		Operation operation = isValidOperationData(id);

		OperationDataResourceAssembler assembler = new OperationDataResourceAssembler();
		return new ResponseEntity<>(assembler.toResource(operation), OK);
	}

	/**
	 *
	 * @param machineCode
	 * @return
	 * @throws OperationDataServiceException
	 */
	@RequestMapping(value = "/machineCode/{machineCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
	@ResponseBody
	public HttpEntity<List<OperationDataResourceOutput>> getOperationsByMacineCode(
			@PathVariable("machineCode") String machineCode) throws OperationDataServiceException {

		List<Operation> operationList = isValidOperationByMachineCode(machineCode);

		OperationDataResourceAssembler assembler = new OperationDataResourceAssembler();
		List<OperationDataResourceOutput> operationDataResource = assembler.toResources(operationList);

		return new ResponseEntity<>(operationDataResource, OK);

	}

	/**
	 *
	 * @param workGroupCode
	 * @return
	 * @throws OperationDataServiceException
	 */
	@RequestMapping(value = "/workGroupCode/{workGroupCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
	@ResponseBody
	public HttpEntity<List<OperationDataResourceOutput>> getOperationsByWorkGroup(
			@PathVariable("workGroupCode") String workGroupCode) throws OperationDataServiceException {

		List<Operation> operationList = isValidOperationByWorkGroup(workGroupCode);

		OperationDataResourceAssembler assembler = new OperationDataResourceAssembler();
		List<OperationDataResourceOutput> operationDataResource = assembler.toResources(operationList);

		return new ResponseEntity<>(operationDataResource, OK);

	}

	/**
	 *
	 * @param machineCode
	 * @return
	 * @throws OperationDataServiceException
	 */
	private List<Operation> isValidOperationByMachineCode(String machineCode) throws OperationDataServiceException {
		List<Operation> operationList = iOperationDataService.getOperationsByMacineCode(machineCode);

		if (operationList == null || operationList.size() == 0) {
			throw new OperationDataServiceException(ErrorMessage.NONEXISTANT_OPERATIONDATA);
		}
		return operationList;
	}

	/**
	 *
	 * @param operationCode
	 * @return
	 * @throws OperationDataServiceException
	 */
	private Operation isValidOperationByOperationCode(String operationCode) throws OperationDataServiceException {
		Operation operation = iOperationDataService.getOperationDataByCode(operationCode);

		if (operation == null) {
			throw new OperationDataServiceException(ErrorMessage.NONEXISTANT_OPERATIONDATA);
		}
		return operation;
	}

	/**
	 *
	 * @param workGroupCode
	 * @return
	 * @throws OperationDataServiceException
	 */
	private List<Operation> isValidOperationByWorkGroup(String workGroupCode) throws OperationDataServiceException {
		List<Operation> operationList = iOperationDataService.findValidOperationByWorkGroup(workGroupCode);

		if (operationList == null || operationList.size() == 0) {
			throw new OperationDataServiceException(ErrorMessage.NONEXISTANT_OPERATIONDATA);
		}
		return operationList;
	}

	/**
	 *
	 * @param operationId
	 * @return
	 * @throws OperationDataServiceException
	 */
	private Operation isValidOperationData(String operationId) throws OperationDataServiceException {
		Operation operation = iOperationDataService.getOperationDataById(operationId);
		if (operation == null) {
			throw new OperationDataServiceException(ErrorMessage.NONEXISTANT_OPERATIONDATA);
		}
		return operation;
	}
}
