/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IWorkGroupDataService;
import com.ge.bf.shopfloor.omm.service.entity.WorkGroupData;
import com.ge.bf.shopfloor.omm.service.exception.WorkGroupDataServiceException;
import com.ge.bf.shopfloor.omm.service.repository.WorkGroupDataRepository;

@Component
public class WorkGroupDataServiceImpl implements IWorkGroupDataService {
  private static final Logger LOGGER = LoggerFactory.getLogger(WorkGroupDataServiceImpl.class);

  @Autowired
  private WorkGroupDataRepository workGroupDataRepository;

  @Override
  public List<WorkGroupData> createWorkGroupData(List<WorkGroupData> workGroupData)
      throws WorkGroupDataServiceException {
    List<WorkGroupData> currentSet;
    try {
      currentSet = workGroupDataRepository.save(workGroupData);
      // LOGGER.debug("WorkGroupData created: " + currentSet.getId());
    } catch (Exception e) {
      throw new WorkGroupDataServiceException("Error creating work group data", e);
    }
    return currentSet;
  }

  @Override
  public WorkGroupData createWorkGroupData(WorkGroupData workGroupData) throws WorkGroupDataServiceException {
    WorkGroupData current;
    try {
      current = workGroupDataRepository.save(workGroupData);
      LOGGER.debug("WorkGroupData created: " + current.getId());
    } catch (Exception e) {
      throw new WorkGroupDataServiceException("Error creating work group data", e);
    }
    return current;
  }

  @Override
  public WorkGroupData getWorkGroupData(String workGroupDataId) {
    return workGroupDataRepository.findById(workGroupDataId);
  }

  @Override
  public List<WorkGroupData> getWorkGroupDataByCode(String workGroupCode) throws WorkGroupDataServiceException {
    if (workGroupCode == null || workGroupCode.trim().length() == 0) {
      throw new WorkGroupDataServiceException("Work Group Code Id Cannot  be null or empty");
    }
    List<WorkGroupData> workGroupDataSet;
    try {
      workGroupDataSet = workGroupDataRepository.getWorkGroupDataByCode(workGroupCode);
    } catch (Exception e) {
      throw new WorkGroupDataServiceException("Error fetching Work Group Data by Work Group Code", e);
    }
    return workGroupDataSet;

  }

  @Override
  public List<WorkGroupData> getWorkGroupDataSet() throws WorkGroupDataServiceException {

    List<WorkGroupData> workGroupDataSet;
    try {
      workGroupDataSet = workGroupDataRepository.findAll();
    } catch (Exception e) {
      throw new WorkGroupDataServiceException("Error fetching Work Group Data ", e);
    }
    return workGroupDataSet;
  }

}
