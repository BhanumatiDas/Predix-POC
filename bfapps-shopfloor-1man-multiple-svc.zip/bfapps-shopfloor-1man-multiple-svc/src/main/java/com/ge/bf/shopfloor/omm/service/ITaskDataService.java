/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

import java.util.List;

import com.ge.bf.shopfloor.omm.service.entity.Task;
import com.ge.bf.shopfloor.omm.service.exception.TaskDataServiceException;

/**
 * 
 * @author 221032148
 *
 */
public interface ITaskDataService {

  List<Task> createTaskData(List<Task> taskData) throws TaskDataServiceException;

  Task createTaskData(Task taskData) throws TaskDataServiceException;

  List<Task> getTasksByOperationCode(String operationCode) throws TaskDataServiceException;

  Task getTaskByCode(String taskCode) throws TaskDataServiceException;

  List<Task> getTaskDataSet() throws TaskDataServiceException;

  Task getTaskById(String taskId) throws TaskDataServiceException;
}
