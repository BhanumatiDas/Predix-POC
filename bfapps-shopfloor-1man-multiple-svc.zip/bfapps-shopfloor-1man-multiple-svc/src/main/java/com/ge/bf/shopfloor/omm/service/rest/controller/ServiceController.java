/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.hateoas.Link;
import org.springframework.hateoas.MediaTypes;
import org.springframework.hateoas.ResourceSupport;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/v1", produces = { MediaTypes.HAL_JSON_VALUE })
@CrossOrigin
public class ServiceController {
  @RequestMapping(value = "/", method = RequestMethod.GET)
  public HttpEntity<ResourceSupport> service(HttpServletRequest request) {
    ResourceSupport service = new ResourceSupport();
    service.add(new Link(request.getRequestURL() + "lines", "lines"));
    return new ResponseEntity<>(service, HttpStatus.OK);
  }
}
