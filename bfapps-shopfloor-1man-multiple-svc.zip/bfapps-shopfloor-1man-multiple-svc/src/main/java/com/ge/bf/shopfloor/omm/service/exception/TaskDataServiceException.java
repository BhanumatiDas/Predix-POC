/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

public class TaskDataServiceException extends OneManMultipleServiceException {
  public TaskDataServiceException(String message) {
    super(message);
  }

  public TaskDataServiceException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public TaskDataServiceException(Throwable throwable) {
    super(throwable);
  }
}
