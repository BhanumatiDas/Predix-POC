/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.entity;

import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.hateoas.Identifiable;

import com.ge.bf.shopfloor.omm.service.rest.util.ResourcesUtils;

@Entity
@Table(name = "machine", schema = "omm")
public class MachineData implements Identifiable<String> {

  @Id
  @Column(name = "machine_id")
  private String id;
  @Column(name = "machine_code")
  private String machineCode;
  @Column(name = "machine_desc")
  private String machineDesc;
  @Column(name = "machine_color")
  private String machineColor;
  @Column(name = "workgroup_code")
  private String workgroupCode;
  @Column(name = "plant_code")
  private String plantCode;
  @Column(name = "part_code")
  private String partCode;
  @Column(name = "created_by")
  private String createdBy;
  @Column(name = "updated_by")
  private String updatedBy;
  @Column(name = "created_date")
  private Timestamp createdDate;
  @Column(name = "updated_date")
  private Timestamp updatedDate;

  public String getCreatedBy() {
    return createdBy;
  }

  public Timestamp getCreatedDate() {
    return createdDate;
  }

  @Override
  public String getId() {
    return id;
  }

  public String getMachineCode() {
    return machineCode;
  }

  public String getMachineColor() {
    return machineColor;
  }

  public String getMachineDesc() {
    return machineDesc;
  }

  public String getPartCode() {
    return partCode;
  }

  public void setPartCode(String partCode) {
    this.partCode = partCode;
  }

  public String getPlantCode() {
    return plantCode;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public Timestamp getUpdatedDate() {
    return updatedDate;
  }

  public String getWorkgroupCode() {
    return workgroupCode;
  }

  @PrePersist
  void onCreate() {
    this.setId(UUID.randomUUID().toString());
    this.setCreatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setCreatedBy("internal");
  }

  @PreUpdate
  void onUpdate() {
    this.setUpdatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setUpdatedBy("internal");
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = createdDate;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setMachineCode(String machineCode) {
    this.machineCode = machineCode;
  }

  public void setMachineColor(String machineColor) {
    this.machineColor = machineColor;
  }

  public void setMachineDesc(String machineDesc) {
    this.machineDesc = machineDesc;
  }

  /**
   * @param plantCode
   *          the plantCode to set
   */
  public void setPlantCode(String plantCode) {
    this.plantCode = plantCode;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public void setUpdatedDate(Timestamp updatedDate) {
    this.updatedDate = updatedDate;
  }

  public void setWorkgroupCode(String workgroupCode) {
    this.workgroupCode = workgroupCode;
  }
}
