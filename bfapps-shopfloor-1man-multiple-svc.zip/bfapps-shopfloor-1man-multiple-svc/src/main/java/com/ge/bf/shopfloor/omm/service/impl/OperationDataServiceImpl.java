/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IOperationDataService;
import com.ge.bf.shopfloor.omm.service.entity.Operation;
import com.ge.bf.shopfloor.omm.service.exception.OperationDataServiceException;
import com.ge.bf.shopfloor.omm.service.repository.OperationRepository;

@Component
public class OperationDataServiceImpl implements IOperationDataService {
  private static final Logger LOGGER = LoggerFactory.getLogger(OperationDataServiceImpl.class);

  @Autowired
  private OperationRepository operationRepository;

  @Override
  public List<Operation> createOperation(List<Operation> operationData) throws OperationDataServiceException {
    List<Operation> currentSet;
    try {
      currentSet = operationRepository.save(operationData);
    } catch (Exception e) {
      throw new OperationDataServiceException("Error creating Operation Data", e);
    }
    return currentSet;
  }

  @Override
  public Operation createOperation(Operation operationData) throws OperationDataServiceException {
    Operation current;
    try {
      current = operationRepository.save(operationData);
      LOGGER.debug("Operation Data created: " + current.getId());
    } catch (Exception e) {
      throw new OperationDataServiceException("Error creating Operation Data", e);
    }
    return current;
  }

  /**
   *
   */
  @Override
  public List<Operation> findValidOperationByWorkGroup(String workgroupCode) throws OperationDataServiceException {

    if (workgroupCode == null || workgroupCode.trim().length() == 0) {
      throw new OperationDataServiceException("WorkGroup Code Cannot  be null or empty");
    }

    List<Operation> operations;
    try {
      operations = operationRepository.findValidOperationByWorkGroup(workgroupCode);
    } catch (Exception e) {
      throw new OperationDataServiceException("Error fetching Operation Data ", e);
    }
    return operations;
  }

  @Override
  public Operation getOperationDataByCode(String operationCode) throws OperationDataServiceException {

    if (operationCode == null || operationCode.trim().length() == 0) {
      throw new OperationDataServiceException("Operation Code Cannot be null or empty");
    }
    Operation operationData;
    try {
      if (operationCode.matches("[0-9.]*")) {
        operationData = operationRepository.getOperationByCode(String.valueOf(Float.valueOf(operationCode).intValue()));
      } else {
        operationData = operationRepository.getOperationByCode(operationCode);
      }

    } catch (Exception e) {
      throw new OperationDataServiceException("Error fetching Task Data by Task Code", e);
    }
    return operationData;
  }

  @Override
  public Operation getOperationDataById(String operationId) {
    return operationRepository.findById(operationId);
  }

  @Override
  public List<Operation> getOperationDataSet() throws OperationDataServiceException {

    List<Operation> operations;
    try {
      operations = operationRepository.findAll();
    } catch (Exception e) {
      throw new OperationDataServiceException("Error fetching Operation Data ", e);
    }
    return operations;

  }

  @Override
  public List<Operation> getOperationsByMacineCode(String machineCode) throws OperationDataServiceException {

    if (machineCode == null || machineCode.trim().length() == 0) {
      throw new OperationDataServiceException("Machine Code Cannot  be null or empty");
    }
    List<Operation> operations;
    try {
      operations = operationRepository.getOperationsByMachineCode(machineCode);
    } catch (Exception e) {
      throw new OperationDataServiceException("Error fetching Machine Data by Machine Code", e);
    }
    return operations;

  }
}
