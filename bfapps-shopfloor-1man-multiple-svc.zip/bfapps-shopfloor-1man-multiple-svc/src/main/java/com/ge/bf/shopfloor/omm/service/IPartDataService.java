/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

import java.util.List;

import com.ge.bf.shopfloor.omm.service.entity.PartData;
import com.ge.bf.shopfloor.omm.service.exception.PartDataServiceException;

public interface IPartDataService {
  List<PartData> createPartData(List<PartData> partData) throws PartDataServiceException;

  PartData createPartData(PartData partData) throws PartDataServiceException;

  PartData getPartData(String partDataId);


  // List<PartData> getPartDataSet(String partDataId); //was String
  // tenantId....changed it to partDataId

  PartData getPartDataByCode(String partCode) throws PartDataServiceException;

  List<PartData> getPartDataSet() throws PartDataServiceException;

}
