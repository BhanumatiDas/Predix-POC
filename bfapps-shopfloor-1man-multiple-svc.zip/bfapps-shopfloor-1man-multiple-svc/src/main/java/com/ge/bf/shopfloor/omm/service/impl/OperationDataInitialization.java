/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IOperationDataService;
import com.ge.bf.shopfloor.omm.service.entity.Operation;
import com.ge.bf.shopfloor.omm.service.exception.DataFormatException;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.OperationDataServiceException;
import com.ge.bf.shopfloor.omm.service.util.IOneManMultipleConstants;

/**
 * @author 221032148
 *
 */
@Component
@SuppressWarnings({ "nls", "unused" })
public class OperationDataInitialization extends AbstractDataInitialization {
  private static final Logger LOGGER = LoggerFactory.getLogger(OperationDataInitialization.class);
  private static final int MACHINE_CODE = 0;
  private static final int OPERATION_CODE = 1;
  private static final int OPERATION_DESC = 2;
  @Autowired
  private IOperationDataService iOperationDataService;

  @Override
  protected String saveData(Map<String, String[][]> content) throws DataFormatException, OperationDataServiceException {
    String[][] operationData = content.get(IOneManMultipleConstants.OPERATION_DATA);
    Operation data = null;
    List<Operation> operationDataSet = new ArrayList<Operation>(10);
    String msg = null;
    if (operationData == null) {
      return "Zero records exists in the Operation worksheet ";
    }
    for (String[] row : operationData) {
      Operation opreation = iOperationDataService.getOperationDataByCode(row[OPERATION_CODE]);
      data = (opreation != null) ? opreation : new Operation();
      // check for Machine Code
      data.setMachineCode(row[MACHINE_CODE]);

      if ((row[OPERATION_CODE] == null) || (row[OPERATION_CODE].trim().length() == 0)) {
        throw new OperationDataServiceException(ErrorMessage.NO_OPERATION_CODE);
      } else {
        if (row[OPERATION_CODE].matches("[0-9.]*")) {
          data.setOperationCode(String.valueOf(Float.valueOf(row[OPERATION_CODE]).intValue()));
        } else {
          data.setOperationCode(row[OPERATION_CODE]);
        }
      }

      if ((row[MACHINE_CODE] == null) || (row[MACHINE_CODE].trim().length() == 0)) {
        throw new OperationDataServiceException(ErrorMessage.NO_MACHINE_CODE);
      } else {
        data.setMachineCode(row[MACHINE_CODE]);
      }

      if ((row[OPERATION_CODE] == null) || (row[OPERATION_CODE].trim().length() == 0)) {
        throw new OperationDataServiceException(ErrorMessage.NO_OPERATION_CODE);
      } else {
        if (row[OPERATION_CODE].matches("[0-9.]*")) {
          data.setOperationCode(String.valueOf(Float.valueOf(row[OPERATION_CODE]).intValue()));
        } else {
          data.setOperationCode(row[OPERATION_CODE]);
        }

      }
      data.setOperationDesc(row[OPERATION_DESC]);
      operationDataSet.add(data);
    }

    if (!operationDataSet.isEmpty()) {
      msg = operationDataSet.size() + " records exists in the Operation Worksheet";
      LOGGER.info(msg);
      iOperationDataService.createOperation(operationDataSet);
    } else {
      msg = "Zero records exists in the Operation worksheet ";
    }
    return msg;

  }
}
