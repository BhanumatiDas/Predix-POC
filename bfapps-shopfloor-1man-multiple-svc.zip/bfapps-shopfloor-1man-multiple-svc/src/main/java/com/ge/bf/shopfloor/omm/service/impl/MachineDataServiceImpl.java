/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IMachineDataService;
import com.ge.bf.shopfloor.omm.service.entity.MachineData;
import com.ge.bf.shopfloor.omm.service.exception.MachineDataServiceException;
import com.ge.bf.shopfloor.omm.service.repository.MachineDataRepository;

@Component
public class MachineDataServiceImpl implements IMachineDataService {
  private static final Logger LOGGER = LoggerFactory.getLogger(MachineDataServiceImpl.class);

  @Autowired
  private MachineDataRepository machineDataRepository;

  @Override
  public List<MachineData> createMachineData(List<MachineData> machineData) throws MachineDataServiceException {
    List<MachineData> currentSet;
    try {
      currentSet = machineDataRepository.save(machineData);
    } catch (Exception e) {
      throw new MachineDataServiceException("Error creating Machine Data", e);
    }
    return currentSet;
  }

  @Override
  public MachineData createMachineData(MachineData machineData) throws MachineDataServiceException {
    MachineData current;
    try {
      current = machineDataRepository.save(machineData);
      LOGGER.debug("Machine Data created: " + current.getId());
    } catch (Exception e) {
      throw new MachineDataServiceException("Error creating Machine Data", e);
    }
    return current;
  }

  @Override
  public MachineData getMachineData(String machineDataId) {
    return machineDataRepository.findById(machineDataId);
  }

  @Override
  public List<MachineData> getMachineDataByCode(String machineCode) throws MachineDataServiceException {
    if (machineCode == null || machineCode.trim().length() == 0) {
      throw new MachineDataServiceException("Machine Code Cannot  be null or empty");
    }
    List<MachineData> machineDataSet;
    try {
      machineDataSet = machineDataRepository.getMachineDataByCode(machineCode);
    } catch (Exception e) {
      throw new MachineDataServiceException("Error fetching Machine Data by Machine Code", e);
    }
    return machineDataSet;

  }

  @Override
  public List<MachineData> getMachineDataByPlant(String plantCode) throws MachineDataServiceException {
    if (plantCode == null || plantCode.trim().length() == 0) {
      throw new MachineDataServiceException("Plant Code Cannot  be null or empty");
    }
    List<MachineData> machineDataSet;
    try {
      machineDataSet = machineDataRepository.getMachineDataByPlant(plantCode);
    } catch (Exception e) {
      throw new MachineDataServiceException("Error fetching Machine Data by Plant Code", e);
    }
    return machineDataSet;

  }

  @Override
  public List<MachineData> getMachineDataPartNumber(String partNumber) throws MachineDataServiceException {
    if (partNumber == null || partNumber.trim().length() == 0) {
      throw new MachineDataServiceException("Part Number Cannot  be null or empty");
    }
    List<MachineData> machineDataSet;
    try {
      machineDataSet = machineDataRepository.getMachineDataPartNumber(partNumber);
    } catch (Exception e) {
      throw new MachineDataServiceException("Error fetching Machine Data by Part Number", e);
    }
    return machineDataSet;

  }

  @Override
  public List<MachineData> getMachineDataSet() throws MachineDataServiceException {
    List<MachineData> machineDataSet;
    try {
      machineDataSet = machineDataRepository.findAll();
    } catch (Exception e) {
      throw new MachineDataServiceException("Error fetching Machine Data ", e);
    }
    return machineDataSet;

  }
}
