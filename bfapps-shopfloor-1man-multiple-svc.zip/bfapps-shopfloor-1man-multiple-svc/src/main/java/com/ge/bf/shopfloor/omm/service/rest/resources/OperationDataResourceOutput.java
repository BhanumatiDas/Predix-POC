/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.resources;

import java.sql.Timestamp;

import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.core.Relation;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 *
 * @author BD470389
 *
 */
@Relation(collectionRelation = "operation")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OperationDataResourceOutput extends ResourceSupport {
  private String operationCode;
  private String operationDesc;
  private String machineCode;
  private String createdBy;
  private String updatedBy;
  private Timestamp createdDate;
  private Timestamp updatedDate;

  @Override
  public boolean equals(Object obj) {

    if (this == obj) {
      return true;
    }
    if (!super.equals(obj)) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    OperationDataResourceOutput other = (OperationDataResourceOutput)obj;

    if (machineCode == null) {
      if (other.machineCode != null) {
        return false;
      }
    } else if (!machineCode.equals(other.machineCode)) {
      return false;
    }
    if (operationCode == null) {
      if (other.operationCode != null) {
        return false;
      }
    } else if (!operationCode.equals(other.operationCode)) {
      return false;
    }
    return true;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public Timestamp getCreatedDate() {
    return (Timestamp)createdDate.clone();
  }

  public String getMachineCode() {
    return machineCode;
  }

  public String getOperationCode() {
    return operationCode;
  }

  public String getOperationDesc() {
    return operationDesc;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public Timestamp getUpdatedDate() {
    return (Timestamp)updatedDate.clone();
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ((machineCode == null) ? 0 : machineCode.hashCode());
    result = prime * result + ((operationCode == null) ? 0 : operationCode.hashCode());
    return result;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = (Timestamp)createdDate.clone();
  }

  public void setMachineCode(String machineCode) {
    this.machineCode = machineCode;
  }

  public void setOperationCode(String operationCode) {
    this.operationCode = operationCode;
  }

  public void setOperationDesc(String operationDesc) {
    this.operationDesc = operationDesc;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public void setUpdatedDate(Timestamp updatedDate) {
    this.updatedDate = (Timestamp)updatedDate.clone();
  }

}
