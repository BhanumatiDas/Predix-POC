/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IPartDataService;
import com.ge.bf.shopfloor.omm.service.entity.PartData;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.PartDataServiceException;
import com.ge.bf.shopfloor.omm.service.repository.PartDataRepository;

@Component
public class PartDataServiceImpl implements IPartDataService {
  private static final Logger LOGGER = LoggerFactory.getLogger(PartDataServiceImpl.class);

  @Autowired
  private PartDataRepository partDataRepository;

  @Override
  public List<PartData> createPartData(List<PartData> partData) throws PartDataServiceException {
    List<PartData> currentSet;
    try {
      currentSet = partDataRepository.save(partData);
    } catch (Exception e) {
      throw new PartDataServiceException("Error creating Part Data", e);
    }
    return currentSet;
  }

  @Override
  public PartData createPartData(PartData partData) throws PartDataServiceException {
    PartData current;
    try {
      current = partDataRepository.save(partData);
      LOGGER.debug("Part Data created: " + current.getId());
    } catch (Exception e) {
      throw new PartDataServiceException("Error creating Part Data", e);
    }
    return current;
  }

  @Override
  public PartData getPartData(String partDataId) {
    return partDataRepository.findById(partDataId);
  }

  @Override
  public PartData getPartDataByCode(String partCode) throws PartDataServiceException {
    if (partCode == null || partCode.trim().length() == 0) {
      throw new PartDataServiceException(ErrorMessage.NO_PART_CODE);
    }
    PartData partData;
    try {
      partData = partDataRepository.getPartDataByCode(partCode);
    } catch (Exception e) {
      throw new PartDataServiceException("Error fetching Part Data by Part Code", e);
    }
    return partData;

  }

  @Override
  public List<PartData> getPartDataSet() throws PartDataServiceException {
    List<PartData> partDataSet;
    try {
      partDataSet = partDataRepository.findAll();
    } catch (Exception e) {
      throw new PartDataServiceException("Error fetching Part Data ", e);
    }
    return partDataSet;

  }
}
