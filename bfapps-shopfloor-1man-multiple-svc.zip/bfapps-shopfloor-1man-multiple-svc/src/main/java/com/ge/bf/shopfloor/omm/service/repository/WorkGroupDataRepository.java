/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ge.bf.shopfloor.omm.service.entity.WorkGroupData;
import com.ge.bf.shopfloor.omm.service.exception.WorkGroupDataServiceException;

public interface WorkGroupDataRepository extends JpaRepository<WorkGroupData, String> {
  WorkGroupData findById(@Param("id") String id);

  @Query("SELECT wd FROM WorkGroupData wd" + " WHERE wd.workGroupCode = :workGroupCode")
  List<WorkGroupData> getWorkGroupDataByCode(@Param("workGroupCode") String workGroupCode)
      throws WorkGroupDataServiceException;

  @Query("SELECT wd FROM WorkGroupData wd" + " WHERE wd.id = :id")
  WorkGroupData getWorkGroupDataById(@Param("id") String id) throws WorkGroupDataServiceException;

}
