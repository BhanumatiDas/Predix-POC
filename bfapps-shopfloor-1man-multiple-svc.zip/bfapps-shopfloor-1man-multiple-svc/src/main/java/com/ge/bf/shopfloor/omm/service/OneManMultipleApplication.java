/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneManMultipleApplication {
  public static void main(String[] args) {
    SpringApplication.run(OneManMultipleApplication.class, args);
  }

  private final String name;

  public OneManMultipleApplication() {
    name = "OneManMultipleApplication";
  }

  public String getName() {
    return name;
  }
}
