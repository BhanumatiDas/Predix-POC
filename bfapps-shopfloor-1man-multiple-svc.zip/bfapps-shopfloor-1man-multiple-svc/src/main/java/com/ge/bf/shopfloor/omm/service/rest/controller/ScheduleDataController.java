/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.bf.shopfloor.omm.service.IScheduleDataService;
import com.ge.bf.shopfloor.omm.service.TenantContextProvider;
import com.ge.bf.shopfloor.omm.service.entity.Schedule;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.ScheduleDataServiceException;
import com.ge.bf.shopfloor.omm.service.rest.assembler.ScheduleDataResourceAssembler;
import com.ge.bf.shopfloor.omm.service.rest.resources.ScheduleDataResourceOutput;

/**
 *
 * @author BD470389
 *
 */
@Controller
@RequestMapping(value = "/omm/v1/schedules", produces = { MediaTypes.HAL_JSON_VALUE })
public class ScheduleDataController {

  private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleDataController.class);

  @Autowired
  private IScheduleDataService iScheduleDataService;

  @Autowired
  private TenantContextProvider tenantContextProvider;

  /**
   *
   * @param scheduleDataResource
   * @return
   * @throws ScheduleDataServiceException
   */
  private Schedule buildScheduleData(ScheduleDataResourceOutput scheduleDataResource)
      throws ScheduleDataServiceException {
    Schedule schedule = new Schedule();
    BeanUtils.copyProperties(scheduleDataResource, schedule);
    return schedule;
  }

  /**
   *
   * @param scheduleDataResourceInput
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(method = POST, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<ScheduleDataResourceOutput> createScheduleData(
      @RequestBody ScheduleDataResourceOutput scheduleDataResourceInput) throws ScheduleDataServiceException {

    /*
     * String tenantId = tenantContextProvider.getTenantId(); if (tenantId ==
     * null) { throw new MissingTenantIdException(NO_TENANT_ID); }
     */

    Schedule schedule = buildScheduleData(scheduleDataResourceInput);
    Schedule newScheduleData = iScheduleDataService.createScheduleData(schedule);
    ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(newScheduleData), CREATED);
  }

  /**
   *
   * @param id
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/delete/{id}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public void deleteScheduleData(@PathVariable("id") String id) throws ScheduleDataServiceException {
    try {
      iScheduleDataService.deleteScheduleData(id);
    } catch (Exception e) {
      throw new ScheduleDataServiceException(ErrorMessage.SCHEDULEDATA_DELETE_FAILURE, e);
    }

  }

  /**
   *
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/all", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<ScheduleDataResourceOutput>> getAllScheduleData() throws ScheduleDataServiceException {

    try {

      List<Schedule> schedule = iScheduleDataService.getScheduleDataSet();

      if (CollectionUtils.isEmpty(schedule)) {
        return new ResponseEntity<>(NO_CONTENT);
      }

      ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
      List<ScheduleDataResourceOutput> scheduleDataResource = assembler.toResources(schedule);

      return new ResponseEntity<>(scheduleDataResource, OK);
    } catch (Exception e) {
      throw new ScheduleDataServiceException(ErrorMessage.SCHEDULEDATA_RETRIEVAL_FAILURE, e);
    }
  }

  /**
   *
   * @param runId
   * @param status
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/{runId}/{status}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<ScheduleDataResourceOutput>> getAllScheduleData(@PathVariable("runId") String runId,
      @PathVariable("status") String status) throws ScheduleDataServiceException {

    try {

      List<Schedule> schedule = iScheduleDataService.getScheduleDataSet(runId, status);

      if (CollectionUtils.isEmpty(schedule)) {
        return new ResponseEntity<>(NO_CONTENT);
      }

      ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
      List<ScheduleDataResourceOutput> scheduleDataResource = assembler.toResources(schedule);

      return new ResponseEntity<>(scheduleDataResource, OK);
    } catch (Exception e) {
      throw new ScheduleDataServiceException(ErrorMessage.SCHEDULEDATA_RETRIEVAL_FAILURE, e);
    }
  }

  /**
   *
   * @param machineCode
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/machineCode/{machineCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<ScheduleDataResourceOutput>> getScheduleByMachineCode(
      @PathVariable("machineCode") String machineCode) throws ScheduleDataServiceException {

    List<Schedule> scheduleList = isValidScheduleByMachineCode(machineCode);

    ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
    List<ScheduleDataResourceOutput> scheduleDataResource = assembler.toResources(scheduleList);

    return new ResponseEntity<>(scheduleDataResource, OK);

  }

  /**
   *
   * @param operationCode
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/operationCode/{operationCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<ScheduleDataResourceOutput>> getScheduleByOperationCode(
      @PathVariable("operationCode") String operationCode) throws ScheduleDataServiceException {

    List<Schedule> scheduleList = isValidScheduleByOperationCode(operationCode);

    ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
    List<ScheduleDataResourceOutput> scheduleDataResource = assembler.toResources(scheduleList);

    return new ResponseEntity<>(scheduleDataResource, OK);

  }

  /**
   *
   * @param partCode
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/partCode/{partCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<ScheduleDataResourceOutput>> getScheduleByPartCode(@PathVariable("partCode") String partCode)
      throws ScheduleDataServiceException {

    List<Schedule> scheduleList = isValidScheduleByPartCode(partCode);

    ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
    List<ScheduleDataResourceOutput> scheduleDataResource = assembler.toResources(scheduleList);

    return new ResponseEntity<>(scheduleDataResource, OK);

  }

  /**
   *
   * @param runId
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/runId/{runId}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<ScheduleDataResourceOutput>> getScheduleByrunId(@PathVariable("runId") String runId)
      throws ScheduleDataServiceException {

    List<Schedule> scheduleList = isValidScheduleByRunId(runId);

    ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
    List<ScheduleDataResourceOutput> scheduleDataResource = assembler.toResources(scheduleList);

    return new ResponseEntity<>(scheduleDataResource, OK);

  }

  /**
   *
   * @param status
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/status/{status}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<ScheduleDataResourceOutput>> getScheduleByStatus(@PathVariable("status") String status)
      throws ScheduleDataServiceException {

    List<Schedule> scheduleList = isValidScheduleByStatus(status);

    ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
    List<ScheduleDataResourceOutput> scheduleDataResource = assembler.toResources(scheduleList);

    return new ResponseEntity<>(scheduleDataResource, OK);

  }

  /**
   *
   * @param taskCode
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/taskCode/{taskCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<ScheduleDataResourceOutput> getScheduleDataByCode(@PathVariable("taskCode") String taskCode)
      throws ScheduleDataServiceException {

    Schedule schedule = isValidScheduleByCode(taskCode);

    ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(schedule), OK);

  }

  /**
   *
   * @param id
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/id/{id}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<ScheduleDataResourceOutput> getScheduleDataById(@PathVariable("id") String id)
      throws ScheduleDataServiceException {

    Schedule schedule = isValidScheduleData(id);

    ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(schedule), OK);
  }

  /**
   *
   * @param taskCode
   * @return
   * @throws ScheduleDataServiceException
   */
  private Schedule isValidScheduleByCode(String taskCode) throws ScheduleDataServiceException {
    Schedule schedule = iScheduleDataService.getScheduleByTaskCode(taskCode);
    if (schedule == null) {
      throw new ScheduleDataServiceException(ErrorMessage.NONEXISTANT_SCHEDULEDATA);
    }
    return schedule;
  }

  /**
   *
   * @param machineCode
   * @return
   * @throws ScheduleDataServiceException
   */
  private List<Schedule> isValidScheduleByMachineCode(String machineCode) throws ScheduleDataServiceException {
    List<Schedule> scheduleList = iScheduleDataService.getScheduleByMachineCode(machineCode);

    if (scheduleList == null || scheduleList.size() == 0) {
      throw new ScheduleDataServiceException(ErrorMessage.NONEXISTANT_SCHEDULEDATA);
    }
    return scheduleList;
  }

  /**
   *
   * @param operationCode
   * @return
   * @throws ScheduleDataServiceException
   */
  private List<Schedule> isValidScheduleByOperationCode(String operationCode) throws ScheduleDataServiceException {
    List<Schedule> scheduleList = iScheduleDataService.getScheduleByOperationCode(operationCode);

    if (scheduleList == null || scheduleList.size() == 0) {
      throw new ScheduleDataServiceException(ErrorMessage.NONEXISTANT_SCHEDULEDATA);
    }
    return scheduleList;
  }

  /**
   *
   * @param partCode
   * @return
   * @throws ScheduleDataServiceException
   */
  private List<Schedule> isValidScheduleByPartCode(String partCode) throws ScheduleDataServiceException {
    List<Schedule> scheduleList = iScheduleDataService.getScheduleByPartCode(partCode);

    if (scheduleList == null || scheduleList.size() == 0) {
      throw new ScheduleDataServiceException(ErrorMessage.NONEXISTANT_SCHEDULEDATA);
    }
    return scheduleList;
  }

  /**
   *
   * @param runId
   * @return
   * @throws ScheduleDataServiceException
   */
  private List<Schedule> isValidScheduleByRunId(String runId) throws ScheduleDataServiceException {
    List<Schedule> scheduleList = iScheduleDataService.getScheduleByRunId(runId);

    if (scheduleList == null || scheduleList.size() == 0) {
      throw new ScheduleDataServiceException(ErrorMessage.NONEXISTANT_SCHEDULEDATA);
    }
    return scheduleList;
  }

  /**
   *
   * @param status
   * @return
   * @throws ScheduleDataServiceException
   */
  private List<Schedule> isValidScheduleByStatus(String status) throws ScheduleDataServiceException {
    List<Schedule> scheduleList = iScheduleDataService.getScheduleByStatus(status);

    if (scheduleList == null || scheduleList.size() == 0) {
      throw new ScheduleDataServiceException(ErrorMessage.NONEXISTANT_SCHEDULEDATA);
    }
    return scheduleList;
  }

  /**
   *
   * @param scheduleId
   * @return
   * @throws ScheduleDataServiceException
   */
  private Schedule isValidScheduleData(String scheduleId) throws ScheduleDataServiceException {
    Schedule schedule = iScheduleDataService.getScheduleDataById(scheduleId);
    if (schedule == null) {
      throw new ScheduleDataServiceException(ErrorMessage.NONEXISTANT_SCHEDULEDATA);
    }
    return schedule;
  }

  /**
   *
   * @param id
   * @param status
   * @return
   * @throws ScheduleDataServiceException
   */
  @RequestMapping(value = "/update/{id}/{status}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<ScheduleDataResourceOutput> updateScheduleData(@PathVariable("id") String id,
      @PathVariable("status") String status) throws ScheduleDataServiceException {
    try {
      Schedule updatedSchedule = iScheduleDataService.updateScheduleData(status, id);

      ScheduleDataResourceAssembler assembler = new ScheduleDataResourceAssembler();
      return new ResponseEntity<>(assembler.toResource(updatedSchedule), OK);
    } catch (Exception e) {
      throw new ScheduleDataServiceException(ErrorMessage.SCHEDULEDATA_UPDATE_FAILURE, e);
    }

  }

}
