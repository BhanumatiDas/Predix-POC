/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IOneManMultipleTaskOptimizer;
import com.ge.bf.shopfloor.omm.service.IOperationDataService;
import com.ge.bf.shopfloor.omm.service.ITaskDataService;
import com.ge.bf.shopfloor.omm.service.entity.Operation;
import com.ge.bf.shopfloor.omm.service.entity.Task;
import com.ge.bf.shopfloor.omm.service.exception.OneManMultipleServiceException;
import com.ge.bf.shopfloor.omm.service.util.TaskGroup;
import com.ge.bf.shopfloor.omm.service.util.TaskWrapper;

/**
 * @author 221032148
 *
 */
@Component
public class OneManMultipleTaskOptimizerImpl implements IOneManMultipleTaskOptimizer {

  private static final Logger LOGGER = LoggerFactory.getLogger(OneManMultipleTaskOptimizerImpl.class);

  private List<TaskWrapper> sequencedTasks;

  @Autowired
  private ITaskDataService taskService;

  @Autowired
  private IOperationDataService opService;

  /**
   * Check if All Tasks are scheduled.
   *
   * @param taskGroups
   * @return
   */
  private boolean allTasksAreScheduled(Map<String, TaskGroup> taskGroups) {
    if (taskGroups == null || taskGroups.isEmpty()) {
      return true;
    }
    boolean flag = true;
    for (String key : taskGroups.keySet()) {
      TaskGroup group = taskGroups.get(key);
      for (TaskWrapper task : group.getTaskList()) {
        if (!task.isTaskScheduled()) {
          flag = false;
          break;
        }
      }
    }
    return flag;
  }

  /**
   *
   * @param workgroupCode
   * @return
   * @throws OneManMultipleServiceException
   */
  private Map<String, TaskGroup> fetchValidTasks(String workgroupCode) throws OneManMultipleServiceException {
    // get valid operations associated with machine and work group
    List<Operation> opSet = opService.findValidOperationByWorkGroup(workgroupCode);
    if (opSet.isEmpty()) {
      throw new OneManMultipleServiceException("No valid operations associated with WorkGroup " + workgroupCode);
    }

    // iterator operations and fetch valid Tasks associated with Ops Code
    Map<String, TaskGroup> taskGroupList = new HashMap<String, TaskGroup>(10);
    for (Operation ops : opSet) {
      List<Task> tasks = taskService.getTasksByOperationCode(ops.getOperationCode());
      if (tasks == null || tasks.isEmpty()) {
        continue;
      }
      TaskGroup group = new TaskGroup();
      List<TaskWrapper> twList = group.createTaskWrappers(tasks);
      group.setOpsCode(ops.getOperationCode());
      group.setTaskList(twList);
      taskGroupList.put(ops.getOperationCode(), group);
    }
    return taskGroupList;
  }

  /**
   * find Next Optimized Operation.
   *
   * @param taskGroups
   * @return
   */
  private TaskGroup findNextOptimizedOps(Map<String, TaskGroup> taskGroups) {
    if (taskGroups == null || taskGroups.isEmpty()) {
      return null;
    }
    TaskGroup optimizedTaskGroup = null;
    for (String key : taskGroups.keySet()) {
      TaskGroup group = taskGroups.get(key);
      // System.out.println(" Task Group " + group.getOpsCode());
      if (group.isCompleted() || group.isOperationRunning()) {
        continue;
      }
      if (optimizedTaskGroup == null) {
        optimizedTaskGroup = group;
        continue;
      }
      optimizedTaskGroup = (optimizedTaskGroup.getOpsRemaningTime() > group.getOpsRemaningTime()) ? optimizedTaskGroup
          : group;
    }
    return optimizedTaskGroup;
  }

  /**
   * Get the next unscheduled Task.
   *
   * @param tasks
   * @return
   */
  private TaskWrapper findNextOptimizedTaskSequence(List<TaskWrapper> tasks) {
    if (tasks == null || tasks.isEmpty()) {
      return null;
    }
    // sort the Task collection by Task Sequence
    Collections.sort(tasks, TaskWrapper.getTaskSequenceComparator());
    for (TaskWrapper task : tasks) {
      LOGGER.debug("++++ Task Code: " + task.getTaskCode() + " task Seq: = " + task.getTaskSequence());
      if (task.isTaskScheduled()) {
        continue;
      }
      LOGGER.debug("++++ Task Code: " + task.getTaskCode() + " task Seq: = " + task.getTaskSequence());
      return task;
    }
    return null;
  }

  /**
   * Utility method to find a wait time.
   *
   * @return
   */
  private double findWaitTime() {
    TaskWrapper t = null;
    for (TaskWrapper task : sequencedTasks) {
      if (task.isTaskCompleted()) {
        continue;
      }
      t = (t == null) ? task : (t.getRemainingTime() > task.getRemainingTime()) ? task : t;
    }
    LOGGER.debug("--- Wait Time : Task No : " + t.getTaskCode() + " wait Time = " + t.getRemainingTime());
    return t.getRemainingTime();
  }

  /*
   * (non-Javadoc)
   *
   * @see com.ge.bf.shopfloor.omm.service.IOneManMultipleTaskOptimizer#
   * generateTaskOptimization()
   */
  @Override
  public List<TaskWrapper> generateTaskOptimization(String workGroup) throws OneManMultipleServiceException {
    // public List<String> generateTaskOptimization(String workGroup) throws
    // OneManMultipleServiceException {
    // fetch valid tasks
    Map<String, TaskGroup> validTasks = fetchValidTasks(workGroup);
    // if no valid tasks found, return null.
    if (validTasks == null || validTasks.isEmpty()) {
      LOGGER.info("Zero Valid Tasks found for Workgroup " + workGroup);
      return null;
    } else {
      return sequencesTasks(validTasks);
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see com.ge.bf.shopfloor.omm.service.IOneManMultipleTaskOptimizer#
   * regenerateTaskOptimization()
   */
  @Override
  public void reGenerateTaskOptimization() throws OneManMultipleServiceException {
    // TODO Auto-generated method stub

  }

  /**
   * Utility method to copy the Task to TaskWrapper.
   *
   * @param tasks
   * @return
   */
  private void resetRemaingTime(double elaspedTime) {

    if (sequencedTasks == null || sequencedTasks.isEmpty()) {
      return;
    }
    // int taskCnt = 1;
    for (TaskWrapper t : sequencedTasks) {
      if (!t.isTaskCompleted()) {
        // if (sequencedTasks.size() >= taskCnt+1 && !t.isTaskCompleted()) {
        t.setRemainingTime(elaspedTime);
      }
      // taskCnt +=1;
    }
  }

  /**
   * Method to sequence the tasks.
   *
   * @return
   */
  private List<TaskWrapper> sequencesTasks(Map<String, TaskGroup> validTasks) {

    TaskWrapper task = null;
    sequencedTasks = new ArrayList<TaskWrapper>(10);
    // loop thru until all tasks are scheduled and sequenced.
    while (!allTasksAreScheduled(validTasks)) {
      // find next optimized operation
      TaskGroup tGroup = findNextOptimizedOps(validTasks);
      // if there is no Operation found, create a wait Task.
      if (tGroup == null) {
        task = TaskGroup.createWaitTask(findWaitTime());
      } else {
        // find a next Optimized Task
        task = findNextOptimizedTaskSequence(tGroup.getTaskList());
      }
      task.setIsTaskScheduled(true);
      // reset the remaining time for the task to be completed.
      resetRemaingTime(task.getManualTime());
      sequencedTasks.add(task);
      if (LOGGER.isDebugEnabled()) {
        int c = 0;
        for (TaskWrapper taska : sequencedTasks) {
          c += 1;
          LOGGER.debug("Task Seq: " + c + " " + taska.toString());
          //
        }
      }
    }
    return sequencedTasks;
  }
}
