/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ResourcesUtils {

  private static final Logger LOGGER = LoggerFactory.getLogger(ResourcesUtils.class);

  /**
   * Util method to calculate difference between 2 local dates.
   *
   * @param startDate
   * @param endDate
   * @return
   */
  public static long diffBetweenDates(LocalDate startDate, LocalDate endDate) {
    if (startDate != null && endDate != null) {
      return ChronoUnit.DAYS.between(startDate, endDate);
    }
    return 0L;
  }

  /**
   * Return an ISO 8601 String representation of a date in UTC.
   *
   * @param date
   * @return
   */
  public static Timestamp getUTCCurrentTimestamp() {
    ZoneId utcZoneId = ZoneId.of("Z");
    Calendar cl = Calendar.getInstance(TimeZone.getTimeZone(utcZoneId));
    return new Timestamp(cl.getTime().getTime());
  }

  /**
   * Return an ISO 8601 String representation of a date in UTC.
   *
   * @param date
   * @return
   */
  public static Date getUTCCurrentDate() {
    ZoneId utcZoneId = ZoneId.of("Z");
    Calendar cl = Calendar.getInstance(TimeZone.getTimeZone(utcZoneId));
    return new Timestamp(cl.getTime().getTime());
  }

  /**
   * @param date
   * @return
   */
  public static Date getUTCDate(String date) {
    LOGGER.debug("Date String parsed : " + date);
    if (date != null) {
      try {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX", Locale.US);
        return format.parse(date);
      } catch (Exception e) {
        LOGGER.error("Error occured while parsing date " + e.getMessage());
      }

    }
    return null;
  }

  /**
   * Return an ISO 8601 String representation of a date in UTC.
   *
   * @param date
   * @return
   */
  public static String getUTCDateString(Date date) {
    String stringRepresentation = null;
    if (date != null) {
      ZoneId utcZoneId = ZoneId.of("Z");
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssX", Locale.US);
      ZonedDateTime zonedDateTime = date.toInstant().atZone(utcZoneId);
      stringRepresentation = zonedDateTime.format(formatter);
    }
    return stringRepresentation;
  }

  private ResourcesUtils() {
    // utility class, do not instantiate
  }
}
