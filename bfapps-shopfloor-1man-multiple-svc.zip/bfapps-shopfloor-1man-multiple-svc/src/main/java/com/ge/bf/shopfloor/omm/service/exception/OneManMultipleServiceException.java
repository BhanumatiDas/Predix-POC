/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

/**
 * @author 221032148
 *
 */
public class OneManMultipleServiceException extends Exception {

  public OneManMultipleServiceException(String message) {
    super(message);
  }

  public OneManMultipleServiceException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public OneManMultipleServiceException(Throwable throwable) {
    super(throwable);
  }
}
