/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

import java.util.List;

import com.ge.bf.shopfloor.omm.service.entity.MachineData;
import com.ge.bf.shopfloor.omm.service.exception.MachineDataServiceException;

/**
 * 
 * @author 221032148
 *
 */
public interface IMachineDataService {

  List<MachineData> createMachineData(List<MachineData> machineData) throws MachineDataServiceException;

  MachineData createMachineData(MachineData machineData) throws MachineDataServiceException;

  MachineData getMachineData(String machineDataId) throws MachineDataServiceException;

  List<MachineData> getMachineDataByCode(String machineCode) throws MachineDataServiceException;

  List<MachineData> getMachineDataByPlant(String plantCode) throws MachineDataServiceException;

  List<MachineData> getMachineDataPartNumber(String partNumber) throws MachineDataServiceException;

  List<MachineData> getMachineDataSet() throws MachineDataServiceException;
}
