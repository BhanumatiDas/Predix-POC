/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

import java.util.List;

import com.ge.bf.shopfloor.omm.service.entity.Operation;
import com.ge.bf.shopfloor.omm.service.exception.OperationDataServiceException;

/**
 * 
 * @author 221032148
 *
 */
public interface IOperationDataService {

  List<Operation> createOperation(List<Operation> operationData) throws OperationDataServiceException;

  Operation createOperation(Operation operationData) throws OperationDataServiceException;

  Operation getOperationDataById(String operationId) throws OperationDataServiceException;

  Operation getOperationDataByCode(String operationCode) throws OperationDataServiceException;

  List<Operation> getOperationsByMacineCode(String machineCode) throws OperationDataServiceException;

  List<Operation> getOperationDataSet() throws OperationDataServiceException;

  List<Operation> findValidOperationByWorkGroup(String workgroupCode) throws OperationDataServiceException;
}
