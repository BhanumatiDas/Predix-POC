/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.resources;

import java.sql.Timestamp;

import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.core.Relation;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 *
 * @author BD470389
 *
 */
@Relation(collectionRelation = "task")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskDataResourceOutput extends ResourceSupport {

  private String taskCode;
  private String taskDesc;
  private String operationCode;
  private String taskSequence;
  private double manualTime;
  private double autoTime;
  private double travelTime;
  private String createdBy;
  private String updatedBy;
  private Timestamp createdDate;
  private Timestamp updatedDate;

  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (!(obj instanceof TaskDataResourceOutput)) {
      return false;
    }

    TaskDataResourceOutput other = (TaskDataResourceOutput)obj;
    if (taskCode == null) {
      if (other.taskCode != null) {
        return false;
      }
    } else if (!taskCode.equals(other.taskCode)) {
      return false;
    }
    return true;
  }

  public double getAutoTime() {
    return autoTime;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public Timestamp getCreatedDate() {
    return (Timestamp)createdDate.clone();
  }

  public double getManualTime() {
    return manualTime;
  }

  public String getOperationCode() {
    return operationCode;
  }

  public String getTaskCode() {
    return taskCode;
  }

  public String getTaskDesc() {
    return taskDesc;
  }

  public String getTaskSequence() {
    return taskSequence;
  }

  public double getTravelTime() {
    return travelTime;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public Timestamp getUpdatedDate() {
    return (Timestamp)updatedDate.clone();
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ((taskCode == null) ? 0 : taskCode.hashCode());
    return result;
  }

  public void setAutoTime(double autoTime) {
    this.autoTime = autoTime;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = (Timestamp)createdDate.clone();
  }

  public void setManualTime(double manualTime) {
    this.manualTime = manualTime;
  }

  public void setOperationCode(String operationCode) {
    this.operationCode = operationCode;
  }

  public void setTaskCode(String taskCode) {
    this.taskCode = taskCode;
  }

  public void setTaskDesc(String taskDesc) {
    this.taskDesc = taskDesc;
  }

  public void setTaskSequence(String taskSequence) {
    this.taskSequence = taskSequence;
  }

  public void setTravelTime(double travelTime) {
    this.travelTime = travelTime;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public void setUpdatedDate(Timestamp updatedDate) {
    this.updatedDate = (Timestamp)updatedDate.clone();
  }

}
