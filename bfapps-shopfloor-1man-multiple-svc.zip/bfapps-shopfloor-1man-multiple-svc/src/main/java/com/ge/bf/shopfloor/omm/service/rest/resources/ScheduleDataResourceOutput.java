/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */package com.ge.bf.shopfloor.omm.service.rest.resources;

 import java.sql.Timestamp;

 import org.springframework.hateoas.ResourceSupport;
 import org.springframework.hateoas.core.Relation;

 import com.fasterxml.jackson.annotation.JsonInclude;

 /**
  *
  * @author BD470389
  *
  */
 @Relation(collectionRelation = "schedule")
 @JsonInclude(JsonInclude.Include.NON_NULL)
 public class ScheduleDataResourceOutput extends ResourceSupport {

   private String taskCode;
   private String taskSequence;
   private String operationCode;
   private String machineCode;
   private String partCode;
   private Timestamp manualStartTime;
   private Timestamp manualEndTime;
   private String completeFlag;
   private String createdBy;
   private String updatedBy;
   private Timestamp createdDate;
   private Timestamp updatedDate;

   @Override
   public boolean equals(Object obj) {
     if (this == obj) {
       return true;
     }
     if (obj == null) {
       return false;
     }
     if (getClass() != obj.getClass()) {
       return false;
     }
     ScheduleDataResourceOutput other = (ScheduleDataResourceOutput)obj;

     if (taskCode == null) {
       if (other.taskCode != null) {
         return false;
       }
     } else if (!taskCode.equals(other.taskCode)) {
       return false;
     }
     return true;
   }

   public String getCompleteFlag() {
     return completeFlag;
   }

   public String getCreatedBy() {
     return createdBy;
   }

   public Timestamp getCreatedDate() {
     return (Timestamp)createdDate.clone();
   }

   public String getMachineCode() {
     return machineCode;
   }

   public Timestamp getManualEndTime() {
     return manualEndTime;
   }

   public Timestamp getManualStartTime() {
     return manualStartTime;
   }

   public String getOperationCode() {
     return operationCode;
   }

   public String getPartCode() {
     return partCode;
   }

   public String getTaskCode() {
     return taskCode;
   }

   public String getTaskSequence() {
     return taskSequence;
   }

   public String getUpdatedBy() {
     return updatedBy;
   }

   public Timestamp getUpdatedDate() {
     return updatedDate;
   }

   @Override
   public int hashCode() {
     final int prime = 31;
     int result = 1;
     result = prime * result + ((taskCode == null) ? 0 : taskCode.hashCode());
     return result;
   }

   public void setCompleteFlag(String completeFlag) {
     this.completeFlag = completeFlag;
   }

   public void setCreatedBy(String createdBy) {
     this.createdBy = createdBy;
   }

   public void setCreatedDate(Timestamp createdDate) {
     this.createdDate = (Timestamp)createdDate.clone();
   }

   public void setMachineCode(String machineCode) {
     this.machineCode = machineCode;
   }

   public void setManualEndTime(Timestamp manualEndTime) {
     this.manualEndTime = manualEndTime;
   }

   public void setManualStartTime(Timestamp manualStartTime) {
     this.manualStartTime = manualStartTime;
   }

   public void setOperationCode(String operationCode) {
     this.operationCode = operationCode;
   }

   public void setPartCode(String partCode) {
     this.partCode = partCode;
   }

   public void setTaskCode(String taskCode) {
     this.taskCode = taskCode;
   }

   public void setTaskSequence(String taskSequence) {
     this.taskSequence = taskSequence;
   }

   public void setUpdatedBy(String updatedBy) {
     this.updatedBy = updatedBy;
   }

   public void setUpdatedDate(Timestamp updatedDate) {
     this.updatedDate = updatedDate;
   }

 }
