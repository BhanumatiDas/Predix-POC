/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.entity;

import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.hateoas.Identifiable;

import com.ge.bf.shopfloor.omm.service.rest.util.ResourcesUtils;

/**
 *
 * @author BD470389
 *
 */
@Entity
@Table(name = "schedule", schema = "omm")
public class Schedule implements Identifiable<String> {

  @Id
  @Column(name = "schedule_id")
  private String id;
  @Column(name = "run_id")
  private String runId;
  @Column(name = "schedule_sequence")
  private Integer scheduleSequence;
  @Column(name = "task_code")
  private String taskCode;
  @Column(name = "task_sequence")
  private String taskSequence;
  @Column(name = "operation_code")
  private String operationCode;
  @Column(name = "machine_code")
  private String machineCode;
  @Column(name = "part_code")
  private String partCode;
  @Column(name = "manual_start_time")
  private Timestamp manualStartTime;
  @Column(name = "manual_end_time")
  private Timestamp manualEndTime;
  @Column(name = "complete_flag")
  private String completeFlag;
  @Column(name = "created_by")
  private String createdBy;
  @Column(name = "updated_by")
  private String updatedBy;
  @Column(name = "created_date")
  private Timestamp createdDate;
  @Column(name = "updated_date")
  private Timestamp updatedDate;

  public String getCompleteFlag() {
    return completeFlag;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public Timestamp getCreatedDate() {
    return createdDate;
  }

  @Override
  public String getId() {
    return id;
  }

  public String getMachineCode() {
    return machineCode;
  }

  public Timestamp getManualEndTime() {
    return manualEndTime;
  }

  public Timestamp getManualStartTime() {
    return manualStartTime;
  }

  public String getOperationCode() {
    return operationCode;
  }

  public String getPartCode() {
    return partCode;
  }

  public String getRunId() {
    return runId;
  }

  public Integer getScheduleSequence() {
    return scheduleSequence;
  }

  public String getTaskCode() {
    return taskCode;
  }

  public String getTaskSequence() {
    return taskSequence;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public Timestamp getUpdatedDate() {
    return updatedDate;
  }

  @PrePersist
  void onCreate() {
    this.setId(UUID.randomUUID().toString());
    this.setCreatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setCreatedBy("internal");
  }

  @PreUpdate
  void onUpdate() {
    this.setUpdatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setUpdatedBy("internal");
  }

  public void setCompleteFlag(String completeFlag) {
    this.completeFlag = completeFlag;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = createdDate;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setMachineCode(String machineCode) {
    this.machineCode = machineCode;
  }

  public void setManualEndTime(Timestamp manualEndTime) {
    this.manualEndTime = manualEndTime;
  }

  public void setManualStartTime(Timestamp manualStartTime) {
    this.manualStartTime = manualStartTime;
  }

  public void setOperationCode(String operationCode) {
    this.operationCode = operationCode;
  }

  public void setPartCode(String partCode) {
    this.partCode = partCode;
  }

  public void setRunId(String runId) {
    this.runId = runId;
  }

  public void setScheduleSequence(Integer scheduleSequence) {
    this.scheduleSequence = scheduleSequence;
  }

  public void setTaskCode(String taskCode) {
    this.taskCode = taskCode;
  }

  public void setTaskSequence(String taskSequence) {
    this.taskSequence = taskSequence;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public void setUpdatedDate(Timestamp updatedDate) {
    this.updatedDate = updatedDate;
  }

}
