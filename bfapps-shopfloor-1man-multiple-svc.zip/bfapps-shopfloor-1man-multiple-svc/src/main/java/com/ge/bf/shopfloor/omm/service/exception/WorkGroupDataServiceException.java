/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

public class WorkGroupDataServiceException extends OneManMultipleServiceException {
  public WorkGroupDataServiceException(String message) {
    super(message);
  }

  public WorkGroupDataServiceException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public WorkGroupDataServiceException(Throwable throwable) {
    super(throwable);
  }
}
