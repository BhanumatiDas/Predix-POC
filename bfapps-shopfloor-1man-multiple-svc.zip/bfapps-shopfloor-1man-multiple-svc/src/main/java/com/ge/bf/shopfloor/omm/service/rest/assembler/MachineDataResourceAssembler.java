/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.assembler;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

import com.ge.bf.shopfloor.omm.service.entity.MachineData;
import com.ge.bf.shopfloor.omm.service.rest.controller.MachineDataController;
import com.ge.bf.shopfloor.omm.service.rest.resources.MachineDataResourceOutput;

/**
 * 
 * @author 221032148
 *
 */
public class MachineDataResourceAssembler extends ResourceAssemblerSupport<MachineData, MachineDataResourceOutput> {

  public MachineDataResourceAssembler() {
    super(MachineDataController.class, MachineDataResourceOutput.class);
  }

  @Override
  public MachineDataResourceOutput toResource(MachineData machineData) {

    MachineDataResourceOutput resource;

    resource = createResourceWithId("id/" + machineData.getId(), machineData);

    BeanUtils.copyProperties(machineData, resource);
    return resource;
  }
}
