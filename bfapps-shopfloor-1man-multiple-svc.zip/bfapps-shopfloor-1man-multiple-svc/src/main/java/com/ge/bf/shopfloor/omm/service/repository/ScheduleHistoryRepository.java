/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */

package com.ge.bf.shopfloor.omm.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ge.bf.shopfloor.omm.service.entity.ScheduleHistory;

public interface ScheduleHistoryRepository extends JpaRepository<ScheduleHistory, String> {

}
