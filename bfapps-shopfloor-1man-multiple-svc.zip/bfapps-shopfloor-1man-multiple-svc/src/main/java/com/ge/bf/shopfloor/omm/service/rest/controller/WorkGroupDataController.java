/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.rest.controller;

import static com.ge.bf.shopfloor.omm.service.exception.ErrorMessage.NO_TENANT_ID;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.bf.shopfloor.omm.service.IWorkGroupDataService;
import com.ge.bf.shopfloor.omm.service.TenantContextProvider;
import com.ge.bf.shopfloor.omm.service.entity.WorkGroupData;
import com.ge.bf.shopfloor.omm.service.exception.ErrorMessage;
import com.ge.bf.shopfloor.omm.service.exception.MissingTenantIdException;
import com.ge.bf.shopfloor.omm.service.exception.WorkGroupDataServiceException;
import com.ge.bf.shopfloor.omm.service.rest.assembler.WorkGroupDataResourceAssembler;
import com.ge.bf.shopfloor.omm.service.rest.resources.WorkGroupDataResourceOutput;

@Controller
@RequestMapping(value = "/omm/v1/workgroups", produces = { MediaTypes.HAL_JSON_VALUE })
public class WorkGroupDataController {

  private static final Logger LOGGER = LoggerFactory.getLogger(WorkGroupDataController.class);

  @Autowired
  private IWorkGroupDataService iWorkGroupDataService;

  @Autowired
  private TenantContextProvider tenantContextProvider;

  private WorkGroupData buildWorkGroupData(WorkGroupDataResourceOutput workGroupDataResource)
      throws WorkGroupDataServiceException {
    WorkGroupData workGroupData = new WorkGroupData();
    BeanUtils.copyProperties(workGroupDataResource, workGroupData);
    return workGroupData;
  }

  @RequestMapping(value = "/all", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<WorkGroupDataResourceOutput>> getAllTaskData() throws WorkGroupDataServiceException {

    try {

      List<WorkGroupData> workGroupData = iWorkGroupDataService.getWorkGroupDataSet();

      if (CollectionUtils.isEmpty(workGroupData)) {
        return new ResponseEntity<>(NO_CONTENT);
      }

      WorkGroupDataResourceAssembler assembler = new WorkGroupDataResourceAssembler();
      List<WorkGroupDataResourceOutput> workGroupDataResourceOutput = assembler.toResources(workGroupData);

      return new ResponseEntity<>(workGroupDataResourceOutput, OK);
    } catch (Exception e) {
      throw new WorkGroupDataServiceException(ErrorMessage.WORKGROUPDATA_RETRIEVAL_FAILURE, e);
    }
  }

  @RequestMapping(method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<WorkGroupDataResourceOutput>> getWorkGroupData() throws WorkGroupDataServiceException {

    try {
      // String tenantId = tenantContextProvider.getTenantId();
      // hardcode, remove this line when tennant context is implemented.

      String tenantId = "12abedfr";
      if (tenantId == null) {
        throw new MissingTenantIdException(NO_TENANT_ID);
      }

      List<WorkGroupData> workGroupData = iWorkGroupDataService.getWorkGroupDataSet();

      if (CollectionUtils.isEmpty(workGroupData)) {
        return new ResponseEntity<>(NO_CONTENT);
      }

      WorkGroupDataResourceAssembler assembler = new WorkGroupDataResourceAssembler();
      List<WorkGroupDataResourceOutput> workGroupDataResource = assembler.toResources(workGroupData);

      return new ResponseEntity<>(workGroupDataResource, OK);
    } catch (Exception e) {
      throw new WorkGroupDataServiceException(ErrorMessage.WORKGROUPDATA_RETRIEVAL_FAILURE, e);
    }
  }

  @RequestMapping(value = "/id/{id}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<WorkGroupDataResourceOutput> getWorkGroupData(@PathVariable("id") String id)
      throws WorkGroupDataServiceException {

    WorkGroupData workGroupData = isValidWorkGroupData(id);

    WorkGroupDataResourceAssembler assembler = new WorkGroupDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(workGroupData), OK);
  }

  @RequestMapping(value = "/workGroupCode/{workGroupCode}", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<List<WorkGroupDataResourceOutput>> getWorkGroupDataByCode(
      @PathVariable("workGroupCode") String workGroupCode) throws WorkGroupDataServiceException {

    List<WorkGroupData> workGroupData = isValidWorkGroupDataByCode(workGroupCode);

    WorkGroupDataResourceAssembler assembler = new WorkGroupDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResources(workGroupData), OK);

  }

  private WorkGroupData isValidWorkGroupData(String workGroupId) throws WorkGroupDataServiceException {
    WorkGroupData workGroupData = iWorkGroupDataService.getWorkGroupData(workGroupId);
    if (workGroupData == null) {
      throw new WorkGroupDataServiceException(ErrorMessage.NONEXISTANT_WORKGROUPDATA);
    }
    return workGroupData;
  }

  private List<WorkGroupData> isValidWorkGroupDataByCode(String workGroupCode) throws WorkGroupDataServiceException {
    List<WorkGroupData> workGroupData = iWorkGroupDataService.getWorkGroupDataByCode(workGroupCode);
    if (workGroupData == null) {
      throw new WorkGroupDataServiceException(ErrorMessage.NONEXISTANT_WORKGROUPDATA);
    }
    return workGroupData;
  }

  @RequestMapping(value = "/search", method = GET, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody

  public HttpEntity<List<WorkGroupDataResourceOutput>> searchWorkGroupData(
      @RequestParam(value = "filter", required = true) String filter) throws WorkGroupDataServiceException {

    if (filter == null) {
      return null;
    }
    List<WorkGroupData> workGroupData = null;
    String[] tokens = filter.split("=");
    for (String token : tokens) {
      LOGGER.info("filters = " + token);
    }

    if (tokens[0].startsWith("workgroup")) {
      workGroupData = isValidWorkGroupDataByCode(tokens[1]);
    } else {
      throw new WorkGroupDataServiceException("Invalid filter passed...supported filters is 'workgroup code' ");
    }

    WorkGroupDataResourceAssembler assembler = new WorkGroupDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResources(workGroupData), OK);
  }

  @RequestMapping(method = POST, produces = { MediaTypes.HAL_JSON_VALUE })
  @ResponseBody
  public HttpEntity<WorkGroupDataResourceOutput> workGroupDataResourceOutput(
      @RequestBody WorkGroupDataResourceOutput workGroupDataResourceInput) throws WorkGroupDataServiceException {

    /*
     * String tenantId = tenantContextProvider.getTenantId(); if (tenantId ==
     * null) { throw new MissingTenantIdException(NO_TENANT_ID); }
     */

    WorkGroupData workGroupData = buildWorkGroupData(workGroupDataResourceInput);
    WorkGroupData newWorkGroupData = iWorkGroupDataService.createWorkGroupData(workGroupData);
    WorkGroupDataResourceAssembler assembler = new WorkGroupDataResourceAssembler();
    return new ResponseEntity<>(assembler.toResource(newWorkGroupData), CREATED);
  }
}
