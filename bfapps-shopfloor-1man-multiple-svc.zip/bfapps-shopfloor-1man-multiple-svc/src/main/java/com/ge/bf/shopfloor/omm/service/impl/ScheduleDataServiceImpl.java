/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.bf.shopfloor.omm.service.IScheduleDataService;
import com.ge.bf.shopfloor.omm.service.entity.Schedule;
import com.ge.bf.shopfloor.omm.service.entity.ScheduleHistory;
import com.ge.bf.shopfloor.omm.service.exception.ScheduleDataServiceException;
import com.ge.bf.shopfloor.omm.service.repository.ScheduleHistoryRepository;
import com.ge.bf.shopfloor.omm.service.repository.ScheduleRepository;

/**
 *
 * @author BD470389
 *
 */
@Component
public class ScheduleDataServiceImpl implements IScheduleDataService {

  private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleDataServiceImpl.class);

  @Autowired
  private ScheduleRepository scheduleRepository;

  @Autowired
  private ScheduleHistoryRepository scheduleHistoryRepo;

  /**
   * This method will insert a list of records.
   */
  @Override
  public List<Schedule> createScheduleData(List<Schedule> schedule) throws ScheduleDataServiceException {
    List<Schedule> currentSet;
    try {
      currentSet = scheduleRepository.save(schedule);
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while creating Schedule Data set", e);
    }
    return currentSet;
  }

  /**
   * This method will insert one record.
   */
  @Override
  public Schedule createScheduleData(Schedule schedule) throws ScheduleDataServiceException {
    Schedule current;
    try {
      current = scheduleRepository.save(schedule);
      LOGGER.debug("Schedule Data created: " + current.getId());
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while creating Schedule Data", e);
    }
    return current;
  }

  /**
   * This method will delete one record.
   */
  @Override
  public void deleteScheduleData(String scheduleId) throws ScheduleDataServiceException {

    try {
      scheduleRepository.delete(scheduleId);
      LOGGER.info("Schedule Data deleted successfully");
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while fetching Schedule Data", e);
    }

  }

  /**
   * This method will delete a list of records.
   */
  @Override
  public void deleteScheduleDataSet(List<Schedule> scheduleDataSet) throws ScheduleDataServiceException {

    try {
      scheduleRepository.deleteInBatch(scheduleDataSet);
      LOGGER.debug("Schedule Data set deleted successfully");
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while deleting schedule data set", e);
    }

  }

  @Override
  public List<Schedule> getScheduleByMachineCode(String machineCode) throws ScheduleDataServiceException {

    if (machineCode == null || machineCode.trim().length() == 0) {
      throw new ScheduleDataServiceException("Machine Code Cannot be null or empty");
    }
    List<Schedule> scheduleDataSet;
    try {
      scheduleDataSet = scheduleRepository.getScheduleByMachineCode(machineCode);
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while fetching Schedule Data by Machine Code", e);
    }
    return scheduleDataSet;
  }

  @Override
  public List<Schedule> getScheduleByOperationCode(String operationCode) throws ScheduleDataServiceException {

    if (operationCode == null || operationCode.trim().length() == 0) {
      throw new ScheduleDataServiceException("Operation Code Cannot be null or empty");
    }
    List<Schedule> scheduleDataSet;
    try {
      scheduleDataSet = scheduleRepository.getScheduleByOperationCode(operationCode);
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while fetching Schedule Data by Operation Code", e);
    }
    return scheduleDataSet;
  }

  @Override
  public List<Schedule> getScheduleByPartCode(String partCode) throws ScheduleDataServiceException {

    if (partCode == null || partCode.trim().length() == 0) {
      throw new ScheduleDataServiceException("Part Code Cannot be null or empty");
    }
    List<Schedule> scheduleDataSet;
    try {
      scheduleDataSet = scheduleRepository.getScheduleByPartCode(partCode);
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while fetching Schedule Data by Part Code", e);
    }
    return scheduleDataSet;
  }

  @Override
  public List<Schedule> getScheduleByRunId(String runId) throws ScheduleDataServiceException {

    if (runId == null || runId.trim().length() == 0) {
      throw new ScheduleDataServiceException("Run id Cannot be null or empty");
    }
    List<Schedule> scheduleDataList;
    try {
      scheduleDataList = scheduleRepository.getScheduleByRunId(runId);
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while fetching Schedule Data by run id", e);
    }
    return scheduleDataList;
  }

  @Override
  public List<Schedule> getScheduleByStatus(String completeFlag) throws ScheduleDataServiceException {

    if (completeFlag == null || completeFlag.trim().length() == 0) {
      throw new ScheduleDataServiceException("Complete Flag Cannot be null or empty");
    }
    List<Schedule> scheduleDataList;
    try {
      scheduleDataList = scheduleRepository.getScheduleByStatus(completeFlag.toUpperCase());
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while fetching Schedule Data by status", e);
    }
    return scheduleDataList;
  }

  @Override
  public Schedule getScheduleByTaskCode(String taskCode) throws ScheduleDataServiceException {

    if (taskCode == null || taskCode.trim().length() == 0) {
      throw new ScheduleDataServiceException("Task Code Cannot be null or empty");
    }
    Schedule scheduleDataSet;
    try {
      scheduleDataSet = scheduleRepository.getScheduleByTaskCode(taskCode);
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while fetching Schedule Data by task Code", e);
    }
    return scheduleDataSet;
  }

  @Override
  public Schedule getScheduleDataById(String scheduleId) {
    return scheduleRepository.findById(scheduleId);
  }

  @Override
  public List<Schedule> getScheduleDataSet() throws ScheduleDataServiceException {
    List<Schedule> scheduleDataSet;
    try {
      scheduleDataSet = scheduleRepository.findAll();
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while fetching Schedule Data ", e);
    }
    return scheduleDataSet;

  }

  @Override
  public List<Schedule> getScheduleDataSet(String runId, String status) throws ScheduleDataServiceException {
    List<Schedule> scheduleDataSet;
    try {
      scheduleDataSet = scheduleRepository.getScheduleDataSet(runId, status.toUpperCase());
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while fetching Schedule Data ", e);
    }
    return scheduleDataSet;

  }

  /**
   * This method will move the schedule data to schedule history table and
   * delete those records from schedule table.
   */
  @Override
  public void removeDataFromSchedule(List<Schedule> scheduleDataSet, List<ScheduleHistory> scheduleHistoryList)
      throws ScheduleDataServiceException {

    try {
      // List<ScheduleHistory> scheduleHistoryList =
      // scheduleDataIntialization.copyScheduleObject(scheduleDataSet);
      scheduleHistoryRepo.save(scheduleHistoryList);
      LOGGER.info("Schedule Data saved successfully in Schedule History table.");
      deleteScheduleDataSet(scheduleDataSet);
      LOGGER.info("Schedule Data deleted successfully");
    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while removing schedule data  to Schedule History table", e);
    }

  }

  /**
   * This method will update a Schedule data.
   */
  @Override
  public Schedule updateScheduleData(String completeFlag, String id) throws ScheduleDataServiceException {
    Schedule updatedSchedule;
    try {
      Schedule schedule = getScheduleDataById(id);
      schedule.setCompleteFlag(completeFlag.toUpperCase());
      updatedSchedule = scheduleRepository.save(schedule);

    } catch (Exception e) {
      throw new ScheduleDataServiceException("Error while updating Schedule Data set", e);
    }
    return updatedSchedule;
  }

}
