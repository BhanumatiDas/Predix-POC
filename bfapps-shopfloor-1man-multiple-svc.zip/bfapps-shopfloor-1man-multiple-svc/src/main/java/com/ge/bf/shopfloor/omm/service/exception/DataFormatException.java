/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.exception;

/**
 * @author 221032148
 *
 */
public class DataFormatException extends OneManMultipleServiceException {
  public DataFormatException(String message) {
    super(message);
  }

  public DataFormatException(String message, Throwable throwable) {
    super(message, throwable);
  }

  public DataFormatException(Throwable throwable) {
    super(throwable);
  }
}
