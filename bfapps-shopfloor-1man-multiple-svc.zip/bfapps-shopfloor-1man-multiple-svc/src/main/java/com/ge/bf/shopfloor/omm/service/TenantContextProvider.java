/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

//import static com.ge.bf.shopfloor.omm.service.exception.ErrorMessage.INVALID_SCOPE;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class TenantContextProvider {

  /*
   * @Autowired private Environment environment;
   * 
   * public String getTenantId() { TenantContext tenantContext =
   * TenantContext.getInstance(); if (tenantContext == null) { return null; }
   * return tenantContext.getTenantUuid(); }
   * 
   * public List<String> getTokenScope() { TenantContext tenantContext =
   * TenantContext.getInstance(); if (tenantContext == null) { return null; }
   * return tenantContext.getScope(); }
   * 
   * public void validateScope() throws InvalidScopeException { String scope =
   * environment.getProperty("scope"); if (tokenScopeContains(scope)) { return;
   * } else { throw new InvalidScopeException(INVALID_SCOPE +
   * " Expected scope: " + scope); } }
   * 
   * public boolean tokenScopeContains(String scope) { List<String> tokenScope =
   * getTokenScope(); if (tokenScope == null) { return false; } for (String str
   * : tokenScope) { if (str.equalsIgnoreCase(scope)) { return true; } } return
   * false; }
   */

  public String getTenantId() {
    /*
     * TenantContext tenantContext = TenantContext.getInstance(); if
     * (tenantContext == null) { return null; } return
     * tenantContext.getTenantUuid();
     */
    return "1";
  }

  public List<String> getTokenScope() {
    /*
     * TenantContext tenantContext = TenantContext.getInstance(); if
     * (tenantContext == null) { return null; } return tenantContext.getScope();
     */
    // return new String[] = ""
    return null;
  }
}
