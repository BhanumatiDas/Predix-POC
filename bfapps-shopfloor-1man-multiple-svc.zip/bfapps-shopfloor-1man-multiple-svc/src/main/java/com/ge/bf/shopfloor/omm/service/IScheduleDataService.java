/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service;

import java.util.List;

import com.ge.bf.shopfloor.omm.service.entity.Schedule;
import com.ge.bf.shopfloor.omm.service.entity.ScheduleHistory;
import com.ge.bf.shopfloor.omm.service.exception.ScheduleDataServiceException;

/**
 *
 * @author BD470389
 *
 */
public interface IScheduleDataService {

  List<Schedule> createScheduleData(List<Schedule> scheduleData) throws ScheduleDataServiceException;

  Schedule createScheduleData(Schedule scheduleData) throws ScheduleDataServiceException;

  void deleteScheduleData(String scheduleId) throws ScheduleDataServiceException;

  void deleteScheduleDataSet(List<Schedule> scheduleDataSet) throws ScheduleDataServiceException;

  List<Schedule> getScheduleByMachineCode(String machineCode) throws ScheduleDataServiceException;

  List<Schedule> getScheduleByOperationCode(String operationCode) throws ScheduleDataServiceException;

  List<Schedule> getScheduleByPartCode(String partCode) throws ScheduleDataServiceException;

  List<Schedule> getScheduleByRunId(String runId) throws ScheduleDataServiceException;

  List<Schedule> getScheduleByStatus(String completeFlag) throws ScheduleDataServiceException;

  Schedule getScheduleByTaskCode(String taskCode) throws ScheduleDataServiceException;

  Schedule getScheduleDataById(String scheduleId) throws ScheduleDataServiceException;

  List<Schedule> getScheduleDataSet() throws ScheduleDataServiceException;

  List<Schedule> getScheduleDataSet(String runId, String status) throws ScheduleDataServiceException;

  void removeDataFromSchedule(List<Schedule> scheduleDataSet, List<ScheduleHistory> scheduleHistoryList)
      throws ScheduleDataServiceException;

  Schedule updateScheduleData(String completeFlag, String id) throws ScheduleDataServiceException;

}
