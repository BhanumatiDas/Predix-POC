/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.entity;

import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.hateoas.Identifiable;

import com.ge.bf.shopfloor.omm.service.rest.util.ResourcesUtils;

@Entity
@Table(name = "PART", schema = "omm")
public class PartData implements Identifiable<String> {

  @Id
  @Column(name = "part_id")
  private String id;
  @Column(name = "part_code")
  private String partCode;
  @Column(name = "part_desc")
  private String partDesc;
  @Column(name = "created_by")
  private String createdBy;
  @Column(name = "updated_by")
  private String updatedBy;
  @Column(name = "created_date")
  private Timestamp createdDate;
  @Column(name = "updated_date")
  private Timestamp updatedDate;

  @Override
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  @PrePersist
  void onCreate() {
    this.setId(UUID.randomUUID().toString());
    this.setCreatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setCreatedBy("internal");
  }

  @PreUpdate
  void onUpdate() {
    this.setUpdatedDate(ResourcesUtils.getUTCCurrentTimestamp());
    this.setUpdatedBy("internal");
  }

  public String getPartCode() {
    return partCode;
  }

  public void setPartCode(String partCode) {
    this.partCode = partCode;
  }

  public String getPartDesc() {
    return partDesc;
  }

  public void setPartDesc(String partDesc) {
    this.partDesc = partDesc;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public Timestamp getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = createdDate;
  }

  public Timestamp getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Timestamp updatedDate) {
    this.updatedDate = updatedDate;
  }

}
