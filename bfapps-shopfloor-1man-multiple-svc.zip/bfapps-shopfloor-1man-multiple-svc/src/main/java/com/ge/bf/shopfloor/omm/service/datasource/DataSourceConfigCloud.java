/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
package com.ge.bf.shopfloor.omm.service.datasource;

import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.sql.DataSource;

import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.config.java.AbstractCloudConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Profile;
import org.springframework.orm.jpa.JpaTransactionManager;

@Configuration
@Profile("cloudPostgres")
public class DataSourceConfigCloud extends AbstractCloudConfig {
  // Connect to the only available relational database service
  @Bean
  public DataSource dataSource() {
    return connectionFactory().dataSource();
  }

  @Bean
  @Autowired
  public EntityManager entityManager(EntityManagerFactory entityManagerFactory) {
    return entityManagerFactory.createEntityManager();
  }

  /**
   * Entity manager factory.
   *
   * @return the local container entity manager factory bean
   */
  @Bean
  @Autowired
  @DependsOn("flyway")
  EntityManagerFactory entityManagerFactory(DataSource dataSource) {
    Properties jpaProps = new Properties();
    jpaProps.put("openjpa.ConnectionFactory", dataSource);
    jpaProps.put("openjpa.ConnectionFactoryProperties", "true");
    jpaProps.put("db.showsql", "true");
    return Persistence.createEntityManagerFactory("OMMPersistenceUnitPostgres", jpaProps);
  }

  /**
   * http://blog.trifork.com/2014/12/09/integrating-flywaydb-in-a-spring-framework-application/
   * .
   *
   * @return
   */
  @Bean(initMethod = "migrate")
  Flyway flyway() {
    Flyway flyway = new Flyway();
    flyway.setSchemas("omm");
    flyway.setLocations("classpath:db/migration/pg");
    flyway.setBaselineOnMigrate(true);
    flyway.setDataSource(dataSource());
    return flyway;
  }

  /**
   * Transaction manager.
   *
   * @param entityManagerFactory
   *          the entity manager factory
   * @return the jpa transaction manager
   */
  @Bean
  @Autowired
  JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
    return new JpaTransactionManager(entityManagerFactory);
  }
}
