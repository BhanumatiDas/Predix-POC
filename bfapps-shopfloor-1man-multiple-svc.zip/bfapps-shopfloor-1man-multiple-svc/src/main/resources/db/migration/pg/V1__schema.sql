-- DDL for Postgres database.


CREATE TABLE if not exists WORKGROUP (
  workgroup_id varchar(255) primary key NOT NULL,
  workgroup_code varchar(255) DEFAULT NULL,
  workgroup_desc varchar(255) DEFAULT NULL,
  active_flag varchar(1) DEFAULT NULL,
  created_by varchar(255) DEFAULT NULL,
  created_date timestamp DEFAULT NULL,
  updated_by varchar(255) DEFAULT NULL,
  updated_date timestamp DEFAULT NULL
);


create table if not exists MACHINE (
  machine_id varchar(255) primary key not null,
  machine_code varchar(255) not null,
  machine_desc varchar(255) not null,
  machine_color varchar(255),
  workgroup_code varchar(255),
  plant_code varchar(255),
  part_code varchar(255),
  created_by varchar(255) not null,
  created_date timestamp not null,
  updated_by varchar(255),
  updated_date timestamp
);

create table if not exists PART (
  part_id varchar(255) primary key not null,
  part_code varchar(255) not null,
  part_desc varchar(255) not null,
  created_by varchar(255) not null,
  created_date timestamp not null,
  updated_by varchar(255),
  updated_date timestamp
);

create table if not exists OPERATION (
  operation_id varchar(255) primary key not null,
  operation_code varchar(255) not null,
  operation_desc varchar(255) not null,
  machine_code varchar(255),
--  part_id varchar(255),
  created_by varchar(255) not null,
  created_date timestamp not null,
  updated_by varchar(255),
  updated_date timestamp
);

create table if not exists TASK (
  task_id varchar(255) primary key not null,
  task_code varchar(255) not null,
  task_desc varchar(255) not null,
  task_sequence varchar(255) not null,
  operation_code varchar(255) not null,
  manual_time double precision not null,
  auto_time double precision not null,
  travel_time double precision not null,
  flag varchar(1) not null,
  created_by varchar(255) not null,
  created_date timestamp not null,
  updated_by varchar(255),
  updated_date timestamp
);

create table if not exists SCHEDULE (
  schedule_id varchar(255) primary key not null,
  run_id varchar(255) not null,
  schedule_sequence int not null,
  task_code varchar(255) not null,
  task_sequence varchar(255),
  operation_code varchar(255) not null,
  machine_code varchar(255),
  part_code varchar(255),
  manual_start_time timestamp ,
  manual_end_time timestamp ,
  complete_flag varchar(1),
  created_by varchar(255) not null,
  created_date timestamp not null,
  updated_by varchar(255),
  updated_date timestamp
);

create table if not exists SCHEDULE_HISTORY (
  schedule_id varchar(255) primary key not null,
  run_id varchar(255) not null,
  schedule_sequence int not null,
  task_code varchar(255) not null,
  task_sequence varchar(255) null,
  operation_code varchar(255) not null,
  machine_code varchar(255),
  part_code varchar(255),
  manual_start_time timestamp,
  manual_end_time timestamp,
  complete_flag varchar(1),
  created_by varchar(255) not null,
  created_date timestamp not null,
  updated_by varchar(255),
  updated_date timestamp
)
