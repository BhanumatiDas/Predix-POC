Local Development environment set TIPS
====================================================================


*****************************************************
**Install gradle**
http://stackoverflow.com/questions/28928106/install-gradle-on-mac-os-x
**Install java8**
http://stackoverflow.com/questions/24342886/how-to-install-java-8-on-mac

**Eclipse and gradle**
http://www.vogella.com/tutorials/EclipseGradle/article.html

**ECLIPSE CONFIGURATION : TRY FIRST TO USE THE FILES IN /conf/eclipse**
**checkstyle and your IDE**
http://stackoverflow.com/questions/984778/how-to-generate-an-eclipse-formatter-configuration-from-a-checkstyle-configurati
**checkstyle and Eclipse**
http://www.vogella.com/tutorials/EclipseGradle/article.html

**IDEA CONFIGURATION : TRY FIRST TO IMPORT THE SETTINGS in /conf/idea File>Import Settings**
Preferences>File and Code Templates>Includes>File Header
/*
 * Copyright (c) 2016 GE. All Rights Reserved.
 * GE Confidential: Restricted Internal Distribution
 */
Preferences>Code Style>Java>Manage>Import
 conf/eclipse/eclipse_formatting_rules.xml

*********************************************************************************
**Create a REST endpoint**
https://spring.io/guides/gs/rest-service/
HAL: http://phlyrestfully.readthedocs.org/en/latest/halprimer.html
HATEOAS: http://docs.spring.io/spring-hateoas/docs/current/reference/html/

*********************************************************************************
**Create gradlew**
http://stackoverflow.com/questions/25769536/how-when-to-generate-gradle-wrapper-files
gradle wrapper

*********************************************************************************
**Run SpringBoot application**
./gradlew bootRun

*********************************************************************************
**Access H2 console
http://localhost:9000/console/
jdbc:h2:mem:testdb


How to compile and run
======================
1. Run "gradlew clean distZip" to compile and generate distribution
2. Distribution is available in build/distributions
4. to deploy to CF simply push the Zip distribution using "cf push" , you need to provide a manifest file
