package com.ge.robertBosch.TrackTrace.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the M2M_DEVICEPOSTN database table.
 * 
 */
@Entity
@Table(name="M2M_DEVICEPOSTN")
@NamedQuery(name="M2mDevicepostn.findAll", query="SELECT m FROM M2mDevicepostn m")
public class M2mDevicepostn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="M2M_DEVICEPOSTN_ID_GENERATOR", sequenceName="TT_SEQ_DEVICPOS")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="M2M_DEVICEPOSTN_ID_GENERATOR")
	private long id;

	private BigDecimal accuracy;

	private BigDecimal x;

	private BigDecimal y;

	@Column(name="ZONE")
	private String zone;

	//bi-directional many-to-one association to M2mDevice
	@ManyToOne
	@JoinColumn(name="DEVICEID")
	private M2mDevice m2mDevice;

	public M2mDevicepostn() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getAccuracy() {
		return this.accuracy;
	}

	public void setAccuracy(BigDecimal accuracy) {
		this.accuracy = accuracy;
	}

	public BigDecimal getX() {
		return this.x;
	}

	public void setX(BigDecimal x) {
		this.x = x;
	}

	public BigDecimal getY() {
		return this.y;
	}

	public void setY(BigDecimal y) {
		this.y = y;
	}

	public String getZone() {
		return this.zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public M2mDevice getM2mDevice() {
		return this.m2mDevice;
	}

	public void setM2mDevice(M2mDevice m2mDevice) {
		this.m2mDevice = m2mDevice;
	}

}