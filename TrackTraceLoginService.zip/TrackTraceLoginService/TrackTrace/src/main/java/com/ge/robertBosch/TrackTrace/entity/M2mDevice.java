package com.ge.robertBosch.TrackTrace.entity;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the M2M_DEVICES database table.
 * 
 */
@Entity
@Table(name="M2M_DEVICES")
@NamedQuery(name="M2mDevice.findAll", query="SELECT m FROM M2mDevice m")
public class M2mDevice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="M2M_DEVICES_ID_GENERATOR", sequenceName="TT_SEQ_DEVICE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="M2M_DEVICES_ID_GENERATOR")
	private long id;

	@Column(name="CONNECTION")
	private String connection;

	private Timestamp created;

	private String imei;

	private String ip;

	private String model;

	private String name;

	private BigDecimal port;

	private String serialno;

	private String status;

	@Column(name="TYPE")
	private String type;

	//bi-directional many-to-one association to M2mData
	@OneToMany(mappedBy="m2mDevice")
	private List<M2mData> m2mData;

	//bi-directional many-to-one association to M2mDevicepostn
	@OneToMany(mappedBy="m2mDevice")
	private List<M2mDevicepostn> m2mDevicepostns;

	//bi-directional many-to-one association to TtUser
	@ManyToOne
	@JoinColumn(name="USERID")
	private TtUser ttUser;

	//bi-directional many-to-one association to M2mNotification
	@OneToMany(mappedBy="m2mDevice")
	private List<M2mNotification> m2mNotifications;

	//bi-directional many-to-one association to M2mProcessedata
	@OneToMany(mappedBy="m2mDevice")
	private List<M2mProcessedata> m2mProcessedata;

	//bi-directional many-to-one association to M2mResult
	@OneToMany(mappedBy="m2mDevice")
	private List<M2mResult> m2mResults;

	public M2mDevice() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getConnection() {
		return this.connection;
	}

	public void setConnection(String connection) {
		this.connection = connection;
	}

	public Timestamp getCreated() {
		return this.created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public String getImei() {
		return this.imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getPort() {
		return this.port;
	}

	public void setPort(BigDecimal port) {
		this.port = port;
	}

	public String getSerialno() {
		return this.serialno;
	}

	public void setSerialno(String serialno) {
		this.serialno = serialno;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<M2mData> getM2mData() {
		return this.m2mData;
	}

	public void setM2mData(List<M2mData> m2mData) {
		this.m2mData = m2mData;
	}

	public M2mData addM2mData(M2mData m2mData) {
		getM2mData().add(m2mData);
		m2mData.setM2mDevice(this);

		return m2mData;
	}

	public M2mData removeM2mData(M2mData m2mData) {
		getM2mData().remove(m2mData);
		m2mData.setM2mDevice(null);

		return m2mData;
	}

	public List<M2mDevicepostn> getM2mDevicepostns() {
		return this.m2mDevicepostns;
	}

	public void setM2mDevicepostns(List<M2mDevicepostn> m2mDevicepostns) {
		this.m2mDevicepostns = m2mDevicepostns;
	}

	public M2mDevicepostn addM2mDevicepostn(M2mDevicepostn m2mDevicepostn) {
		getM2mDevicepostns().add(m2mDevicepostn);
		m2mDevicepostn.setM2mDevice(this);

		return m2mDevicepostn;
	}

	public M2mDevicepostn removeM2mDevicepostn(M2mDevicepostn m2mDevicepostn) {
		getM2mDevicepostns().remove(m2mDevicepostn);
		m2mDevicepostn.setM2mDevice(null);

		return m2mDevicepostn;
	}

	public TtUser getTtUser() {
		return this.ttUser;
	}

	public void setTtUser(TtUser ttUser) {
		this.ttUser = ttUser;
	}

	public List<M2mNotification> getM2mNotifications() {
		return this.m2mNotifications;
	}

	public void setM2mNotifications(List<M2mNotification> m2mNotifications) {
		this.m2mNotifications = m2mNotifications;
	}

	public M2mNotification addM2mNotification(M2mNotification m2mNotification) {
		getM2mNotifications().add(m2mNotification);
		m2mNotification.setM2mDevice(this);

		return m2mNotification;
	}

	public M2mNotification removeM2mNotification(M2mNotification m2mNotification) {
		getM2mNotifications().remove(m2mNotification);
		m2mNotification.setM2mDevice(null);

		return m2mNotification;
	}

	public List<M2mProcessedata> getM2mProcessedata() {
		return this.m2mProcessedata;
	}

	public void setM2mProcessedata(List<M2mProcessedata> m2mProcessedata) {
		this.m2mProcessedata = m2mProcessedata;
	}

	public M2mProcessedata addM2mProcessedata(M2mProcessedata m2mProcessedata) {
		getM2mProcessedata().add(m2mProcessedata);
		m2mProcessedata.setM2mDevice(this);

		return m2mProcessedata;
	}

	public M2mProcessedata removeM2mProcessedata(M2mProcessedata m2mProcessedata) {
		getM2mProcessedata().remove(m2mProcessedata);
		m2mProcessedata.setM2mDevice(null);

		return m2mProcessedata;
	}

	public List<M2mResult> getM2mResults() {
		return this.m2mResults;
	}

	public void setM2mResults(List<M2mResult> m2mResults) {
		this.m2mResults = m2mResults;
	}

	public M2mResult addM2mResult(M2mResult m2mResult) {
		getM2mResults().add(m2mResult);
		m2mResult.setM2mDevice(this);

		return m2mResult;
	}

	public M2mResult removeM2mResult(M2mResult m2mResult) {
		getM2mResults().remove(m2mResult);
		m2mResult.setM2mDevice(null);

		return m2mResult;
	}

}
