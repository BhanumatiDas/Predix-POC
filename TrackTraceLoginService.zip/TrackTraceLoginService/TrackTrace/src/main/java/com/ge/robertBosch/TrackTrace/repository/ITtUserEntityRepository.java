package com.ge.robertBosch.TrackTrace.repository;

/** Copyright (c) 2013 GE Global Research. All rights reserved.
*
* The copyright to the computer software herein is the property of
* GE Global Research. The software may be used and/or copied only
* with the written permission of GE Global Research or in accordance
* with the terms and conditions stipulated in the agreement/contract
* under which the software has been supplied.
*/

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.robertBosch.TrackTrace.entity.TtUser;

/**
* This class models the spring-data repository for alarmevent entity. Apart form the standard operations supported by
* CRUD Repository, this class also supports customized named queries ,pagination, sorting and type safe queries using query-dsl.
* 
* @author 212350258
*/
@Repository
public interface ITtUserEntityRepository extends JpaRepository<TtUser, Integer>
{
	
	
	String CHECK_AVIALABLE_USER = "from TtUser ttUser where ttUser.userName=?1";


	List<TtUser> findByUserName(String username);
	
	
	@Query(CHECK_AVIALABLE_USER)
	TtUser findUser(String username);
	
	
}