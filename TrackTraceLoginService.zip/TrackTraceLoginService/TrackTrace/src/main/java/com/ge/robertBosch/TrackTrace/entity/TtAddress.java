package com.ge.robertBosch.TrackTrace.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the TT_ADDRESS database table.
 * 
 */
@Entity
@Table(name="TT_ADDRESS")
@NamedQuery(name="TtAddress.findAll", query="SELECT t FROM TtAddress t")
public class TtAddress implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TT_ADDRESS_ID_GENERATOR", sequenceName="TT_SEQ_ADDRS")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TT_ADDRESS_ID_GENERATOR")
	private long id;

	private String address1;

	private String address2;

	private String address3;

	private String country;

	@Column(name="PIN_CODE")
	private BigDecimal pinCode;

	@Column(name="STATE")
	private String state;

	//bi-directional many-to-one association to TtUser
	@ManyToOne
	@JoinColumn(name="USERID")
	private TtUser ttUser;

	public TtAddress() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAddress1() {
		return this.address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return this.address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return this.address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public BigDecimal getPinCode() {
		return this.pinCode;
	}

	public void setPinCode(BigDecimal pinCode) {
		this.pinCode = pinCode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public TtUser getTtUser() {
		return this.ttUser;
	}

	public void setTtUser(TtUser ttUser) {
		this.ttUser = ttUser;
	}

}
