package com.ge.predix.solsvc.training.alarmservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ge.predix.solsvc.training.alarmservice.entity.Models;


public interface IModelRepository extends JpaRepository<Models, Long>{
	
	/*@SuppressWarnings("javadoc")
	String INSERT_MODEL= "select a.priority, count(a) as number_of_alarms, a.patientId from AlarmEventEntity a group by a.priority, a.patientId"; //$NON-NLS-1$
	*/
	@Override
	List<Models> findAll();
	

}
