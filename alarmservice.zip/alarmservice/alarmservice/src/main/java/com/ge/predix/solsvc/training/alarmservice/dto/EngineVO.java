package com.ge.predix.solsvc.training.alarmservice.dto;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EngineVO implements Serializable {
	
	 private static final long serialVersionUID = 1L;
		
		private long id;	
		private String engineCycleSinceNew;
		private String engineTimeSinceNew;
	 	private String esn;
		private java.math.BigDecimal seriesId;	
		//private ModelVO model;
		/*private Set<PartVO> parts;
		private Set<ShopVisitVO> shopVisits;*/
		
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getEngineCycleSinceNew() {
			return engineCycleSinceNew;
		}
		public void setEngineCycleSinceNew(String engineCycleSinceNew) {
			this.engineCycleSinceNew = engineCycleSinceNew;
		}
		public String getEngineTimeSinceNew() {
			return engineTimeSinceNew;
		}
		public void setEngineTimeSinceNew(String engineTimeSinceNew) {
			this.engineTimeSinceNew = engineTimeSinceNew;
		}
		public String getEsn() {
			return esn;
		}
		public void setEsn(String esn) {
			this.esn = esn;
		}
		public java.math.BigDecimal getSeriesId() {
			return seriesId;
		}
		public void setSeriesId(java.math.BigDecimal seriesId) {
			this.seriesId = seriesId;
		}
		/*public ModelVO getModel() {
			return model;
		}
		public void setModel(ModelVO model) {
			this.model = model;
		}*/
		/*public Set<PartVO> getParts() {
			return parts;
		}
		public void setParts(Set<PartVO> parts) {
			this.parts = parts;
		}
		public Set<ShopVisitVO> getShopVisits() {
			return shopVisits;
		}
		public void setShopVisits(Set<ShopVisitVO> shopVisits) {
			this.shopVisits = shopVisits;
		}*/
		

}
