package com.ge.predix.solsvc.training.alarmservice.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the MODEL database table.
 * 
 */
@Entity
@Table(name = "EQUP_PROD_DTLS")
//@NamedQuery(name="Model.findAll", query="SELECT m FROM Model m")

public class OEE_Equipment_Entity_Dtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="OEE_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="OEE_ID_GENERATOR")
	private Integer id;

	@Column(name="EQUP_NAME")
	private String equipName;

	@Column(name="SHIFT_NUM")
	private BigDecimal shiftNum;
	
	@Column(name="BREAK")
	private BigDecimal equipBreak;
	
	@Column(name="BLOCKED_TIME")
	private BigDecimal blockedTime;
	
	@Column(name="STRAVED_TIME")
	private BigDecimal stravedTime;
	
	@Column(name="FAULT_TIME")
	private BigDecimal faultTime;
	
	@Column(name="IDEAL_CYCLE_TIME")
	private BigDecimal idealCycleTime;
	
	@Column(name="UPDATE_DATE")
	private Date updateDate;
	
	@Column(name="TOTAL_UNIT_PRODUCED")
	private Double totalUnitProduced;
	
	@Column(name="REJECTED_UNIT")
	private Double rejectedUnt;
	
	@Column(name="SHIFT_LENGTH")
	private BigDecimal shiftLength;
	
	@Column(name="SITE")
	private String site;
	
	
	@Column(name="SHIFT_NAME")
	private String shiftName;
	
	
	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getEquipName() {
		return equipName;
	}

	public void setEquipName(String equipName) {
		this.equipName = equipName;
	}

		

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	

	public Double getTotalUnitProduced() {
		return totalUnitProduced;
	}

	public void setTotalUnitProduced(Double totalUnitProduced) {
		this.totalUnitProduced = totalUnitProduced;
	}

	public Double getRejectedUnt() {
		return rejectedUnt;
	}

	public void setRejectedUnt(Double rejectedUnt) {
		this.rejectedUnt = rejectedUnt;
	}

	public OEE_Equipment_Entity_Dtl() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	public BigDecimal getIdealCycleTime() {
		return idealCycleTime;
	}

	public void setIdealCycleTime(BigDecimal idealCycleTime) {
		this.idealCycleTime = idealCycleTime;
	}

	public BigDecimal getShiftNum() {
		return shiftNum;
	}

	public void setShiftNum(BigDecimal shiftNum) {
		this.shiftNum = shiftNum;
	}

	public BigDecimal getEquipBreak() {
		return equipBreak;
	}

	public void setEquipBreak(BigDecimal equipBreak) {
		this.equipBreak = equipBreak;
	}

	public BigDecimal getBlockedTime() {
		return blockedTime;
	}

	public void setBlockedTime(BigDecimal blockedTime) {
		this.blockedTime = blockedTime;
	}

	public BigDecimal getStravedTime() {
		return stravedTime;
	}

	public void setStravedTime(BigDecimal stravedTime) {
		this.stravedTime = stravedTime;
	}

	public BigDecimal getFaultTime() {
		return faultTime;
	}

	public void setFaultTime(BigDecimal faultTime) {
		this.faultTime = faultTime;
	}

	public BigDecimal getShiftLength() {
		return shiftLength;
	}

	public void setShiftLength(BigDecimal shiftLength) {
		this.shiftLength = shiftLength;
	}

}
