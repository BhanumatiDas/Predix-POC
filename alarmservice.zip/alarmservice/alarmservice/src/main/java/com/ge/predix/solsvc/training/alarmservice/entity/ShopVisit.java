package com.ge.predix.solsvc.training.alarmservice.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="SHOP_VISIT")
public class ShopVisit implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SHOP_VISIT_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SHOP_VISIT_ID_GENERATOR")
	private long id;
   
	@Column(name="AMOUNT")
	private BigDecimal amount;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_VISIT")
	private Date dateOfVisit;

	@Column(name="NO_OF_CYCLES_SINCE_LAST_VISIT")
	private String noOfCyclesSinceLastVisit;

	@Column(name="NO_OF_CYCLES_SINCE_NEW")
	private String noOfCyclesSinceNew;

	@Column(name="WORKSCOPE")
	private String workscope;

	//bi-directional many-to-one association to Engine
	@ManyToOne
	@JoinColumn(name = "ENGINE_ID")
	private Engines engineShopvisit;

	public Engines getEngineShopvisit() {
		return engineShopvisit;
	}

	public void setEngineShopvisit(Engines engineShopvisit) {
		this.engineShopvisit = engineShopvisit;
	}

	public ShopVisit() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Date getDateOfVisit() {
		return this.dateOfVisit;
	}

	public void setDateOfVisit(Date dateOfVisit) {
		this.dateOfVisit = dateOfVisit;
	}

	public String getNoOfCyclesSinceLastVisit() {
		return this.noOfCyclesSinceLastVisit;
	}

	public void setNoOfCyclesSinceLastVisit(String noOfCyclesSinceLastVisit) {
		this.noOfCyclesSinceLastVisit = noOfCyclesSinceLastVisit;
	}

	public String getNoOfCyclesSinceNew() {
		return this.noOfCyclesSinceNew;
	}

	public void setNoOfCyclesSinceNew(String noOfCyclesSinceNew) {
		this.noOfCyclesSinceNew = noOfCyclesSinceNew;
	}

	public String getWorkscope() {
		return this.workscope;
	}

	public void setWorkscope(String workscope) {
		this.workscope = workscope;
	}

	/*public Engine getEngine() {
		return this.engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}
*/

}
