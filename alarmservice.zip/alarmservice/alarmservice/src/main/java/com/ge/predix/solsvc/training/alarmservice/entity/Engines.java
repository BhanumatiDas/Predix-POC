package com.ge.predix.solsvc.training.alarmservice.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ge.predix.solsvc.training.alarmservice.dto.EngineVO;
import com.ge.predix.solsvc.training.alarmservice.dto.ShopVisitVO;


@Entity
@Table(name = "Engine")
public class Engines implements Serializable {
	
private static final long serialVersionUID = 1L;
	
	

	@Id
	@SequenceGenerator(name="ENGINE_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ENGINE_ID_GENERATOR")
	private long id;

	@Column(name="ENGINE_CYCLE_SINCE_NEW")
	private String engineCycleSinceNew;

	@Column(name="ENGINE_TIME_SINCE_NEW")
	private String engineTimeSinceNew;
	
	@Column(name="ESN")
 	private String esn;

	@Column(name="SERIES_ID")
	private java.math.BigDecimal seriesId;

	
	public Models getModels() {
		return models;
	}

	public void setModels(Models models) {
		this.models = models;
	}

	@ManyToOne
	@JoinColumn(name = "MODEL_ID")
	private Models models;

	@OneToMany(fetch = FetchType.LAZY,mappedBy="enginepart")	
	private Set<Parts> parts;

	@OneToMany(fetch = FetchType.LAZY,mappedBy="engineShopvisit")	
	private Set<ShopVisit> shopVisits;

	/*public Engine(long id,String engineCycleSinceNew,String engineTimeSinceNew,String esn,BigDecimal seriesId,Set<ShopVisit> shopVisits,Set<Part> parts) {
       		super();    
       		this.id= id;
       		this.engineCycleSinceNew= engineCycleSinceNew;
       		this.engineTimeSinceNew= engineTimeSinceNew;
       		this.seriesId= seriesId;
       		this.esn= esn;
       		this.shopVisits= shopVisits;
       		this.parts= parts;
	}
	*/
	
	
	 public EngineVO toEngine()
	    {
		 EngineVO engineVO = new EngineVO();
		 List<ShopVisitVO> shopVisitVOs = new ArrayList<ShopVisitVO>();
		 engineVO.setEsn(this.esn);
		 engineVO.setId(this.id);
		 engineVO.setEngineCycleSinceNew(this.engineCycleSinceNew);
		 engineVO.setEngineTimeSinceNew(this.engineTimeSinceNew);
		 engineVO.setSeriesId(this.seriesId);
		 //shopVisitVOs.
		 //engineVO.g
		 
	       
	        return engineVO;
	    }
	 
	public Engines() {     
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEngineCycleSinceNew() {
		return this.engineCycleSinceNew;
	}

	public void setEngineCycleSinceNew(String engineCycleSinceNew) {
		this.engineCycleSinceNew = engineCycleSinceNew;
	}

	public String getEngineTimeSinceNew() {
		return this.engineTimeSinceNew;
	}

	public void setEngineTimeSinceNew(String engineTimeSinceNew) {
		this.engineTimeSinceNew = engineTimeSinceNew;
	}

	public String getEsn() {
		return this.esn;
	}

	public void setEsn(String esn) {
		this.esn = esn;
	}

	public java.math.BigDecimal getSeriesId() {
		return this.seriesId;
	}

	public void setSeriesId(java.math.BigDecimal seriesId) {
		this.seriesId = seriesId;
	}	
	public Set<Parts> getParts() {
		return this.parts;
	}

	public void setParts(Set<Parts> parts) {
		this.parts = parts;
	}

	/*public Part addPart(Part part) {
		getParts().add(part);
		part.setEngine(this);

		return part;
	}

	public Part removePart(Part part) {
		getParts().remove(part);
		part.setEngine(null);

		return part;
	}*/

	public Set<ShopVisit> getShopVisits() {
		return this.shopVisits;
	}

	public void setShopVisits(Set<ShopVisit> shopVisits) {
		this.shopVisits = shopVisits;
	}

	/*public ShopVisit addShopVisit(ShopVisit shopVisit) {
		getShopVisits().add(shopVisit);
		shopVisit.setEngine(this);

		return shopVisit;
	}

	public ShopVisit removeShopVisit(ShopVisit shopVisit) {
		getShopVisits().remove(shopVisit);
		shopVisit.setEngine(null);

		return shopVisit;
	}*/

}
