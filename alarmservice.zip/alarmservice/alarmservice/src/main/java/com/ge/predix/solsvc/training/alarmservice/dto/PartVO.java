package com.ge.predix.solsvc.training.alarmservice.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PartVO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private long id;
	private BigDecimal catalogPrice;
	private String category;
	private String iin;
	private String lifeRemainingPercent;
	private String llpInd;
	private String minorModule;
	private BigDecimal partCycleRemaining;
	private BigDecimal partCycleSinceNew;
	private BigDecimal partLlpCycle;
	private String partName;
	private String partNumber;
	private String partSerialNumber;
	private String qpe;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public BigDecimal getCatalogPrice() {
		return catalogPrice;
	}
	public void setCatalogPrice(BigDecimal catalogPrice) {
		this.catalogPrice = catalogPrice;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getIin() {
		return iin;
	}
	public void setIin(String iin) {
		this.iin = iin;
	}
	public String getLifeRemainingPercent() {
		return lifeRemainingPercent;
	}
	public void setLifeRemainingPercent(String lifeRemainingPercent) {
		this.lifeRemainingPercent = lifeRemainingPercent;
	}
	public String getLlpInd() {
		return llpInd;
	}
	public void setLlpInd(String llpInd) {
		this.llpInd = llpInd;
	}
	public String getMinorModule() {
		return minorModule;
	}
	public void setMinorModule(String minorModule) {
		this.minorModule = minorModule;
	}
	public BigDecimal getPartCycleRemaining() {
		return partCycleRemaining;
	}
	public void setPartCycleRemaining(BigDecimal partCycleRemaining) {
		this.partCycleRemaining = partCycleRemaining;
	}
	public BigDecimal getPartCycleSinceNew() {
		return partCycleSinceNew;
	}
	public void setPartCycleSinceNew(BigDecimal partCycleSinceNew) {
		this.partCycleSinceNew = partCycleSinceNew;
	}
	public BigDecimal getPartLlpCycle() {
		return partLlpCycle;
	}
	public void setPartLlpCycle(BigDecimal partLlpCycle) {
		this.partLlpCycle = partLlpCycle;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartSerialNumber() {
		return partSerialNumber;
	}
	public void setPartSerialNumber(String partSerialNumber) {
		this.partSerialNumber = partSerialNumber;
	}
	public String getQpe() {
		return qpe;
	}
	public void setQpe(String qpe) {
		this.qpe = qpe;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
