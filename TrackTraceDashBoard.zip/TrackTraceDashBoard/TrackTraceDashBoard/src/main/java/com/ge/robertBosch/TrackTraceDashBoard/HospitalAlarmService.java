package com.ge.robertBosch.TrackTraceDashBoard;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.robertBosch.TrackTraceDashBoard.dto.MachineDataVO;
import com.ge.robertBosch.TrackTraceDashBoard.dto.MachineDeviceVO;
import com.ge.robertBosch.TrackTraceDashBoard.dto.MachineMessageVO;
import com.ge.robertBosch.TrackTraceDashBoard.dto.MachineNotificationVO;
import com.ge.robertBosch.TrackTraceDashBoard.dto.MachineResultVO;
import com.ge.robertBosch.TrackTraceDashBoard.entity.M2mData;
import com.ge.robertBosch.TrackTraceDashBoard.entity.M2mDevice;
import com.ge.robertBosch.TrackTraceDashBoard.entity.M2mMessage;
import com.ge.robertBosch.TrackTraceDashBoard.entity.M2mNotification;
import com.ge.robertBosch.TrackTraceDashBoard.entity.M2mResult;
import com.ge.robertBosch.TrackTraceDashBoard.repository.IM2MDataRepository;
import com.ge.robertBosch.TrackTraceDashBoard.repository.IM2MDeviceRepository;
import com.ge.robertBosch.TrackTraceDashBoard.repository.IM2MNotificationRepository;
import com.ge.robertBosch.TrackTraceDashBoard.repository.IM2MResultRepository;


@RestController
public class HospitalAlarmService {
	
	@Autowired
	private IM2MResultRepository machineResultRepo;
	
	@Autowired
	private IM2MDeviceRepository machineDeviceRepo;
	
	@Autowired
	private IM2MDataRepository machineDataRepo;
	
	@Autowired
	private IM2MNotificationRepository machineNotificationRepo;

		
	@RequestMapping("/getMachineResult")
	public @ResponseBody MachineResultVO getMachineResult() {
		
		MachineResultVO machineResultVO = null;
		try{
		List<M2mResult> m2mResults = machineResultRepo.findAll();
		Integer ok = 0;
		Integer nok = 0;
		//Integer quality = null;
		System.out.println("m2mResults size********" + m2mResults.size());
		for(M2mResult result : m2mResults){
			System.out.println("HospitalAlarmService.getMachineResult() Inside loop");
			machineResultVO = new MachineResultVO();
            if(result.getTighteningstatus().equalsIgnoreCase("OK")){
            	ok++;
            }else{
            	nok++;
            }
            System.out.println("Ok is " + ok);
            Double  quality  = (double) Math.round((((ok)/(m2mResults.size()))*10)/10);
            System.out.println("quality :" + quality);
            DecimalFormat df=new DecimalFormat("#.00");  
            String qualitys= df.format(quality);
            System.out.println("qualitys" + qualitys);
            machineResultVO.setTotalQuality(qualitys);
           
			}
		}
		catch(Exception e){
			
			System.out.println("HospitalAlarmService.getMachineResult() exception is :" + e);
		}
		return machineResultVO;
		
		
	}
	
	@RequestMapping("/getToolFeetCount")
	public @ResponseBody String getToolFeetCount() {
		Integer toolCont = null;
		ObjectMapper objectMapper=new ObjectMapper();
		String jsonData="";
		System.out.println("HospitalAlarmService.getToolFeetCount()!!!!!!!");
		try{
			//machineDeviceRepo.findAll();
			
			toolCont = machineDeviceRepo.getToolFleetCount();
			System.out.println("toolCont" + toolCont);
		
			jsonData=objectMapper.writeValueAsString(toolCont);
			
		}catch(Exception e){
			System.out.println("HospitalAlarmService.getToolFeetCount()");
		}
		return jsonData;
		
	}
	
	
	@RequestMapping("/getTighteningProcessingCount")
	public @ResponseBody String getTighteningProcessingCount() {
		Integer toolCont = null;
		ObjectMapper objectMapper=new ObjectMapper();
		String jsonData="";
		try{
			toolCont = machineDataRepo.getTighteningProcessingCount();
			jsonData=objectMapper.writeValueAsString(toolCont);
			
		}catch(Exception e){
			System.out.println("HospitalAlarmService.getTighteningProcessingCount()");
		}
		return jsonData;
		
	}
	
	
	@RequestMapping("/getMachineNotification")
	public @ResponseBody List<MachineNotificationVO> getMachineNotification() {
		
		List<MachineNotificationVO> machineNotificationVOs = new ArrayList<MachineNotificationVO>();
		MachineNotificationVO machineNotificationVO = null;
		MachineDeviceVO machineDeviceVo = null;
		M2mDevice device = null;
		M2mMessage m2mMessage = null;
		MachineMessageVO machineMessageVO = null;
		System.out.println("HospitalAlarmService.getMachineNotification()");
		try{
			List<M2mNotification> notification = machineNotificationRepo.findAll();
			
			System.out.println("notification : " + notification.size());
			
			for(M2mNotification notificationList : notification){
				machineNotificationVO = new MachineNotificationVO();
				machineNotificationVO.setId(notificationList.getId());
				machineNotificationVO.setCreated(notificationList.getCreated());
				machineNotificationVO.setNotificationType(notificationList.getNotificationType());
				machineNotificationVO.setSeverity(notificationList.getSeverity());
				machineNotificationVO.setStatus(notificationList.getStatus());
				machineNotificationVO.setAcknowledged(notificationList.getAcknowledged());
						
				device = notificationList.getM2mDevice();
				machineDeviceVo = new  MachineDeviceVO();
				machineDeviceVo.setConnection(device.getConnection());
				machineDeviceVo.setCreated(device.getCreated());
				machineDeviceVo.setId(device.getId());
				machineDeviceVo.setModel(device.getModel());
				machineDeviceVo.setName(device.getName());
				machineDeviceVo.setPort(device.getPort());
				machineDeviceVo.setSerialno(device.getSerialno());
				machineDeviceVo.setStatus(device.getStatus());
				machineDeviceVo.setType(device.getType());
			//	machineDeviceVo.se
				
				m2mMessage = notificationList.getM2mMessage();
				machineMessageVO = new MachineMessageVO();
				
				machineMessageVO.setId(m2mMessage.getId());
				machineMessageVO.setContent(m2mMessage.getContent());
				machineMessageVO.setImg(m2mMessage.getImg());
				machineMessageVO.setTitle(m2mMessage.getTitle());
								
				machineNotificationVO.setMachineDeviceVo(machineDeviceVo);
				machineNotificationVO.setMessageVO(machineMessageVO);
				
				
				
				machineNotificationVOs.add(machineNotificationVO);
			}
		}
			catch(Exception e){
			System.out.println("HospitalAlarmService.getMachineNotification()" + e);
		}
		return machineNotificationVOs;
		
	}
	
	@RequestMapping("/getMachineDevice")
	public @ResponseBody List<MachineDeviceVO> getMachineDevice() {
		List<MachineDeviceVO> deviceVOs = new ArrayList<MachineDeviceVO>();
		MachineDeviceVO machineDeviceVO = null;

		try {
			List<M2mDevice> devices = machineDeviceRepo.findAll();

			for (M2mDevice device : devices) {
				machineDeviceVO = new MachineDeviceVO();
				machineDeviceVO.setConnection(device.getConnection());
				machineDeviceVO.setCreated(device.getCreated());
				machineDeviceVO.setId(device.getId());
				machineDeviceVO.setModel(device.getModel());
				machineDeviceVO.setName(device.getName());
				machineDeviceVO.setPort(device.getPort());
				machineDeviceVO.setSerialno(device.getSerialno());
				machineDeviceVO.setStatus(device.getStatus());
				machineDeviceVO.setType(device.getType());
				machineDeviceVO.setImei(device.getImei());
				machineDeviceVO.setIp(device.getIp());
				deviceVOs.add(machineDeviceVO);
			}

		} catch (Exception e) {

		}
		return deviceVOs;

	}
	
	@RequestMapping("/getMachineDeviceDetails/{deviceId}")
	public @ResponseBody List<Map<String,Object>> getMachineDevice(@PathVariable("deviceId") Long deviceId) {
		Map<String,Object> objMap  = null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try{
		
			List<Object []> retList = machineDeviceRepo.getDeviceDetailsById(deviceId);
			
			for(int i = 0; i < retList.size(); i++){
				objMap	= new HashMap<String, Object>();
				objMap.put("model", (retList.get(i))[0]);
				objMap.put("deviceName", (retList.get(i))[1]);
				objMap.put("connection", (retList.get(i))[2]);
				objMap.put("status", (retList.get(i))[3]);
				objMap.put("accuracy", (retList.get(i))[4]);
				
				objMap.put("x", (retList.get(i))[5]);
				objMap.put("y", (retList.get(i))[6]);
				objMap.put("zone", (retList.get(i))[7]);
				objMap.put("tighteingid", (retList.get(i))[8]);
				
				objMap.put("tighteningstatus", (retList.get(i))[9]);
				objMap.put("tighteningprogram", (retList.get(i))[10]);
				objMap.put("serialno", (retList.get(i))[11]);
				objMap.put("type", (retList.get(i))[12]);
				//objMap.put("processId", (retList.get(i))[13]);
				//objMap.put("data", (retList.get(i))[14]);
							
				
				list.add(objMap);
				
			}
			
			
			System.out.println("BookingController.getMachineDevice()");
	
			}
		catch(Exception e)
		{
			System.out.println("BookingController.getMachineDevice()" + e);
		}
		
		return list;
		
		
	}
	
	@RequestMapping("/getMachineDeviceData")
	public @ResponseBody List<MachineDataVO> getMachineDeviceData() {
		List<MachineDataVO> machineDatavo = new ArrayList<MachineDataVO>();
		MachineDataVO dataVO = null;
		try{
			List<M2mData> listData = machineDataRepo.findAll();
			System.out.println("listData");
			for(M2mData list : listData){
				dataVO = new MachineDataVO();
				dataVO.setData(list.getData());
				dataVO.setProcessId(list.getProcessId());
				dataVO.setTighteingid(list.getTighteingid());
				machineDatavo.add(dataVO);
				
			}
			
			/*List<Object []> retList = machineDataRepo.findDataById();
			System.out.println("retList" + retList);
			for(int i = 0; i < retList.size(); i++){
				System.out.println( "Data is::"+  (retList.get(i))[0]);
			}*/
			
						
		}catch(Exception e){
			System.out.println("HospitalAlarmService.getMachineDevice()" + e);
		}
		return machineDatavo;
		
	}
	@RequestMapping("/getMachineDataByDeviceId/{deviceId}")
	public @ResponseBody List<Map<Object,Object>> getMachineDataByDeviceId(@PathVariable("deviceId") Long deviceId) {
		/*List<MachineDataVO> machineDatavo = new ArrayList<MachineDataVO>();
		MachineDataVO dataVO = null;*/

		List<Object> retListData = new ArrayList<Object>();
		Map<Object,Object> objMap  = null;
		List<Map<Object,Object>> list = new ArrayList<Map<Object,Object>>();
		try{
			System.out
					.println("HospitalAlarmService.getMachineDataByDeviceId()***********");
			List<Object []> retList = machineDataRepo.getMachineDataByDeviceId(deviceId);
			
			System.out.println("listData!!!!!!!!!!" + retList);
			for(int i = 0; i < retList.size(); i++){
				objMap	= new HashMap<Object, Object>();
				objMap.put("processId", (retList.get(i))[1]);
				String str  = (String) retList.get(i)[0];
				str = str.replaceAll("\\n", "");
				str = str.replaceAll("\\t", "");
				str = str.replaceAll("\\\\", "");
				retListData.add(str);
				System.out
						.println("String is data: " + retListData);
				/*
				ObjectMapper objectMapper=new ObjectMapper();
				String jsonData=objectMapper.writeValueAsString(str);
				
				System.out
				.println("jsonData data: " + jsonData);*/
				
				objMap.put("data", retListData);
				
				
				list.add(objMap);
				
			}
			
						
		}catch(Exception e){
			System.out.println("HospitalAlarmService.getMachineDataByDeviceId()" + e);
		}
		return list;
		
	}
	
	
	
}
