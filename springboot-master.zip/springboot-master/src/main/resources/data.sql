INSERT INTO booking(booking_name) values('Salva');
INSERT INTO booking(booking_name) values('Manu');
INSERT INTO booking(booking_name) values('Diego');