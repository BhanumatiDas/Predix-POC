package com.ge.test;

public class QueryContant {
	
	public static final String GET_FLIGHT_QUERY="select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId";

}
