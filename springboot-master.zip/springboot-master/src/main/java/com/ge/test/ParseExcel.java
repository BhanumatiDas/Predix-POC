package com.ge.test;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class ParseExcel {
	
	
	public static void main(String ar[]){
		
		  String fileName = "D:\\GEGDC\\SM358224\\Tableau\\invoice.csv";
		
		  printSheetData(fileName);
	}
	
	public static void printSheetData(
			String fileName) {

		

		try {
			FileInputStream myInput = new FileInputStream(fileName);

			POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);

			HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);

			HSSFSheet mySheet = myWorkBook.getSheetAt(0);

			Iterator<Row> rowIter = mySheet.rowIterator();

			while (rowIter.hasNext()) {
				HSSFRow myRow = (HSSFRow) rowIter.next();
				Iterator<Cell> cellIter = myRow.cellIterator();
			
				while (cellIter.hasNext()) {
					HSSFCell myCell = (HSSFCell) cellIter.next();
					int columnIndex = myCell.getColumnIndex();

					switch (columnIndex) {
					case 1:
						String invoiceNum = ((String) getCellValue(myCell));
						System.out.println("ParseExcel.printSheetData()" + invoiceNum);
						break;
					case 2:
						String date  = ((String) getCellValue(myCell));
						System.out.println("ParseExcel.printSheetData()" + date);
						break;
					case 3:
						String type = ((String) getCellValue(myCell));
						System.out.println("ParseExcel.printSheetData()" + type);
						break;
					case 4:
						String curr = ((String) getCellValue(myCell));
						System.out.println("ParseExcel.printSheetData()" + curr);
						break;
					}
				}
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}

	private static Object getCellValue(Cell cell) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();

		case Cell.CELL_TYPE_BOOLEAN:
			return cell.getBooleanCellValue();

		case Cell.CELL_TYPE_NUMERIC:
			return cell.getNumericCellValue();
		}

		return null;
	}

}
