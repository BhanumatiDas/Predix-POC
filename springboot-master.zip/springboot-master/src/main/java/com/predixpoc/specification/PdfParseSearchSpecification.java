package com.predixpoc.specification;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sopra.entities.PdfParser;

public class PdfParseSearchSpecification implements Specification<PdfParser> {
	
	private PdfParser filter;
	
	//private ScpDemandId filter1;
	
	public PdfParseSearchSpecification(PdfParser filter){
		super();
		this.filter = filter;
		//this.filter1 = filter1;
	}
	
	
	@Override
	public Predicate toPredicate(Root<PdfParser> root, CriteriaQuery<?> query,
			CriteriaBuilder cb) {
			Predicate p = cb.disjunction();
			
			List<Predicate> predicates = new ArrayList<>();
			if (null != filter.getFileName() && "" != filter.getFileName()) {
				predicates.add(cb.equal(root.get("fileName"),
						filter.getFileName()));
			}
			if ((null != filter.getAuthor() && "" != filter.getAuthor())) {
				predicates.add(cb.and(cb.equal(root.get("author"),
						filter.getAuthor())));
			}
			if (null != filter.getPurposeType() && "" != filter.getPurposeType()) {
				predicates.add(cb.and(cb.equal(root.get("purposeType"),
						filter.getPurposeType())));
			}
			if (filter.getModality() != null && "" != filter.getModality()) {
				predicates.add(cb.and(cb.equal(root.get("modality"),
						filter.getModality())));
			}
			if (filter.getFileType() != null
					&& "" != filter.getFileType()) {
				predicates.add(cb.and(cb.equal(root.get("fileType"),
						filter.getFileType())));
			}
			
			if (filter.getHeader() != null
					&& "" != filter.getHeader()) {
				predicates.add(cb.and(cb.like(
		                  root.<String>get("header"), "%" + filter.getHeader() + "%")));
			}
				
		
			/*List<Predicate> predicates = new ArrayList<>();
		 	CriteriaQuery<ScpDemandId> criteriaLogin = cb.createQuery(ScpDemandId.class);
			Root<ScpDemandId> rootLoginVO = criteriaLogin.from(ScpDemandId.class);
			Root<GetsDemand> rootStatusVO = criteriaLogin.from(GetsDemand.class);
			
			Predicate predicateJoin = cb.equal(rootLoginVO
					.get("id"),
					rootStatusVO.get("scpDemandId").ge);
			predicates.add(predicateJoin);
			*/

		
		 //cb.isTrue(owner.get(attributeName)));
		
		/*if (null!= filter.getFirstName() && ""!= filter.getFirstName()) {
			predicates.add(cb.equal(root.get("firstName"),
					filter.getFirstName()));
		}  if ((null!= filter.getLastName() && ""!=  filter.getLastName())) {
			predicates.add(cb.and(cb.equal(root.get("lastName"),
					filter.getLastName())));
		}  if( null!=  filter.getAge()) {
			predicates.add(cb.and(cb.equal(root.get("age"), filter.getAge())));
		}  if (filter.getDepartment() != null && ""!= filter.getDepartment()) {
			predicates.add(cb.and(cb.equal(root.get("department"),
					filter.getDepartment())));
		}*/
		
		/*predicates.add(cb.and(arg0));

		 if (filter.getFirstName() != null && filter.getLastName() != null && filter.getAge()!=null && filter.getDepartment()!=null ) {
	            p.getExpressions().add(
	                    cb.and(cb.equal(root.get("firstName"), filter.getFirstName()),
	                            cb.equal(root.get("age"), filter.getAge())));
	        }
*/
		return andTogether(predicates, cb);
	}
	
	private Predicate andTogether(List<Predicate> predicates, CriteriaBuilder cb) {
	    return cb.and(predicates.toArray(new Predicate[0]));
	  }
	

	

}
