package com.predixpoc.specification;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sopra.entities.FleetData;
import com.sopra.entities.FleetData2;
import com.sopra.entities.FlightMaster;

public class FleetSearchSpecification implements Specification<FleetData2> {
	
	private FleetData2 filter;
	
	private String flightDate; 
	private String flightTime;
	private String recordType;
	private String triggerChannel;
	private String startTime;
	private String endTime;
	
	//private ScpDemandId filter1;
	
/*	public FleetSearchSpecification(FleetData filter){
		super();
		this.filter = filter;
		//this.filter1 = filter1;
	}*/
	
	
	public FleetSearchSpecification(String flightDate, String flightTime,
			String recordType, String triggerChannel, String startTime,
			String endTime) {
		// TODO Auto-generated constructor stub
		
		this.flightDate= flightDate;
		this.flightTime= flightTime;
		this.recordType= recordType;
		this.triggerChannel= triggerChannel;
		this.startTime= startTime;
		this.endTime= endTime;
		
	}


	@Override
	public Predicate toPredicate(Root<FleetData2> root, CriteriaQuery<?> query,
			CriteriaBuilder cb) {
			Predicate p = cb.disjunction();
			
			List<Predicate> predicates = new ArrayList<>();
			
			
			CriteriaQuery<FlightMaster> criteriaFlightMaster = cb.createQuery(FlightMaster.class);
			CriteriaQuery<FleetData> criteriaFletDat = cb.createQuery(FleetData.class);
			Root<FlightMaster> rootFMVO = criteriaFlightMaster.from(FlightMaster.class);
			Root<FleetData> rootFleetVo= criteriaFletDat.from(FleetData.class);
			
			
			 Join address = rootFMVO.join("address", JoinType.LEFT); 
			
			
		/*	CriteriaQuery<FleetData> querys = cb.createQuery(FleetData.class);
			Root<FlightMaster> teacher = querys.from(FlightMaster.class);
			Join<FlightMaster, FleetData> phones = teacher.join("flightId");
			query.select(phones).where(cb.equal(teacher.get("firstName"), "prasad"));*/
			
			
			
			CriteriaQuery<FlightMaster> criteriaFlightMaste1r = cb.createQuery(FlightMaster.class);
	            Root<FlightMaster> project = criteriaFlightMaste1r.from(FlightMaster.class);
	            Join<FlightMaster, FleetData> sqEmp = project.join("flightId");
	            
	            /* Predicate predicateJoin = sqEmp;*/
	           /* criteriaFlightMaste1r.select(sqEmp).where(cb.equal(project.get("flightId"),
	            		cb.equal(sqEmp.)    cb.parameter(String.class, projectName)));*/
	         
	          
			
			
		
		/*	Predicate predicateJoin = cb.equal(rootFMVO
					.get("flightId"),
					rootFleetVo.get("flightMaster").get("flightId"));*/
		/*	predicates.add(predicateJoin);
			*/

			
			
			
		/*	if (null != filter.getItemNumber() && "" != filter.getItemNumber()) {
				predicates.add(cb.equal(root.get("itemNumber"),
						filter.getItemNumber()));
			}
			if ((null != filter.getBuyerName() && "" != filter.getBuyerName())) {
				predicates.add(cb.and(cb.equal(root.get("buyerName"),
						filter.getBuyerName())));
			}
			if (null != filter.getSupplierName() && "" != filter.getSupplierName()) {
				predicates.add(cb.and(cb.equal(root.get("supplierName"),
						filter.getSupplierName())));
			}
			if (filter.getSupplierCode() != null && "" != filter.getSupplierCode()) {
				predicates.add(cb.and(cb.equal(root.get("supplierCode"),
						filter.getSupplierCode())));
			}
			if (filter.getBuissnessUnit() != null
					&& "" != filter.getBuissnessUnit()) {
				predicates.add(cb.and(cb.equal(root.get("buissnessUnit"),
						filter.getBuissnessUnit())));
			}*/
				
		
			/*List<Predicate> predicates = new ArrayList<>();
		 	CriteriaQuery<ScpDemandId> criteriaLogin = cb.createQuery(ScpDemandId.class);
			Root<ScpDemandId> rootLoginVO = criteriaLogin.from(ScpDemandId.class);
			Root<GetsDemand> rootStatusVO = criteriaLogin.from(GetsDemand.class);
			
			Predicate predicateJoin = cb.equal(rootLoginVO
					.get("id"),
					rootStatusVO.get("scpDemandId").ge);
			predicates.add(predicateJoin);
			*/

		
		 //cb.isTrue(owner.get(attributeName)));
		
		/*if (null!= filter.getFirstName() && ""!= filter.getFirstName()) {
			predicates.add(cb.equal(root.get("firstName"),
					filter.getFirstName()));
		}  if ((null!= filter.getLastName() && ""!=  filter.getLastName())) {
			predicates.add(cb.and(cb.equal(root.get("lastName"),
					filter.getLastName())));
		}  if( null!=  filter.getAge()) {
			predicates.add(cb.and(cb.equal(root.get("age"), filter.getAge())));
		}  if (filter.getDepartment() != null && ""!= filter.getDepartment()) {
			predicates.add(cb.and(cb.equal(root.get("department"),
					filter.getDepartment())));
		}*/
		
		/*predicates.add(cb.and(arg0));

		 if (filter.getFirstName() != null && filter.getLastName() != null && filter.getAge()!=null && filter.getDepartment()!=null ) {
	            p.getExpressions().add(
	                    cb.and(cb.equal(root.get("firstName"), filter.getFirstName()),
	                            cb.equal(root.get("age"), filter.getAge())));
	        }
*/
		return andTogether(predicates, cb);
	}
	
	private Predicate andTogether(List<Predicate> predicates, CriteriaBuilder cb) {
	    return cb.and(predicates.toArray(new Predicate[0]));
	  }


	public FleetData2 getFilter() {
		return filter;
	}


	public void setFilter(FleetData2 filter) {
		this.filter = filter;
	}


	public String getFlightDate() {
		return flightDate;
	}


	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}


	public String getFlightTime() {
		return flightTime;
	}


	public void setFlightTime(String flightTime) {
		this.flightTime = flightTime;
	}


	public String getRecordType() {
		return recordType;
	}


	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}


	public String getTriggerChannel() {
		return triggerChannel;
	}


	public void setTriggerChannel(String triggerChannel) {
		this.triggerChannel = triggerChannel;
	}


	public String getStartTime() {
		return startTime;
	}


	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}


	public String getEndTime() {
		return endTime;
	}


	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}


	

	

}
