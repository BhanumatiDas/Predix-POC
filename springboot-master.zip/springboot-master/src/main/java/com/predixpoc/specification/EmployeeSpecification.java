package com.predixpoc.specification;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sopra.entities.Employee;

public class EmployeeSpecification implements Specification<Employee> {
	
	private Employee filter;
	
	public EmployeeSpecification(Employee filter){
		super();
		this.filter = filter;
	}

	@Override
	public Predicate toPredicate(Root<Employee> root, CriteriaQuery<?> arg1,
			CriteriaBuilder cb) {
		Predicate p = cb.disjunction();
		
		List<Predicate> predicates = new ArrayList<>();

		
		/*if (filter.getFirstName() != null) {
            p.getExpressions()
                    .add(cb.equal(root.get("firstName"), filter.getFirstName()));
        }else if(filter.getLastName() != null){
        	 p.getExpressions().add(cb.and(arg0))
        	
        }*/ 
		//StringUtils.isn
		if (null!= filter.getFirstName() && ""!= filter.getFirstName()) {
			predicates.add(cb.equal(root.get("firstName"),
					filter.getFirstName()));
		}  if ((null!= filter.getLastName() && ""!=  filter.getLastName())) {
			predicates.add(cb.and(cb.equal(root.get("lastName"),
					filter.getLastName())));
		}  if( null!=  filter.getAge()) {
			predicates.add(cb.and(cb.equal(root.get("age"), filter.getAge())));
		}  if (filter.getDepartment() != null && ""!= filter.getDepartment()) {
			predicates.add(cb.and(cb.equal(root.get("department"),
					filter.getDepartment())));
		}
		
		/*predicates.add(cb.and(arg0));

		 if (filter.getFirstName() != null && filter.getLastName() != null && filter.getAge()!=null && filter.getDepartment()!=null ) {
	            p.getExpressions().add(
	                    cb.and(cb.equal(root.get("firstName"), filter.getFirstName()),
	                            cb.equal(root.get("age"), filter.getAge())));
	        }
*/
		return andTogether(predicates, cb);
	}
	
	private Predicate andTogether(List<Predicate> predicates, CriteriaBuilder cb) {
	    return cb.and(predicates.toArray(new Predicate[0]));
	  }
	

	

}
