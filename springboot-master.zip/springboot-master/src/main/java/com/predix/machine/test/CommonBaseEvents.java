package com.predix.machine.test;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

@XmlRootElement
@XmlType(namespace="http://www.ibm.com/AC/commonbaseevent1_0_1")
public class CommonBaseEvents {

	private ExtendedDataElements extendedDataElements;
	
	private String version;
	  
	private String globalInstanceId;
	   
	private String extensionName;
	  
	private XMLGregorianCalendar creationTime;
	  
	private Integer severity;
	   
	private Integer priority;
	  
	private Integer sequenceNumber;
	   
	private Integer repeatCount;
	   
	private Integer elapsedTime;

	public ExtendedDataElements getExtendedDataElements() {
		return extendedDataElements;
	}

	@XmlElement
	public void setExtendedDataElements(ExtendedDataElements extendedDataElements) {
		this.extendedDataElements = extendedDataElements;
	}

	public String getVersion() {
		return version;
	}
	
	@XmlAttribute
	public void setVersion(String version) {
		this.version = version;
	}

	public String getGlobalInstanceId() {
		return globalInstanceId;
	}
	@XmlAttribute
	public void setGlobalInstanceId(String globalInstanceId) {
		this.globalInstanceId = globalInstanceId;
	}

	public String getExtensionName() {
		return extensionName;
	}
	@XmlAttribute
	public void setExtensionName(String extensionName) {
		this.extensionName = extensionName;
	}

	public XMLGregorianCalendar getCreationTime() {
		return creationTime;
	}
	@XmlAttribute
	@XmlSchemaType(name = "dateTime")
	public void setCreationTime(XMLGregorianCalendar creationTime) {
		this.creationTime = creationTime;
	}

	public Integer getSeverity() {
		return severity;
	}
	@XmlAttribute
	public void setSeverity(Integer severity) {
		this.severity = severity;
	}

	public Integer getPriority() {
		return priority;
	}
	@XmlAttribute
	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}
	@XmlAttribute
	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public Integer getRepeatCount() {
		return repeatCount;
	}
	@XmlAttribute
	public void setRepeatCount(Integer repeatCount) {
		this.repeatCount = repeatCount;
	}

	public Integer getElapsedTime() {
		return elapsedTime;
	}
	@XmlAttribute
	public void setElapsedTime(Integer elapsedTime) {
		this.elapsedTime = elapsedTime;
	}
	
	
	
	
	
}
