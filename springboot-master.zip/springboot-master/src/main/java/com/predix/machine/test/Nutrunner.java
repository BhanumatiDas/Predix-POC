package com.predix.machine.test;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

import com.predix.machine.poc.ConfigurationType;
import com.predix.machine.poc.StatusType;

public class Nutrunner {
	
	
	private String displayname;
	
	private Configuration configuration;
	  
    private Status status;

	public String getDisplayname() {
		return displayname;
	}

	@XmlAttribute
	public void setDisplayname(String displayname) {
		this.displayname = displayname;
	}

	public Configuration getConfiguration() {
		return configuration;
	}

	@XmlElement
	public void setConfiguration(Configuration configuration) {
		this.configuration = configuration;
	}

	public Status getStatus() {
		return status;
	}

	@XmlElement
	public void setStatus(Status status) {
		this.status = status;
	}

}
