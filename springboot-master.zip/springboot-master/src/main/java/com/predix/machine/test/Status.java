package com.predix.machine.test;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

public class Status {
	
	private BigDecimal lastMaintenanceTS;
	   
	private BigDecimal totalCyclesTS;
    
	private BigDecimal totalCyclesSinceLastMaintenanceTS;
   
	private BigDecimal currentTorque;
   
	private BigDecimal currentTorqueTS;
   
	private BigDecimal currentAngle;
   
	private BigDecimal currentAngleTS;
    
	private String nutrunnerStatus;
    
	private BigDecimal nutrunnerStatusTS;
   
	private BigDecimal batteryStatusTS;
   
	private BigDecimal systemStatusTS;

	public BigDecimal getLastMaintenanceTS() {
		return lastMaintenanceTS;
	}

	@XmlElement
	public void setLastMaintenanceTS(BigDecimal lastMaintenanceTS) {
		this.lastMaintenanceTS = lastMaintenanceTS;
	}

	public BigDecimal getTotalCyclesTS() {
		return totalCyclesTS;
	}
	@XmlElement
	public void setTotalCyclesTS(BigDecimal totalCyclesTS) {
		this.totalCyclesTS = totalCyclesTS;
	}

	public BigDecimal getTotalCyclesSinceLastMaintenanceTS() {
		return totalCyclesSinceLastMaintenanceTS;
	}
	@XmlElement
	public void setTotalCyclesSinceLastMaintenanceTS(
			BigDecimal totalCyclesSinceLastMaintenanceTS) {
		this.totalCyclesSinceLastMaintenanceTS = totalCyclesSinceLastMaintenanceTS;
	}

	public BigDecimal getCurrentTorque() {
		return currentTorque;
	}
	@XmlElement
	public void setCurrentTorque(BigDecimal currentTorque) {
		this.currentTorque = currentTorque;
	}

	public BigDecimal getCurrentTorqueTS() {
		return currentTorqueTS;
	}
	@XmlElement
	public void setCurrentTorqueTS(BigDecimal currentTorqueTS) {
		this.currentTorqueTS = currentTorqueTS;
	}

	public BigDecimal getCurrentAngle() {
		return currentAngle;
	}
	@XmlElement
	public void setCurrentAngle(BigDecimal currentAngle) {
		this.currentAngle = currentAngle;
	}

	public BigDecimal getCurrentAngleTS() {
		return currentAngleTS;
	}
	@XmlElement
	public void setCurrentAngleTS(BigDecimal currentAngleTS) {
		this.currentAngleTS = currentAngleTS;
	}

	public String getNutrunnerStatus() {
		return nutrunnerStatus;
	}
	@XmlElement
	public void setNutrunnerStatus(String nutrunnerStatus) {
		this.nutrunnerStatus = nutrunnerStatus;
	}

	public BigDecimal getNutrunnerStatusTS() {
		return nutrunnerStatusTS;
	}
	@XmlElement
	public void setNutrunnerStatusTS(BigDecimal nutrunnerStatusTS) {
		this.nutrunnerStatusTS = nutrunnerStatusTS;
	}

	public BigDecimal getBatteryStatusTS() {
		return batteryStatusTS;
	}
	@XmlElement
	public void setBatteryStatusTS(BigDecimal batteryStatusTS) {
		this.batteryStatusTS = batteryStatusTS;
	}

	public BigDecimal getSystemStatusTS() {
		return systemStatusTS;
	}
	@XmlElement
	public void setSystemStatusTS(BigDecimal systemStatusTS) {
		this.systemStatusTS = systemStatusTS;
	}

   


}
