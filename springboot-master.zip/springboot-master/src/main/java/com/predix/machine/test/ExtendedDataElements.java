package com.predix.machine.test;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

import com.predix.machine.poc.ChildrenType;

public class ExtendedDataElements {
	
		
	    private String values;
	   
	    private ChildrenType children;
	   
	    private String name;
	   
	    private String type;

	    /**
	     * Gets the value of the values property.
	     * 
	     * @return
	     *     possible object is
	     *     {@link String }
	     *     
	     */
	    public String getValues() {
	        return values;
	    }

	    /**
	     * Sets the value of the values property.
	     * 
	     * @param value
	     *     allowed object is
	     *     {@link String }
	     *     
	     */
	    @XmlElement
	    public void setValues(String value) {
	        this.values = value;
	    }

	    /**
	     * Gets the value of the children property.
	     * 
	     * @return
	     *     possible object is
	     *     {@link ChildrenType }
	     *     
	     */
	    public ChildrenType getChildren() {
	        return children;
	    }

	    /**
	     * Sets the value of the children property.
	     * 
	     * @param value
	     *     allowed object is
	     *     {@link ChildrenType }
	     *     
	     */
	    @XmlElement
	    public void setChildren(ChildrenType value) {
	        this.children = value;
	    }

	    /**
	     * Gets the value of the name property.
	     * 
	     * @return
	     *     possible object is
	     *     {@link String }
	     *     
	     */
	    public String getName() {
	        return name;
	    }

	    /**
	     * Sets the value of the name property.
	     * 
	     * @param value
	     *     allowed object is
	     *     {@link String }
	     *     
	     */
	    @XmlElement
	    public void setName(String value) {
	        this.name = value;
	    }

	    /**
	     * Gets the value of the type property.
	     * 
	     * @return
	     *     possible object is
	     *     {@link String }
	     *     
	     */
	    public String getType() {
	        return type;
	    }

	    /**
	     * Sets the value of the type property.
	     * 
	     * @param value
	     *     allowed object is
	     *     {@link String }
	     *     
	     */
	    @XmlElement
	    public void setType(String value) {
	        this.type = value;
	    }

}
