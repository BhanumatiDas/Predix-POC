package com.predix.machine.test;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

public class Configuration {

	private BigDecimal programTS;

	public BigDecimal getProgramTS() {
		return programTS;
	}

	@XmlElement
	public void setProgramTS(BigDecimal programTS) {
		this.programTS = programTS;
	}
}
