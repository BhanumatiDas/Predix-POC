package com.sopra.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the PARKING_ZONE_DETAIL database table.
 * 
 */
@Entity
@Table(name="PARKING_ZONE_DETAIL")
@NamedQuery(name="ParkingZoneDetail.findAll", query="SELECT p FROM ParkingZoneDetail p")
public class ParkingZoneDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARKING_ZONE_DETAIL_ZONEID_GENERATOR", sequenceName="PARK_SEQ_NEW")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARKING_ZONE_DETAIL_ZONEID_GENERATOR")
	@Column(name="ZONE_ID")
	private long zoneId;

	@Column(name="AREA_NAME")
	private String areaName;

	private double latitude;

	private double longitude;

	//bi-directional many-to-one association to ParkingLocation
	@OneToMany(mappedBy="parkingZoneDetail")
	private List<ParkingLocation> parkingLocations;

	public ParkingZoneDetail() {
	}

	public long getZoneId() {
		return this.zoneId;
	}

	public void setZoneId(long zoneId) {
		this.zoneId = zoneId;
	}

	public String getAreaName() {
		return this.areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}


	
	public void setLongitude(long longitude) {
		this.longitude = longitude;
	}

	public List<ParkingLocation> getParkingLocations() {
		return this.parkingLocations;
	}

	public void setParkingLocations(List<ParkingLocation> parkingLocations) {
		this.parkingLocations = parkingLocations;
	}

	public ParkingLocation addParkingLocation(ParkingLocation parkingLocation) {
		getParkingLocations().add(parkingLocation);
		parkingLocation.setParkingZoneDetail(this);

		return parkingLocation;
	}

	public ParkingLocation removeParkingLocation(ParkingLocation parkingLocation) {
		getParkingLocations().remove(parkingLocation);
		parkingLocation.setParkingZoneDetail(null);

		return parkingLocation;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	

}