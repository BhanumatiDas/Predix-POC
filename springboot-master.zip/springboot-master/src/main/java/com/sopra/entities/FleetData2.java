package com.sopra.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the FLEET_DATA_2 database table.
 * 
 */
@Entity
@Table(name="FLEET_DATA_2")
@NamedQuery(name="FleetData2.findAll", query="SELECT f FROM FleetData2 f")
public class FleetData2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="FLEET_DATA_2_FLEETID_GENERATOR", sequenceName="FLEET_SEQ1")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="FLEET_DATA_2_FLEETID_GENERATOR")
	@Column(name="FLEET_ID")
	private long fleetId;

	@Column(name="AIRSPEED")
	private Double airspeed;

	@Column(name="ARM_RETARDANT_TANK_DOOR")
	private BigDecimal armRetardantTankDoor;

	@Column(name="BEACON_START_STOP_RECORDING")
	private BigDecimal beaconStartStopRecording;

	@Column(name="ELAPSED_TIME")
	private Double elapsedTime;

	@Column(name="ELEVATOR_POSITION")
	private Double elevatorPosition;

	@Column(name="FLAP_POSITION")
	private Double flapPosition;

	@Column(name="GEAR_UP_AND_LOCKED")
	private BigDecimal gearUpAndLocked;

	@Column(name="LEFT_AILERON_POSITION")
	private Double leftAileronPosition;

	@Column(name="PEAK_VALLEY_INDICATOR")
	private String peakValleyIndicator;

	@Column(name="PRESSURE_ALTITUDE")
	private Double pressureAltitude;

	@Column(name="RECORD_TYPE")
	private String recordType;

	@Column(name="RETARDANT_DOOR_OPEN")
	private BigDecimal retardantDoorOpen;

	@Column(name="RETARDANT_TANK_FLOAT")
	private BigDecimal retardantTankFloat;

	@Column(name="ROLL_ACCELERATION")
	private Double rollAcceleration;

	@Column(name="STRAIN_GAUGE_1")
	private Double strainGauge1;

	@Column(name="STRAIN_GAUGE_2")
	private Double strainGauge2;

	@Column(name="STRAIN_GAUGE_3")
	private Double strainGauge3;

	@Column(name="STRAIN_GAUGE_4")
	private Double strainGauge4;

	@Column(name="STRAIN_GAUGE_5")
	private Double strainGauge5;

	@Column(name="STRAIN_GAUGE_6")
	private Double strainGauge6;

	@Column(name="STRAIN_GAUGE_7")
	private Double strainGauge7;

	@Column(name="STRAIN_GAUGE_8")
	private Double strainGauge8;
	
	@Column(name="STRAIN_GAUGE_9")
	private Double strainGauge9;
	
	

	/**
	 * @return the strainGauge9
	 */
	public Double getStrainGauge9() {
		return this.strainGauge9;
	}

	/**
	 * @param strainGauge9 the strainGauge9 to set
	 */
	public void setStrainGauge9(Double strainGauge9) {
		this.strainGauge9 = strainGauge9;
	}

	@Column(name="TIMESTAMP")
	private String timestamp;

	@Column(name="TRIGGER_CHANNEL")
	private BigDecimal triggerChannel;

	@Column(name="VERTICAL_ACCELERATION")
	private Double verticalAcceleration;

	//bi-directional many-to-one association to FlightMaster
	@ManyToOne
	@JoinColumn(name="FLIGHT_ID")
	private FlightMaster flightMaster;

	public FleetData2() {
	}

	public long getFleetId() {
		return this.fleetId;
	}

	public void setFleetId(long fleetId) {
		this.fleetId = fleetId;
	}

	public Double getAirspeed() {
		return this.airspeed;
	}

	public void setAirspeed(Double airspeed) {
		this.airspeed = airspeed;
	}

	public BigDecimal getArmRetardantTankDoor() {
		return this.armRetardantTankDoor;
	}

	public void setArmRetardantTankDoor(BigDecimal armRetardantTankDoor) {
		this.armRetardantTankDoor = armRetardantTankDoor;
	}

	public BigDecimal getBeaconStartStopRecording() {
		return this.beaconStartStopRecording;
	}

	public void setBeaconStartStopRecording(BigDecimal beaconStartStopRecording) {
		this.beaconStartStopRecording = beaconStartStopRecording;
	}

	public Double getElapsedTime() {
		return this.elapsedTime;
	}

	public void setElapsedTime(Double elapsedTime) {
		this.elapsedTime = elapsedTime;
	}

	public Double getElevatorPosition() {
		return this.elevatorPosition;
	}

	public void setElevatorPosition(Double elevatorPosition) {
		this.elevatorPosition = elevatorPosition;
	}

	public Double getFlapPosition() {
		return this.flapPosition;
	}

	public void setFlapPosition(Double flapPosition) {
		this.flapPosition = flapPosition;
	}

	public BigDecimal getGearUpAndLocked() {
		return this.gearUpAndLocked;
	}

	public void setGearUpAndLocked(BigDecimal gearUpAndLocked) {
		this.gearUpAndLocked = gearUpAndLocked;
	}

	public Double getLeftAileronPosition() {
		return this.leftAileronPosition;
	}

	public void setLeftAileronPosition(Double leftAileronPosition) {
		this.leftAileronPosition = leftAileronPosition;
	}

	public String getPeakValleyIndicator() {
		return this.peakValleyIndicator;
	}

	public void setPeakValleyIndicator(String peakValleyIndicator) {
		this.peakValleyIndicator = peakValleyIndicator;
	}

	public Double getPressureAltitude() {
		return this.pressureAltitude;
	}

	public void setPressureAltitude(Double pressureAltitude) {
		this.pressureAltitude = pressureAltitude;
	}

	public String getRecordType() {
		return this.recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public BigDecimal getRetardantDoorOpen() {
		return this.retardantDoorOpen;
	}

	public void setRetardantDoorOpen(BigDecimal retardantDoorOpen) {
		this.retardantDoorOpen = retardantDoorOpen;
	}

	public BigDecimal getRetardantTankFloat() {
		return this.retardantTankFloat;
	}

	public void setRetardantTankFloat(BigDecimal retardantTankFloat) {
		this.retardantTankFloat = retardantTankFloat;
	}

	public Double getRollAcceleration() {
		return this.rollAcceleration;
	}

	public void setRollAcceleration(Double rollAcceleration) {
		this.rollAcceleration = rollAcceleration;
	}

	public Double getStrainGauge1() {
		return this.strainGauge1;
	}

	public void setStrainGauge1(Double strainGauge1) {
		this.strainGauge1 = strainGauge1;
	}

	public Double getStrainGauge2() {
		return this.strainGauge2;
	}

	public void setStrainGauge2(Double strainGauge2) {
		this.strainGauge2 = strainGauge2;
	}

	public Double getStrainGauge3() {
		return this.strainGauge3;
	}

	public void setStrainGauge3(Double strainGauge3) {
		this.strainGauge3 = strainGauge3;
	}

	public Double getStrainGauge4() {
		return this.strainGauge4;
	}

	public void setStrainGauge4(Double strainGauge4) {
		this.strainGauge4 = strainGauge4;
	}

	public Double getStrainGauge5() {
		return this.strainGauge5;
	}

	public void setStrainGauge5(Double strainGauge5) {
		this.strainGauge5 = strainGauge5;
	}

	public Double getStrainGauge6() {
		return this.strainGauge6;
	}

	public void setStrainGauge6(Double strainGauge6) {
		this.strainGauge6 = strainGauge6;
	}

	public Double getStrainGauge7() {
		return this.strainGauge7;
	}

	public void setStrainGauge7(Double strainGauge7) {
		this.strainGauge7 = strainGauge7;
	}

	public Double getStrainGauge8() {
		return this.strainGauge8;
	}

	public void setStrainGauge8(Double strainGauge8) {
		this.strainGauge8 = strainGauge8;
	}

	public String getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public BigDecimal getTriggerChannel() {
		return this.triggerChannel;
	}

	public void setTriggerChannel(BigDecimal triggerChannel) {
		this.triggerChannel = triggerChannel;
	}

	public Double getVerticalAcceleration() {
		return this.verticalAcceleration;
	}

	public void setVerticalAcceleration(Double verticalAcceleration) {
		this.verticalAcceleration = verticalAcceleration;
	}

	public FlightMaster getFlightMaster() {
		return this.flightMaster;
	}

	public void setFlightMaster(FlightMaster flightMaster) {
		this.flightMaster = flightMaster;
	}
}