package com.sopra.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.jpa.enums.WorkScope;

@Entity
@Table(name = "shop_visit")
public class ShopVisit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8492990330375545323L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "id", unique = true, nullable = false, insertable = false, updatable = false)
	private Long id;
	
	@Column(name = "date_of_visit")
	private Date visitDate=new Date();
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="engine_id")
	private Engine engine;
	
	@Column(name = "no_of_cycles_since_new")
	private String numberOfCyclesSinceNew;
	
	@Column(name = "no_of_cycles_since_last_visit")
	private String numberOfCyclesSinceLastVisit;
	
	@Column(name = "amount")
	private BigDecimal amount;
	

	
	@Column(name = "workscope")
	private String workScope;
	

	public ShopVisit() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public String getNumberOfCyclesSinceNew() {
		return numberOfCyclesSinceNew;
	}

	public void setNumberOfCyclesSinceNew(String numberOfCyclesSinceNew) {
		this.numberOfCyclesSinceNew = numberOfCyclesSinceNew;
	}

	public String getNumberOfCyclesSinceLastVisit() {
		return numberOfCyclesSinceLastVisit;
	}

	public void setNumberOfCyclesSinceLastVisit(String numberOfCyclesSinceLastVisit) {
		this.numberOfCyclesSinceLastVisit = numberOfCyclesSinceLastVisit;
	}

	public String getWorkScope() {
		return workScope;
	}

	public void setWorkScope(String workScope) {
		this.workScope = workScope;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}


	
}
