package com.sopra.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="parts")
public class LLPDetails implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "id", unique = true, nullable = false, insertable = false, updatable = false)
	private Long id;
	
	
	@Column(name = "part_number")
	private String partNumber;
	
	@Column(name = "part_serial_number")
	private String partSerialNumber;
	
	@Column(name="part_name")
	private String partName;
	
	@Column(name="category")
	private String category;
	
	@Column(name="part_cycle_since_new")
	private Long partCycleSinceNew;
	
	@Column(name="part_cycle_remaining")
	private Long partCycleRemaining;
	
	@Column(name="part_llp_cycle")
	private Long partLifeCycle;
	
	@Column(name="catalog_price")
	private Long catalogPrice;
	
	@Column(name="iin")
	 private  String iin;
	
	@Column(name="qpe")
	 private  String qpe;
	
	@Column(name="life_remaining_percent")
	 private  String lifeRemainingPercentage;
	
	@Column(name="llp_ind")
	private  String llp_ind;
	
	@Column(name="minor_module")
    private  String minorModule;
	
	@ManyToOne
	@JoinColumn(name="engine_id")
	private Engine engine;
	
	public LLPDetails() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	public String getPartSerialNumber() {
		return partSerialNumber;
	}

	public void setPartSerialNumber(String partSerialNumber) {
		this.partSerialNumber = partSerialNumber;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Long getPartCycleSinceNew() {
		return partCycleSinceNew;
	}

	public void setPartCycleSinceNew(Long partCycleSinceNew) {
		this.partCycleSinceNew = partCycleSinceNew;
	}

	public Long getPartCycleRemaining() {
		return partCycleRemaining;
	}

	public void setPartCycleRemaining(Long partCycleRemaining) {
		this.partCycleRemaining = partCycleRemaining;
	}

	public Long getPartLifeCycle() {
		return partLifeCycle;
	}

	public void setPartLifeCycle(Long partLifeCycle) {
		this.partLifeCycle = partLifeCycle;
	}

	public Long getCatalogPrice() {
		return catalogPrice;
	}

	public void setCatalogPrice(Long catalogPrice) {
		this.catalogPrice = catalogPrice;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getIin() {
		return iin;
	}

	public void setIin(String iin) {
		this.iin = iin;
	}

	public String getQpe() {
		return qpe;
	}

	public void setQpe(String qpe) {
		this.qpe = qpe;
	}

	public String getLifeRemainingPercentage() {
		return lifeRemainingPercentage;
	}

	public void setLifeRemainingPercentage(String lifeRemainingPercentage) {
		this.lifeRemainingPercentage = lifeRemainingPercentage;
	}

	public String getLlp_ind() {
		return llp_ind;
	}

	public void setLlp_ind(String llp_ind) {
		this.llp_ind = llp_ind;
	}

	public String getMinorModule() {
		return minorModule;
	}

	public void setMinorModule(String minorModule) {
		this.minorModule = minorModule;
	}




}
