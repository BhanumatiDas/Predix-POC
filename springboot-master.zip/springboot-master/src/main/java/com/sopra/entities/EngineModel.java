package com.sopra.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.jpa.enums.ModelNames;

@Entity
@Table(name = "models_test")
public class EngineModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8492990330375545323L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "id", unique = true, nullable = false, insertable = false, updatable = false)
	private Long id;
	
	@Column(name = "model_name")
	private String modelName;
	
	@Column(name = "model_number")
	private String modelNumber;
	

	public EngineModel() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getModelNumber() {
		return modelNumber;
	}

	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

}
