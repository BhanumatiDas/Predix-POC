package com.sopra.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="engine_parts")
public class EngineLLPDetails implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "id", unique = true, nullable = false, insertable = false, updatable = false)
	private Long id;
	
	@OneToOne
	@JoinColumn(name="engine_id")
	private Engine engines;
	
	
	@JoinColumn(name="part_id")
	@OneToOne
	private LLPDetails llpDetails;

	
	
	

	public EngineLLPDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Engine getEngines() {
		return engines;
	}

	public void setEngines(Engine engines) {
		this.engines = engines;
	}

	public LLPDetails getLlpDetails() {
		return llpDetails;
	}

	public void setLlpDetails(LLPDetails llpDetails) {
		this.llpDetails = llpDetails;
	}



	
	
}
