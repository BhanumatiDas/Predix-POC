package com.sopra.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the M2M_WORKER database table.
 * 
 */
@Entity
@Table(name="M2M_WORKER")
@NamedQuery(name="M2mWorker.findAll", query="SELECT m FROM M2mWorker m")
public class M2mWorker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="M2M_WORKER_ID_GENERATOR", sequenceName="TT_SEQ_WORKER")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="M2M_WORKER_ID_GENERATOR")
	private long id;

	private String city;

	private String email;

	private String firstname;

	private String lastname;

	private String status;

	public M2mWorker() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}