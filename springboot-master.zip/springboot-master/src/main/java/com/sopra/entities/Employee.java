package com.sopra.entities;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;


/**
 * The persistent class for the TT_ADDRESS database table.
 * 
 */
@Entity
@Table(name="EMPLOYEE_TEST_JPA")
@NamedQuery(name="Employee.findAll", query="SELECT t FROM Employee t")
public class Employee implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TT_ADDRESS_ID_GENERATOR1", sequenceName="TT_SEQ_ADDR1")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TT_ADDRESS_ID_GENERATOR1")
	private long id;

	private String firstName;

	private String lastName;

	private Integer age;

	@Column(name = "DEPARTMENT")
	private String department;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	
	
}