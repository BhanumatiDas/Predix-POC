package com.sopra.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the AVIO_DATA_NEW database table.
 * 
 */
@Embeddable
public class AvioDataNewPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="\"Flight_id\"")
	private long flight_id;

	@Column(name="\"Time\"")
	private long time;

	public AvioDataNewPK() {
	}
	public long getFlight_id() {
		return this.flight_id;
	}
	public void setFlight_id(long flight_id) {
		this.flight_id = flight_id;
	}
	public long getTime() {
		return this.time;
	}
	public void setTime(long time) {
		this.time = time;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AvioDataNewPK)) {
			return false;
		}
		AvioDataNewPK castOther = (AvioDataNewPK)other;
		return 
			(this.flight_id == castOther.flight_id)
			&& (this.time == castOther.time);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.flight_id ^ (this.flight_id >>> 32)));
		hash = hash * prime + ((int) (this.time ^ (this.time >>> 32)));
		
		return hash;
	}
}