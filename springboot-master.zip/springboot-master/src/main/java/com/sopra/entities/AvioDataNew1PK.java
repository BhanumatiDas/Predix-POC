package com.sopra.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the AVIO_DATA_NEW1 database table.
 * 
 */
@Embeddable
public class AvioDataNew1PK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="FLIGHT_ID")
	private long flightId;

	@Column(name="TIME")
	private long time;

	public AvioDataNew1PK() {
	}
	public long getFlightId() {
		return this.flightId;
	}
	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}
	public long getTime() {
		return this.time;
	}
	public void setTime(long time) {
		this.time = time;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AvioDataNew1PK)) {
			return false;
		}
		AvioDataNew1PK castOther = (AvioDataNew1PK)other;
		return 
			(this.flightId == castOther.flightId)
			&& (this.time == castOther.time);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.flightId ^ (this.flightId >>> 32)));
		hash = hash * prime + ((int) (this.time ^ (this.time >>> 32)));
		
		return hash;
	}
}