package com.sopra.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class QuantityTypeVO {
	
	private String quantityType;
	
	private List<DemandDateVO> demandDateVos;

	public String getQuantityType() {
		return quantityType;
	}

	public void setQuantityType(String quantityType) {
		this.quantityType = quantityType;
	}
	
	public List<DemandDateVO> getDemandDateVos() {
		return demandDateVos;
	}

	public void setDemandDateVos(List<DemandDateVO> demandDateVos) {
		this.demandDateVos = demandDateVos;
	}

	
	

}
