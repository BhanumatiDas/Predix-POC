package com.sopra.vo;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;



public class Music {
	
	private String gener;
	
	private String lyrics;

	public String getGener() {
		return gener;
	}
	@XmlElement
	public void setGener(String gener) {
		this.gener = gener;
	}

	public String getLyrics() {
		return lyrics;
	}
	@XmlElement
	public void setLyrics(String lyrics) {
		this.lyrics = lyrics;
	}

	@Override
	public String toString() {
		return "Track [gener=" + gener + ", singer=" + lyrics + "]";
	}
	

}
