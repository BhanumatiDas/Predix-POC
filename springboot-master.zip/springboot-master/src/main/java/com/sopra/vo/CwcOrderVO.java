package com.sopra.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CwcOrderVO implements Serializable{
	private static final long serialVersionUID = 1L;

	private long cwcOrder;

	private BigDecimal balancedue;

	private String colshipmentprioritycode;

	private String custitem;

	private String custline;
	private String status;
	public String getNotificationFlag() {
		return notificationFlag;
	}

	public void setNotificationFlag(String notificationFlag) {
		this.notificationFlag = notificationFlag;
	}

	public Date getSchDate() {
		return schDate;
	}

	public void setSchDate(Date schDate) {
		this.schDate = schDate;
	}

	private String custpo;

	private BigDecimal deliverynumber;

	private BigDecimal extendedsellingprice;
	private BigDecimal geOrder;

	private String geitem;

	private BigDecimal geline;

	private String item;

	private String itemdescription;

	private String operatingUnit;
	private Date ordDt;

	private String ordType;
	private Date promisedate;

	private BigDecimal qtycancelled;

	private BigDecimal qtyordered;

	private BigDecimal qtyreserved;

	private String releasedflag;
	private String notificationFlag;
	private Date schDate;

	public long getCwcOrder() {
		return cwcOrder;
	}

	public void setCwcOrder(long cwcOrder) {
		this.cwcOrder = cwcOrder;
	}

	public BigDecimal getBalancedue() {
		return balancedue;
	}

	public void setBalancedue(BigDecimal balancedue) {
		this.balancedue = balancedue;
	}

	public String getColshipmentprioritycode() {
		return colshipmentprioritycode;
	}

	public void setColshipmentprioritycode(String colshipmentprioritycode) {
		this.colshipmentprioritycode = colshipmentprioritycode;
	}

	public String getCustitem() {
		return custitem;
	}

	public void setCustitem(String custitem) {
		this.custitem = custitem;
	}

	public String getCustline() {
		return custline;
	}

	public void setCustline(String custline) {
		this.custline = custline;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCustpo() {
		return custpo;
	}

	public void setCustpo(String custpo) {
		this.custpo = custpo;
	}

	public BigDecimal getDeliverynumber() {
		return deliverynumber;
	}

	public void setDeliverynumber(BigDecimal deliverynumber) {
		this.deliverynumber = deliverynumber;
	}

	public BigDecimal getExtendedsellingprice() {
		return extendedsellingprice;
	}

	public void setExtendedsellingprice(BigDecimal extendedsellingprice) {
		this.extendedsellingprice = extendedsellingprice;
	}

	public BigDecimal getGeOrder() {
		return geOrder;
	}

	public void setGeOrder(BigDecimal geOrder) {
		this.geOrder = geOrder;
	}

	public String getGeitem() {
		return geitem;
	}

	public void setGeitem(String geitem) {
		this.geitem = geitem;
	}

	public BigDecimal getGeline() {
		return geline;
	}

	public void setGeline(BigDecimal geline) {
		this.geline = geline;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItemdescription() {
		return itemdescription;
	}

	public void setItemdescription(String itemdescription) {
		this.itemdescription = itemdescription;
	}

	public String getOperatingUnit() {
		return operatingUnit;
	}

	public void setOperatingUnit(String operatingUnit) {
		this.operatingUnit = operatingUnit;
	}

	public Date getOrdDt() {
		return ordDt;
	}

	public void setOrdDt(Date ordDt) {
		this.ordDt = ordDt;
	}

	public String getOrdType() {
		return ordType;
	}

	public void setOrdType(String ordType) {
		this.ordType = ordType;
	}

	public Date getPromisedate() {
		return promisedate;
	}

	public void setPromisedate(Date promisedate) {
		this.promisedate = promisedate;
	}

	public BigDecimal getQtycancelled() {
		return qtycancelled;
	}

	public void setQtycancelled(BigDecimal qtycancelled) {
		this.qtycancelled = qtycancelled;
	}

	public BigDecimal getQtyordered() {
		return qtyordered;
	}

	public void setQtyordered(BigDecimal qtyordered) {
		this.qtyordered = qtyordered;
	}

	public BigDecimal getQtyreserved() {
		return qtyreserved;
	}

	public void setQtyreserved(BigDecimal qtyreserved) {
		this.qtyreserved = qtyreserved;
	}

	public String getReleasedflag() {
		return releasedflag;
	}

	public void setReleasedflag(String releasedflag) {
		this.releasedflag = releasedflag;
	}

	public Date getRequestdate() {
		return requestdate;
	}

	public void setRequestdate(Date requestdate) {
		this.requestdate = requestdate;
	}

	public String getShipto() {
		return shipto;
	}

	public void setShipto(String shipto) {
		this.shipto = shipto;
	}

	public String getShiptolocation() {
		return shiptolocation;
	}

	public void setShiptolocation(String shiptolocation) {
		this.shiptolocation = shiptolocation;
	}

	public String getUnitvol() {
		return unitvol;
	}

	public void setUnitvol(String unitvol) {
		this.unitvol = unitvol;
	}

	public String getUnitwt() {
		return unitwt;
	}

	public void setUnitwt(String unitwt) {
		this.unitwt = unitwt;
	}

	public String getUxpart() {
		return uxpart;
	}

	public void setUxpart(String uxpart) {
		this.uxpart = uxpart;
	}

	private Date requestdate;

	private String shipto;

	private String shiptolocation;

	private String unitvol;

	private String unitwt;

	private String uxpart;

	
}
