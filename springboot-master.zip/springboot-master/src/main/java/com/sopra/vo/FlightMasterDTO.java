package com.sopra.vo;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author predix -
 */
@XmlRootElement
public class FlightMasterDTO {
	
	private long flightId;

	private String startDate;

	private String startTime;

	/**
	 * @return the flightId
	 */
	public long getFlightId() {
		return this.flightId;
	}

	/**
	 * @param flightId the flightId to set
	 */
	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return this.startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return this.startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	
	

}
