package com.sopra.vo;

public class RegressionCalDTO {
	
	
	private String Coeff;
	private String StdError;
	private String pValue;
	private String tValue;
	private String param;
	/**
	 * @return the coeff
	 */
	public String getCoeff() {
		return this.Coeff;
	}
	/**
	 * @param coeff the coeff to set
	 */
	public void setCoeff(String coeff) {
		Coeff = coeff;
	}
	/**
	 * @return the stdError
	 */
	public String getStdError() {
		return this.StdError;
	}
	/**
	 * @param stdError the stdError to set
	 */
	public void setStdError(String stdError) {
		StdError = stdError;
	}
	/**
	 * @return the pValue
	 */
	public String getpValue() {
		return this.pValue;
	}
	/**
	 * @param pValue the pValue to set
	 */
	public void setpValue(String pValue) {
		this.pValue = pValue;
	}
	/**
	 * @return the tValue
	 */
	public String gettValue() {
		return this.tValue;
	}
	/**
	 * @param tValue the tValue to set
	 */
	public void settValue(String tValue) {
		this.tValue = tValue;
	}
	/**
	 * @return the param
	 */
	public String getParam() {
		return this.param;
	}
	/**
	 * @param param the param to set
	 */
	public void setParam(String param) {
		this.param = param;
	}
	
	
	

}
