package com.sopra.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sopra.entities.SupplierConnectTbl;

@Repository
public interface ISupplierSearchEntityRepository extends JpaRepository<SupplierConnectTbl, Long>,JpaSpecificationExecutor<SupplierConnectTbl>
{
	
	
}
