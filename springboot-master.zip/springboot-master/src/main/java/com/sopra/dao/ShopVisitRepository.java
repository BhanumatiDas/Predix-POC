package com.sopra.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.sopra.entities.ShopVisit;

@RepositoryRestResource
public interface ShopVisitRepository extends JpaRepository<ShopVisit, Long> {

}
