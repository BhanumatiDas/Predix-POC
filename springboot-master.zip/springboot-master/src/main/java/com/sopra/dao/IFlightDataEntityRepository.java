package com.sopra.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sopra.entities.AvioDataNew1;


@Repository
public interface IFlightDataEntityRepository extends JpaRepository<AvioDataNew1, Long>
{
	
	String GET_FLIGHT_DETAILS = "select a from AvioDataNew1 a where a.id.flightId = ?1 ";

	@Query(GET_FLIGHT_DETAILS)
	List<AvioDataNew1>   findByflightId(long flightId);
}