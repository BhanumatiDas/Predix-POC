package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.sopra.entities.FlightMaster;

public interface IFlightMasterRepository extends CrudRepository<FlightMaster, Long>{

	String GET_FLIGHT_DETAILS = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId";
	
	String GET_FLIGHT_TIMESTAMP_BY_DATE_TIME = "select a.flightId as flightId,a.startTime as  startTime from FlightMaster a where a.startDate =? and a.startTime=?";

	List<FlightMaster> findByStartDate(String startdate);

	@Query(GET_FLIGHT_DETAILS + " and a.timestamp between ?5 and ?6")
	List<Object[]> getFlightDetails(String flightDate, String flightTime,
			String recordType, String triggerChannel, String startTime,
			String endTime);

	@Query(GET_FLIGHT_DETAILS)
	FlightMaster getFlightDetailss();


	List<FlightMaster> findByStartTime(String startTime);
	
	@Query(GET_FLIGHT_TIMESTAMP_BY_DATE_TIME)
	List<Object[]> findByStartTimeAndDate(String startDate,String startTime);

}
