package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.sopra.entities.Employee;
import com.sopra.entities.IrevDgsBacklog;

public interface IEmployeeRepository extends JpaRepository<Employee, Long>,JpaSpecificationExecutor<Employee> {
	
	
	
}

