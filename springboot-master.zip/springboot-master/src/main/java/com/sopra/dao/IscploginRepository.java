package com.sopra.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sopra.entities.ScpUser;

public interface IscploginRepository extends JpaRepository<ScpUser, Long>{
	
	String CHECK_AVIALABLE_USER = "from ScpUser user where user.username=?1";

	@Query(CHECK_AVIALABLE_USER)
	ScpUser findUser(String username);

}
