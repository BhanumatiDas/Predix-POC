package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sopra.entities.ParkingLocation;
import com.sopra.entities.ParkingZoneDetail;

public interface IParkingLocationInfoRepo extends JpaRepository<ParkingLocation, Long>{

	/**
	 * 
	 */
	String GET_PARKING_ZONE_DETAILS_BY_LAT_LONG = "select a.zoneId as zoneId,a.areaName as areaName,a.latitude as latitude,a.longitude as longitude from ParkingZoneDetail a where a.latitude>=?1 and a.longitude>=?2";
	/**
	 * @param l 
	 * @param m 
	 * @param lat
	 * @param lon
	 * @return -
	 */
	@Query(GET_PARKING_ZONE_DETAILS_BY_LAT_LONG)
	List<Object[]> findParkingAreasByLongitudeAndLatitude(double latitude,
			double longitude);

	

}
