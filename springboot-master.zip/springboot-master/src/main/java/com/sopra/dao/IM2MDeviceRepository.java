package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sopra.entities.M2mDevice;

import java.lang.String;

@Repository
public interface IM2MDeviceRepository extends JpaRepository<M2mDevice, Long>
{
	
	String GET_TOOLFLEET_COUNT = "select count(*) from M2mDevice a ";
	String GET_DEVICE_DETAILS = "select a.model as model, a.name as name,a.connection as connection,a.status as status,b.accuracy as accuracy,b.x as x ,"
			+ "b.y as y,b.zone as zone,c.tighteingid as tighteingid,c.tighteningstatus as tighteningstatus,c.tighteningprogrambigint as tighteningprogrambigint,a.serialno as serialno"
			+ " from M2mDevice a,M2mDevicepostn b,M2mResult c"
			+ " where a.id=b.m2mDevice.id and a.id=c.m2mDevice.id"
			+ " and a.id=?1";
	
	@Override
	public List<M2mDevice> findAll();
	
	@Query(GET_TOOLFLEET_COUNT)
	public Integer getToolFleetCount();
	
	
	
	
	@Query(GET_DEVICE_DETAILS)
	
	List<Object []> getDeviceDetailsById(Long deviceId);
	@Override
	public M2mDevice findOne(Long id);
	
	
	
}
