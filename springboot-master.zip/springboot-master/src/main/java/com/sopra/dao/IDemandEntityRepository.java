package com.sopra.dao;


import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.sopra.entities.GetsDemand;

@Repository
public interface IDemandEntityRepository extends JpaRepository<GetsDemand, Long>,PagingAndSortingRepository<GetsDemand, Long>
{
	
	
	String GET_UNIQUE_ITEM_NUMBER = "select distinct(a.itemNumber),a.itemDescription  from GetsDemand a";
	
	String GET_UNIQUE_ITEM_NUMBER_SEARCH = "select distinct a.itemNumber, a.itemDescription from GetsDemand a where a.itemNumber like ?1%";

	//String GET_UNIQUE_SUPPLIER_NAMES = "select distinct(a.supplierName),a.dispositionId from GetsDemand a";
	
	String GET_UNIQUE_SUPPLIER_NAMES = "select distinct(a.supplierName) from GetsDemand a";

	String GET_UNIQUE_SUPPLIER_NAMES_SEARCH = "select a.supplierName,a.dispositionId from GetsDemand a where a.supplierName like ?1%";

	//String GET_UNIQUE_BUYER_NAMES = "select distinct(a.buyerName),a.dispositionId from GetsDemand a";
	
	String GET_UNIQUE_BUYER_NAMES = "select distinct(a.buyerName) from GetsDemand a";

	String GET_UNIQUE_BUYER_NAMES_SEARCH = "select a.buyerName,a.dispositionId from GetsDemand a where a.buyerName like ?1%";

	//String GET_UNIQUE_BUISNESS_UNIT_NAMES = "select distinct(a.buissnessUnit),a.dispositionId from GetsDemand a";

	String GET_UNIQUE_BUISNESS_NAMES_SEARCH = "select a.buissnessUnit,a.dispositionId from GetsDemand a where a.buissnessUnit like ?1%";

	//String GET_UNIQUE_ITEM_NUMBER_SEARCH = "select a.itemNumber, a.itemDescription from GetsDemand a where a.itemNumber like :itemNumber%";
	String GET_UNIQUE_BUISNESS_UNIT_NAMES = "select distinct(a.buissnessUnit) from GetsDemand a";
	@Override
	public List<GetsDemand> findAll();
	
	@Override
	public List<GetsDemand> findAll(Sort sort);
	
	
	@Query(GET_UNIQUE_ITEM_NUMBER)
	public List<Object[]> getUniqueItemNumber();
	
	/*@Query(GET_UNIQUE_ITEM_NUMBER_SEARCH)
	public List<Object[]> getItemNumberonItemSearch(@Param("itemNumber") String itemNumber);
	*/
	@Query(GET_UNIQUE_ITEM_NUMBER_SEARCH)
	public List<Object[]> getItemNumberonItemSearch(String itemNumber);
	
	
	@Query(GET_UNIQUE_SUPPLIER_NAMES)
	public List<String[]> getUniqueSupplierNames();
	
	@Query(GET_UNIQUE_SUPPLIER_NAMES_SEARCH)
	public List<Object[]> getSupplierNamesOnName(String supplerName);
	
	@Query(GET_UNIQUE_BUYER_NAMES)
	public List<String[]> getUniqueBuyerNames();
	
	
	List<GetsDemand> findByUserName(String username,Sort sort);
	
	@Query(GET_UNIQUE_BUYER_NAMES_SEARCH)
	public List<Object[]> getBuyerNamesOnName(String buyerName);
	
	@Query(GET_UNIQUE_BUISNESS_UNIT_NAMES)
	public List<String[]> getUniqueBuisnessUnitNames();
	
	@Query(GET_UNIQUE_BUISNESS_NAMES_SEARCH)
	public List<Object[]> getBuisnessNamesOnName(String buisnessUnitName);
	
	
}