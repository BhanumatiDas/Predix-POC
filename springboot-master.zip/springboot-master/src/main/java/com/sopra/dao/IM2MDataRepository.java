package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sopra.entities.M2mData;

@Repository
public interface IM2MDataRepository extends JpaRepository<M2mData, Integer>
{
	
	String GET_MACHINE_DATA_COUNT = "select count(*) from M2mData a ";
	
	String GET_MACHINE_JSON_DATA_BY_DEVICE_ID = "select b.data as data , b.processId as processId from M2mData b ,M2mDevice a "
			+ "where a.id=b.m2mDevice.id and a.id=?1";
	
	@Override
	public List<M2mData> findAll();
	
	@Query(GET_MACHINE_DATA_COUNT)
	public Integer getTighteningProcessingCount();
	
	@Query(GET_MACHINE_JSON_DATA_BY_DEVICE_ID)
	public List<Object[]> getMachineDataByDeviceId(Long deviceId);
	
}
