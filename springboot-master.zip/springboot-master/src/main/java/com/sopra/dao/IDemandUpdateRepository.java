package com.sopra.dao;


import org.springframework.data.domain.Sort;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.sopra.entities.GetsDemand;

@Repository
public interface IDemandUpdateRepository extends CrudRepository<GetsDemand, Long>
{
	
	@Override
	public GetsDemand findOne(Long id);
	
		
}