package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.sopra.entities.IrevDgsBacklog;

public interface IrevDSVBackLogRepository extends JpaRepository<IrevDgsBacklog, Long>,JpaSpecificationExecutor<IrevDgsBacklog> {
	
	String FIND_ALL_DETAILS = "select a.id as id,a.mod as mod,a.comments as comments,a.construction as construction,a.contractcustname as contractcustname,"
			+ "a.estrevfq as estrevfq,a.fset as fset,a.gon as gon, a.h as h, a.nevtt as nevtt,a.orderchart as orderchart,a.pmiscomment as pmiscomment,"
			+ "a.revrecterms as revrecterms,a.rosd as rosd,a.salesh as salesh,a.sosd as sosd "
			+ "from IrevDgsBacklog a where a.zone=?1 or a.region=?2 or a.revrecqtr=?3 or a.accountreps=?4 or a.pss=?5 or a.govtvaso=?6 or a.schedules=?7";

	@Override
	public List<IrevDgsBacklog> findAll();

	
	
	@Query(FIND_ALL_DETAILS)
	public List<Object[]> findIRevDSVBacklogVOonSearch(String zone,
			String region, String revrecqtr, String accountreps, String pss,
			String govtvaso, String schedules);
	
	
	//List<IrevDgsBacklog> findIRevDSVBacklogVOonSearch();

}

