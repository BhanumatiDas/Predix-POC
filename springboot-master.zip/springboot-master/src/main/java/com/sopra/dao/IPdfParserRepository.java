package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sopra.entities.GetsDemand;
import com.sopra.entities.PdfParser;

@Repository
public interface IPdfParserRepository extends JpaRepository<PdfParser, Long>,JpaSpecificationExecutor<PdfParser>
{
	
	
	@Override
	public List<PdfParser> findAll();	
	

}
