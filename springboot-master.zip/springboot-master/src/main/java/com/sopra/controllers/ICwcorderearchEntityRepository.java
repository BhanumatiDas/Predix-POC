package com.sopra.controllers;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sopra.entities.CwcSearchportionPoc;

public interface ICwcorderearchEntityRepository extends JpaRepository<CwcSearchportionPoc, Long>,JpaSpecificationExecutor<CwcSearchportionPoc>
{
	
	
}