package com.sopra.controllers;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.SimpleBookmark;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.jpa.enums.ModelNames;
import com.jpa.enums.WorkScope;
import com.predix.machine.poc.CommonBaseEventType;
import com.predix.machine.test.CommonBaseEvents;
import com.predixpoc.specification.DemandSearchSpecification;
import com.predixpoc.specification.DemandSearchSpecificationFilterExcel;
import com.predixpoc.specification.DemandSearchSupplierSpecification;
import com.predixpoc.specification.EmployeeSpecification;
import com.predixpoc.specification.FleetSearchSpecification;
import com.predixpoc.specification.PdfParseSearchSpecification;
import com.predixpoc.specification.SupplierSearchSpecification;
import com.predixpoc.util.ExcelUtil;
import com.predixpoc.util.RandomUtils;
import com.sopra.dao.EngineLLPDetailsRepository;
import com.sopra.dao.EngineModelRepository;
import com.sopra.dao.EngineRepository;
import com.sopra.dao.IDemandEntityRepository;
import com.sopra.dao.IDemandSearchEntityRepository;
import com.sopra.dao.IDemandUpdateRepository;
import com.sopra.dao.IEmployeeRepository;
import com.sopra.dao.IFlightDataEntityRepository;
import com.sopra.dao.IFlightFleet2Repository;
import com.sopra.dao.IFlightFleetRepository;
import com.sopra.dao.IFlightMasterRepository;
import com.sopra.dao.IM2MDataRepository;
import com.sopra.dao.IM2MDeviceRepository;
import com.sopra.dao.IM2MNotificationRepository;
import com.sopra.dao.IM2MResultRepository;
import com.sopra.dao.IParkingLocationInfoRepo;
import com.sopra.dao.IParkingZoneInfoRepo;
import com.sopra.dao.IPdfParserRepository;
import com.sopra.dao.ISupplierSearchEntityRepository;
import com.sopra.dao.ITtUserEntityRepository;
import com.sopra.dao.IrevDSVBackLogRepository;
import com.sopra.dao.IscploginRepository;
import com.sopra.dao.LLPDetailsRepository;
import com.sopra.dao.ShopVisitRepository;
import com.sopra.entities.AvioDataNew1;
import com.sopra.entities.CwcSearchportionPoc;
import com.sopra.entities.Employee;
import com.sopra.entities.Engine;
import com.sopra.entities.EngineModel;
import com.sopra.entities.FleetData2;
import com.sopra.entities.FlightMaster;
import com.sopra.entities.GetsDemand;
import com.sopra.entities.IrevDgsBacklog;
import com.sopra.entities.LLPDetails;
import com.sopra.entities.M2mDevice;
import com.sopra.entities.M2mMessage;
import com.sopra.entities.M2mNotification;
import com.sopra.entities.M2mResult;
import com.sopra.entities.ParkingLocation;
import com.sopra.entities.ParkingZoneDetail;
import com.sopra.entities.PdfParser;
import com.sopra.entities.ScpUser;
import com.sopra.entities.ScpUserRole;
import com.sopra.entities.ShopVisit;
import com.sopra.entities.SupplierConnectTbl;
import com.sopra.entities.TtUser;
import com.sopra.vo.BackLogCalcVO;
import com.sopra.vo.CumBackLogCalcVO;
import com.sopra.vo.CwcOrderVO;
import com.sopra.vo.DemandDateVO;
import com.sopra.vo.DemandsDetailsVO;
import com.sopra.vo.DemandsVO;
import com.sopra.vo.EmployeeVO;
import com.sopra.vo.FleetData2DTO;
import com.sopra.vo.FlightMasterDTO;
import com.sopra.vo.FlightParametersDTO;
import com.sopra.vo.MachineDeviceVO;
import com.sopra.vo.MachineMessageVO;
import com.sopra.vo.MachineNotificationVO;
import com.sopra.vo.MachineResultVO;
import com.sopra.vo.ParkingLocationDTO;
import com.sopra.vo.ParkingZoneDTO;
import com.sopra.vo.PdfParserDTO;
import com.sopra.vo.PlannedSupplierCalcVO;
import com.sopra.vo.QuantityTypeVO;
import com.sopra.vo.RegressionCalDTO;
import com.sopra.vo.RestResponse;
import com.sopra.vo.SupplierCommitCalcVO;
import com.sopra.vo.SupplierConnectSearchVO;
import com.sopra.vo.Track;

@Controller
@RequestMapping(value = "/app")
public class BookingController {

	@Autowired
	private IFlightMasterRepository flightMasterRepo;

	@Autowired
	private IFlightFleetRepository filghtFleetrepo;

	@Autowired
	private IFlightFleet2Repository filghtFleetrepo2;

	@Autowired
	private ResourceLoader resourceLoader;

	@Autowired
	private EngineModelRepository engineModelRepository;

	/*
	 * @Autowired private BookingRepository bookingRepository;
	 */

	@Autowired
	private EngineRepository engineRepository;

	@Autowired
	private LLPDetailsRepository llpDetailsRepository;

	@Autowired
	private EngineLLPDetailsRepository enginellpDetailsRepository;

	@Autowired
	private ShopVisitRepository shopVisitRepository;

	@Autowired
	private ITtUserEntityRepository ttUserService;

	@Autowired
	private IM2MResultRepository machineResultRepo;

	@Autowired
	private IM2MDeviceRepository machineDeviceRepo;

	@Autowired
	private IM2MDataRepository machineDataRepo;

	@Autowired
	private IM2MNotificationRepository machineNotificationRepo;

	@Autowired
	private IrevDSVBackLogRepository iRevRepo;

	@Autowired
	private IDemandEntityRepository demandRepo;

	@Autowired
	private IEmployeeRepository empRepo;

	@Autowired
	private IscploginRepository loginRepo;

	@Autowired
	private IDemandSearchEntityRepository demandSearchRepo;

	@Autowired
	private IDemandUpdateRepository demandUpdateRepository;

	@Autowired
	private IPdfParserRepository pdfParserRespo;

	@Autowired
	private ICwcorderearchEntityRepository cwcOrderSearchService;

	@Autowired
	private IParkingZoneInfoRepo parkingzoneInfo;

	@Autowired
	private IParkingLocationInfoRepo infoRepo;

	@Autowired
	private IFlightDataEntityRepository flightDataEntityRepo;

	@Autowired
	private ISupplierSearchEntityRepository supplierSearchEntityRepository;

	private static List<String> partNames = new ArrayList<String>();
	static {
		partNames.add("ASSY - COMBUSTION CHAMBER");
		partNames.add("FUEL SYSTEM COMPONENTS");
		partNames.add("ASSY - FAN ROTOR");
		partNames.add("ASSY - HPC ROTOR");
		partNames.add("SUPPORT - BEARING");
		partNames.add("BLADE - FAN");
		partNames.add("LINK - THRUST ENGINE MOUNT");
		partNames.add("SEAL - CDP");
		partNames.add("HOUSING - BEARING NO 1");
		partNames.add("ELECTRICAL - TRANSMITTER");
		partNames.add("PLATE - HPT COOLING");
		partNames.add("SPOOL");
		partNames.add("CASE - LPT");
		partNames.add("ALTERNATOR - GENERATOR STATOR/ROTOR");
		partNames.add("FRAME - EXHAUST");
		partNames.add("CASE - FAN BLADE CONTAINMENT");
		partNames.add("MISC - LOW COST PARTS");
		partNames.add("SENSOR - SENSOR N1 & N2 SPEED");
		partNames.add("ASSY - HPC STATOR");
		partNames.add("DISK - FAN STG 1");
		partNames.add("SHAFT - LPT");
		partNames.add("PUMP - LUBE");
		partNames.add("BLADE - HPT STG 1");
		partNames.add("Blisk - HPC");
		partNames.add("ACTUATOR");
		partNames.add("SEAL - HPC");
		partNames.add("SEAL - TURBINE STG 3 & 4");
		partNames.add("ASSY - ACCESSORY GEARBOX");
		partNames.add("CASE - HPC");
		partNames.add("SEAL - TURBINE STG 5 & 6");
		partNames.add("VALVE");
		partNames.add("ASSY - LPT MODULE");
		partNames.add("BEARING - MAIN #1");
		partNames.add("ASSY - PTO DRIVE");
		partNames.add("MOUNT - ENGINE");
		partNames.add("DISK - HPT STG 1");
		partNames.add("LINER - COMBUSTION");
		partNames.add("DISK - LPT STG 3");
		partNames.add("DISK - LPT STG 4");
		partNames.add("PLUG");
		partNames.add("SEAL - ROTATING AIR");
		partNames.add("SEAL - AIR");
		partNames.add("Blisk - HPC");
		partNames.add("SUPPORT - MOUNT BEAM");
		partNames.add("SEAL - AIR BALANCE PISTON ST");
		partNames.add("ASSY - DOME COMBUSTION");
		partNames.add("NOZZLE - HPT STG 1");
		partNames.add("FRAME - FAN HUB");
		partNames.add("DISK - LPT STG 5");
		partNames.add("COUPLING");
		partNames.add("DISK - HPT STG 2");

	}

	@RequestMapping(value = "/bookings.html", method = RequestMethod.GET)
	public String index(Model model) {
		return "bookings";
	}

	@RequestMapping(value = "/listenginemodel", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EngineModel> bookings(Model model) {
		return engineModelRepository.findAll();
	}

	@RequestMapping(value = "/populate/model", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String models(Model model) {
		System.out.println("In Model APP");

		for (int i = 0; i < 3; i++) {
			System.out.println("BookingController.models()" + i);
			EngineModel model2 = new EngineModel();
			model2.setModelName(ModelNames.values()[new Random()
					.nextInt(ModelNames.values().length)].toString());
			model2.setModelNumber("CRM-" + RandomStringUtils.randomNumeric(3));

			engineModelRepository.save(model2);
		}
		return "success";
	}

	@RequestMapping(value = "/populate/engines", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String series(Model model) {
		List<EngineModel> engineModels = engineModelRepository.findAll();

		for (EngineModel engineModel : engineModels) {
			for (int j = 0; j < 4; j++) {
				Engine engine = new Engine();
				engine.setEsn(RandomStringUtils.randomNumeric(6));
				engine.setEngineModel(engineModel);
				engineRepository.save(engine);
			}

		}

		return "success";
	}

	@RequestMapping(value = "/populate/engine/parts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String parts(Model model) {
		List<Engine> engines = engineRepository.findAll();
		for (Engine engine : engines) {
			for (int i = 0; i < partNames.size(); i++) {
				LLPDetails llpDetails = new LLPDetails();
				llpDetails.setPartSerialNumber(RandomStringUtils
						.randomAlphanumeric(6));
				llpDetails.setIin(RandomStringUtils.randomNumeric(3));
				llpDetails.setPartCycleSinceNew(Long
						.parseLong(RandomStringUtils.randomNumeric(6)));
				llpDetails.setPartNumber(RandomUtils.randomIntger(4)
						+ RandomStringUtils.randomAlphanumeric(3) + "" + i);
				llpDetails.setPartName(partNames.get(i));
				llpDetails.setCatalogPrice(RandomUtils.randomLongBetween(6000l,
						100000l));
				llpDetails.setEngine(engine);
				llpDetailsRepository.save(llpDetails);
			}
		}

		return "success";
	}

	@RequestMapping(value = "/populate/shopvisit", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String esn(Model model) {
		System.out.println("In Shop Visit of  ESNs");
		List<Engine> engines = engineRepository.findAll();
		for (Engine engine : engines) {
			int visitCount = RandomUtils.randomIntgerBetween(5, 10);
			String noOfCyclesSinceNew = RandomStringUtils.randomNumeric(5);
			for (int j = 0; j < visitCount; j++) {
				ShopVisit shopvisit = new ShopVisit();
				shopvisit.setEngine(engine);
				shopvisit.setNumberOfCyclesSinceNew(noOfCyclesSinceNew);
				Long engineCycleSinceNew = Long.parseLong(shopvisit
						.getNumberOfCyclesSinceNew());
				Long engineCycleSinceLastSV = Long.parseLong(RandomStringUtils
						.randomNumeric(5));
				Long numberOfCyclesSinceLastSV = 0l;
				if (engineCycleSinceLastSV > engineCycleSinceNew) {
					numberOfCyclesSinceLastSV = engineCycleSinceLastSV
							- engineCycleSinceNew;
				} else {
					numberOfCyclesSinceLastSV = engineCycleSinceNew
							- engineCycleSinceLastSV;
				}
				shopvisit
						.setNumberOfCyclesSinceLastVisit(numberOfCyclesSinceLastSV
								.toString());
				shopvisit.setVisitDate(RandomUtils
						.randomDateBetween(2013, 2014));
				shopvisit.setWorkScope(WorkScope.values()[new Random()
						.nextInt(WorkScope.values().length)].toString());
				shopvisit.setAmount(new BigDecimal(RandomStringUtils
						.randomNumeric(4)));
				shopVisitRepository.save(shopvisit);
			}
		}

		return "success";
	}

	// @CrossOrigin(origins = "http://localhost:9000")
	@RequestMapping(value = "/view/enginemodels", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EngineModel> engineModels(Model model, HttpServletResponse res) {
		HttpServletResponse response = (HttpServletResponse) res;
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods",
				"POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		return engineModelRepository.findAll();
	}

	@RequestMapping(value = "/view/engines", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Engine> engines(Model model) {
		return engineRepository.findAll();
	}

	@RequestMapping(value = "/view/engineparts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<LLPDetails> engineParts(Model model) {
		return llpDetailsRepository.findAll();
	}

	@RequestMapping(value = "/view/shopvisits", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<ShopVisit> shopVisits(Model model) {
		return shopVisitRepository.findAll();
	}

	@RequestMapping(value = "/view/TestPost", method = RequestMethod.POST, produces = MediaType.APPLICATION_XML_VALUE)
	@ResponseBody
	public String testPostService() {
		String output = "Testting the Post Service request";

		System.out.println("Testting the Post Service");
		return output;
	}

	@RequestMapping(value = "/view/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String login(@RequestBody TtUser user) {
		String status = "";
		System.out.println("BookingController.login()");

		try {

			TtUser checkUser = ttUserService.findUser(user.getUserName());

			if (null != checkUser) {

				if ((checkUser.getUserName().equalsIgnoreCase(user
						.getUserName()))
						&& (checkUser.getPassword().equalsIgnoreCase(user
								.getPassword()))) {
					return "Success";

				} else {
					return "Failure";
				}

			} else {
				return "Failure";

			}

		}

		catch (Exception ex) {
			System.out.println("HospitalAllarmService.login()");
			return status = status + "Registration unsuccessfully";

		}

		// return status;

	}

	@RequestMapping(value = "/view/register", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public RestResponse registerUser(@RequestBody TtUser user) {
		String status = "";
		System.out.println("BookingController.registerUser()");
		RestResponse response = new RestResponse();
		try {

			TtUser checkUser = ttUserService.findUser(user.getUserName());

			if (null != checkUser) {
				response.setStatus(201);
				response.setObject("Exists");
				return response;
			} else {
				//
				checkUser = new TtUser();
				// TtUser user = new TtUser();
				checkUser.setUserName(user.getUserName());
				checkUser.setFullName(user.getFullName());
				checkUser.setEmail(user.getEmail());
				checkUser.setPassword(user.getPassword());
				checkUser.setFlag("Y");
				ttUserService.save(checkUser);
				response.setStatus(200);
				return response;
			}

		}

		catch (Exception ex) {
			System.out.println("HospitalAllarmService.registerUser()");
			response.setStatus(201);
			return response;

		}
		// return status;

	}

	@RequestMapping("/view/getMachineResult")
	public @ResponseBody MachineResultVO getMachineResult() {

		MachineResultVO machineResultVO = null;
		try {
			List<M2mResult> m2mResults = machineResultRepo.findAll();
			Integer ok = 0;
			Integer nok = 0;
			// Integer quality = null;
			for (M2mResult result : m2mResults) {

				machineResultVO = new MachineResultVO();
				if (result.getTighteningstatus().equalsIgnoreCase("OK")) {
					ok++;
				} else {
					nok++;
				}

			}
			Double dok = ok.doubleValue();
			Integer resultSize = m2mResults.size();
			Double dresult = resultSize.doubleValue();
			Double quality = (double) ((((dok) / (dresult)) * 10) / 10);
			DecimalFormat df = new DecimalFormat("#.00");
			String qualitys = df.format(quality);
			machineResultVO.setTotalQuality(qualitys);

		} catch (Exception e) {

			System.out
					.println("HospitalAlarmService.getMachineResult() exception is :"
							+ e);
		}
		return machineResultVO;

	}

	@RequestMapping("/view/getToolFeetCount")
	public @ResponseBody Integer getToolFeetCount() {
		Integer toolCont = null;
		try {
			// machineDeviceRepo.findAll();

			toolCont = machineDeviceRepo.getToolFleetCount();

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getToolFeetCount()");
		}
		return toolCont;

	}

	@RequestMapping("/view/getTighteningProcessingCount")
	public @ResponseBody Integer getTighteningProcessingCount() {
		Integer toolCont = null;
		try {
			// machineDeviceRepo.findAll();

			toolCont = machineDataRepo.getTighteningProcessingCount();

		} catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getTighteningProcessingCount()");
		}
		return toolCont;

	}

	@RequestMapping("/view/getMachineNotification")
	public @ResponseBody List<MachineNotificationVO> getMachineNotification() {

		List<MachineNotificationVO> machineNotificationVOs = new ArrayList<MachineNotificationVO>();
		MachineNotificationVO machineNotificationVO = null;
		MachineDeviceVO machineDeviceVo = null;
		M2mDevice device = null;
		M2mMessage m2mMessage = null;
		MachineMessageVO machineMessageVO = null;

		try {
			List<M2mNotification> notification = machineNotificationRepo
					.findAll();

			for (M2mNotification notificationList : notification) {
				machineNotificationVO = new MachineNotificationVO();
				machineNotificationVO.setId(notificationList.getId());
				machineNotificationVO.setCreated(notificationList.getCreated());
				machineNotificationVO.setNotificationType(notificationList
						.getNotificationType());
				machineNotificationVO.setSeverity(notificationList
						.getSeverity());
				machineNotificationVO.setStatus(notificationList.getStatus());
				machineNotificationVO.setAcknowledged(notificationList
						.getAcknowledged());

				device = notificationList.getM2mDevice();
				machineDeviceVo = new MachineDeviceVO();
				machineDeviceVo.setConnection(device.getConnection());
				machineDeviceVo.setCreated(device.getCreated());
				machineDeviceVo.setId(device.getId());
				machineDeviceVo.setModel(device.getModel());
				machineDeviceVo.setName(device.getName());
				machineDeviceVo.setPort(device.getPort());
				machineDeviceVo.setSerialno(device.getSerialno());
				machineDeviceVo.setStatus(device.getStatus());
				machineDeviceVo.setType(device.getType());
				// machineDeviceVo.se

				m2mMessage = notificationList.getM2mMessage();
				machineMessageVO = new MachineMessageVO();

				machineMessageVO.setId(m2mMessage.getId());
				machineMessageVO.setContent(m2mMessage.getContent());
				machineMessageVO.setImg(m2mMessage.getImg());
				machineMessageVO.setTitle(m2mMessage.getTitle());

				machineNotificationVO.setMachineDeviceVo(machineDeviceVo);
				machineNotificationVO.setMessageVO(machineMessageVO);

				machineNotificationVOs.add(machineNotificationVO);

			}

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getMachineNotification()"
					+ e);
		}
		return machineNotificationVOs;

	}

	@RequestMapping("/view/getMachineDevice")
	public @ResponseBody List<MachineDeviceVO> getMachineDevice() {
		List<MachineDeviceVO> deviceVOs = new ArrayList<MachineDeviceVO>();
		MachineDeviceVO machineDeviceVO = null;

		try {
			List<M2mDevice> devices = machineDeviceRepo.findAll();

			for (M2mDevice device : devices) {
				machineDeviceVO = new MachineDeviceVO();

				machineDeviceVO.setConnection(device.getConnection());
				machineDeviceVO.setCreated(device.getCreated());
				machineDeviceVO.setId(device.getId());
				machineDeviceVO.setModel(device.getModel());
				machineDeviceVO.setName(device.getName());
				machineDeviceVO.setPort(device.getPort());
				machineDeviceVO.setSerialno(device.getSerialno());
				machineDeviceVO.setStatus(device.getStatus());
				machineDeviceVO.setType(device.getType());
				deviceVOs.add(machineDeviceVO);

			}

		} catch (Exception e) {

		}
		return deviceVOs;

	}

	@RequestMapping("/getMachineDeviceDetails/{deviceId}")
	public @ResponseBody List<Map<String, Object>> getMachineDevice(
			@PathVariable("deviceId") Long deviceId) {
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		try {

			List<Object[]> retList = machineDeviceRepo
					.getDeviceDetailsById(deviceId);

			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("model", (retList.get(i))[0]);
				objMap.put("deviceName", (retList.get(i))[1]);
				objMap.put("connection", (retList.get(i))[2]);
				objMap.put("status", (retList.get(i))[3]);
				objMap.put("accuracy", (retList.get(i))[4]);

				objMap.put("x", (retList.get(i))[5]);
				objMap.put("y", (retList.get(i))[6]);
				objMap.put("zone", (retList.get(i))[7]);
				objMap.put("tighteingid", (retList.get(i))[8]);

				objMap.put("tighteningstatus", (retList.get(i))[9]);
				objMap.put("tighteningprogram", (retList.get(i))[10]);
				objMap.put("serialno", (retList.get(i))[11]);

				list.add(objMap);

			}

			System.out.println("BookingController.getMachineDevice()");

		} catch (Exception e) {
			System.out.println("BookingController.getMachineDevice()" + e);
		}

		return list;

	}

	/*
	 * @RequestMapping("/view/getMachineDeviceDetails/{deviceId}") public
	 * @ResponseBody List<Map<String,Object>>
	 * getMachineDevice(@PathVariable("deviceId") Long deviceId) {
	 * Map<String,Object> objMap = null; List<Map<String,Object>> list = new
	 * ArrayList<Map<String,Object>>(); try{
	 * 
	 * List<Object []> retList =
	 * machineDeviceRepo.getDeviceDetailsById(deviceId);
	 * 
	 * System.out.println("BookingController.getMachineDevice()");
	 * 
	 * } catch(Exception e) {
	 * System.out.println("BookingController.getMachineDevice()" + e); }
	 * 
	 * return null;
	 * 
	 * 
	 * }
	 */

	@RequestMapping(value = "/view/getAllDSVBacklogDetailsOnSearch", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getAllDSVBacklogDetailsOnSearchA(
			@PathVariable("zone") String zone,
			@PathVariable("region") String region,
			@PathVariable("revrecqtr") String revrecqtr,
			@PathVariable("accountreps") String accountreps,
			@PathVariable("pss") String pss,
			@PathVariable("govtvaso") String govtvaso,
			@PathVariable("schedules") String schedules) {
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		try {
			List<Object[]> retList = iRevRepo.findIRevDSVBacklogVOonSearch(
					zone, region, revrecqtr, accountreps, pss, govtvaso,
					schedules);
			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("id", (retList.get(i))[0]);
				objMap.put("mod", (retList.get(i))[1]);
				objMap.put("comments", (retList.get(i))[2]);
				objMap.put("construction", (retList.get(i))[3]);
				objMap.put("contractcustname", (retList.get(i))[4]);
				objMap.put("estrevfq", (retList.get(i))[5]);
				objMap.put("fset", (retList.get(i))[6]);
				objMap.put("gon", (retList.get(i))[7]);
				objMap.put("h", (retList.get(i))[8]);
				objMap.put("nevtt", (retList.get(i))[9]);
				objMap.put("orderchart", (retList.get(i))[10]);
				objMap.put("pmiscomment", (retList.get(i))[11]);
				objMap.put("revrecterms", (retList.get(i))[12]);
				objMap.put("rosd", (retList.get(i))[13]);
				objMap.put("salesh", (retList.get(i))[14]);
				objMap.put("sosd", (retList.get(i))[15]);
				list.add(objMap);

			}

		} catch (Exception e) {
			System.out
					.println("HospitalAlarmService.iRevDSVBacklogVOonSearch()"
							+ e);
		}
		return list;

	}

	@RequestMapping(value = "/view/getAllDSVBacklogDetailsOnSearchPost", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getAllDSVBacklogDetailsOnSearchPost(
			@RequestBody @Valid final IrevDgsBacklog irevDgsBacklog) {
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		try {
			List<Object[]> retList = iRevRepo
					.findIRevDSVBacklogVOonSearch(irevDgsBacklog.getZone(),
							irevDgsBacklog.getRegion(),
							irevDgsBacklog.getRevrecqtr(),
							irevDgsBacklog.getAccountreps(),
							irevDgsBacklog.getPss(),
							irevDgsBacklog.getGovtvaso(),
							irevDgsBacklog.getSchedules());
			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("id", (retList.get(i))[0]);
				objMap.put("mod", (retList.get(i))[1]);
				objMap.put("comments", (retList.get(i))[2]);
				objMap.put("construction", (retList.get(i))[3]);
				objMap.put("contractcustname", (retList.get(i))[4]);
				objMap.put("estrevfq", (retList.get(i))[5]);
				objMap.put("fset", (retList.get(i))[6]);
				objMap.put("gon", (retList.get(i))[7]);
				objMap.put("h", (retList.get(i))[8]);
				objMap.put("nevtt", (retList.get(i))[9]);
				objMap.put("orderchart", (retList.get(i))[10]);
				objMap.put("pmiscomment", (retList.get(i))[11]);
				objMap.put("revrecterms", (retList.get(i))[12]);
				objMap.put("rosd", (retList.get(i))[13]);
				objMap.put("salesh", (retList.get(i))[14]);
				objMap.put("sosd", (retList.get(i))[15]);
				list.add(objMap);

			}

		} catch (Exception e) {
			System.out
					.println("HospitalAlarmService.iRevDSVBacklogVOonSearch()"
							+ e);
		}
		return list;

	}

	@RequestMapping("/view/getBuisnessUnitNames")
	public @ResponseBody List<Map<String, Object>> getBuisnessUnitNames() {
		// List<ItemNumberVO> itemNumberVOs = new ArrayList<ItemNumberVO>();
		// ItemNumberVO itemNumberVO = null;
		// List<GetsDemand> itemList = null;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		System.out.println("HospitalAlarmService.getBuisnessUnitNames()");
		try {
			List<String[]> retList = demandRepo.getUniqueBuisnessUnitNames();
			System.out.println("retList.getBuisnessUnitNames()"
					+ retList.size());
			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("buissnessUnit", (retList.get(i)));
				// objMap.put("itemDescription", (retList.get(i))[1]);
				list.add(objMap);
			}

			/*
			 * itemList = demandRepo.getUniqueItemNumber(); for(GetsDemand
			 * itemLst : itemList){ itemNumberVO = new ItemNumberVO();
			 * itemNumberVO.setItemNumber(itemLst.getItemNumber());
			 * itemNumberVO.setItemDescription(itemLst.getItemDescription());
			 * itemNumberVOs.add(itemNumberVO); }
			 */

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getSupplierNames()" + e);
		}
		return list;

	}

	@RequestMapping(value = "/view/getDemandItemNumberOnSearch", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getDemandItem(
			@RequestBody @Valid final GetsDemand demand) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			List<Object[]> retList = demandRepo
					.getItemNumberonItemSearch(demand.getItemNumber());

			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("itemNumber", (retList.get(i)[0]));
				objMap.put("itemDescription", (retList.get(i)[1]));
				list.add(objMap);
			}

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getEngineDetails()" + e);
		}
		return list;

	}

	/*
	 * @RequestMapping(value = "/view/getEmployee", method = RequestMethod.GET,
	 * produces="application/json") public @ResponseBody List<EmployeeVO>
	 * getEmployee(@PathVariable("firstName") String
	 * firstName,@PathVariable("lastName") String lastName,@PathVariable("age")
	 * Integer age,@PathVariable("Department") String Department){
	 * List<EmployeeVO> employeeVOs = new ArrayList<EmployeeVO>(); EmployeeVO
	 * employeeVO = null;
	 * 
	 * try{ EmployeeSpecification employeeSpecification = new
	 * EmployeeSpecification(filter)
	 * 
	 * }catch(Exception e){
	 * 
	 * } return null;
	 * 
	 * }
	 */

	@RequestMapping(value = "/view/getEmployee", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<EmployeeVO> getEmployee(
			@RequestBody @Valid final Employee emp) {
		List<EmployeeVO> employeeVOs = new ArrayList<EmployeeVO>();
		EmployeeVO employeeVO = null;

		try {
			EmployeeSpecification employeeSpecification = new EmployeeSpecification(
					emp);
			List<Employee> emplIst = empRepo.findAll(employeeSpecification);
			for (Employee list : emplIst) {
				employeeVO = new EmployeeVO();
				employeeVO.setAge(list.getAge());
				employeeVO.setDepartment(list.getDepartment());
				employeeVO.setFirstName(list.getFirstName());
				employeeVO.setLastName((list.getLastName()));
				employeeVO.setId(list.getId());
				employeeVOs.add(employeeVO);
			}

		} catch (Exception e) {
			System.out.println("BookingController.getEmployee()" + e);
		}
		return employeeVOs;

	}

	@RequestMapping(value = "/view/Scplogin", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public RestResponse loginScp(@RequestBody @Valid final ScpUser user) {
		RestResponse response = new RestResponse();
		try {

			ScpUser checkUser = loginRepo.findUser(user.getUsername());
			System.out.println("checkUser" + checkUser);

			if (null != checkUser) {

				if ((checkUser.getUsername().equalsIgnoreCase(user
						.getUsername()))
						&& (checkUser.getPassword().equalsIgnoreCase(user
								.getPassword()))) {
					ScpUserRole role = checkUser.getScpUserRole();
					response.setStatus(200);
					response.setMessage("Success");
					response.setRoleId(role.getRoleId());
					response.setRoleName(role.getRoleName());
					System.out.println("checkUser" + response);

				} else {
					response.setMessage("Failure");
					response.setStatus(201);

				}
				System.out.println("Response: " + response);
			} else {
				response.setMessage("NotExist");
				response.setStatus(201);

			}

		}

		catch (Exception ex) {
			System.out.println("HospitalAllarmService.login()");
			response.setStatus(201);
			return response;

		}
		// return status;
		return response;

	}

	@RequestMapping("/view/getDemandDetailsWithOutFilter")
	public @ResponseBody List<DemandsVO> getDemandDetailsWithOutFilter() {
		List<DemandsVO> demandVos = new ArrayList<DemandsVO>();
		DemandsVO demandVo = null;
		QuantityTypeVO quantityTypeVO = null;
		DemandDateVO dateVO = null;
		List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		List<DemandDateVO> demandDateVoList = new ArrayList<DemandDateVO>();
		try {
			List<GetsDemand> demandList = demandRepo.findAll();

			for (GetsDemand demands : demandList) {
				demandVo = new DemandsVO();
				quantityTypeVO = new QuantityTypeVO();
				dateVO = new DemandDateVO();

				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands
						.getInventoryOrganization());
				// setting quantity type
				quantityTypeVO.setQuantityType(demands.getProductCode());

				// setting the date type

				dateVO.setApr04Apr10(demands.getApr04Apr10());
				dateVO.setApr11Apr17(demands.getApr11Apr17());
				dateVO.setApr18Apr24(demands.getApr18Apr24());
				dateVO.setApr25May01(demands.getApr25May01());
				dateVO.setAug01Aug28(demands.getAug01Aug28());
				dateVO.setAug29Oct02(demands.getAug29Oct02());
				dateVO.setFeb29Mar06(demands.getFeb29Mar06());
				dateVO.setJan02Jan29(demands.getJan02Jan29());
				dateVO.setJan30Feb26(demands.getJan30Feb26());
				dateVO.setJul04Jul31(demands.getJul04Jul31());
				dateVO.setMar07Mar13(demands.getMar07Mar13());
				dateVO.setMar14Mar20(demands.getMar14Mar20());
				dateVO.setMar21Mar27(demands.getMar21Mar27());
				dateVO.setMar28Apr03(demands.getMar28Apr03());
				dateVO.setMay02May08(demands.getMay02May08());
				dateVO.setMay09May15(demands.getMay09May15());
				dateVO.setMay16May22(demands.getMay16May22());
				dateVO.setMay23May29(demands.getMay23May29());
				dateVO.setMay30Jul03(demands.getMay30Jul03());
				dateVO.setNov28Jan01(demands.getNov28Jan01());
				dateVO.setOct03Oct30(demands.getOct03Oct30());
				dateVO.setOct31Nov27(demands.getOct31Nov27());

				demandDateVoList.add(dateVO);
				quantityTypeVO.setDemandDateVos(demandDateVoList);
				quantityVoList.add(quantityTypeVO);
				demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);

			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandDetailsWithOutFilter()"
							+ e);
		}
		return demandVos;

	}

	@RequestMapping("/view/getDemandAllDetailsWithOutFilterNew")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithOutFilterNew() {
		List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		DemandsDetailsVO demandVo = null;
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new
		// ArrayList<QuantityTypeVO>();
		// List<DemandDateVO> demandDateVoList = new ArrayList<DemandDateVO>();
		try {
			List<GetsDemand> demandList = demandRepo.findAll();

			for (GetsDemand demands : demandList) {
				demandVo = new DemandsDetailsVO();
				// quantityTypeVO = new QuantityTypeVO();
				// dateVO = new DemandDateVO();

				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands
						.getInventoryOrganization());
				demandVo.setQuantityType(demands.getProductCode());
				// setting quantity type
				// quantityTypeVO.setQuantityType(demands.getProductCode());

				// setting the date type

				demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03(demands.getMar28Apr03());
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());

				// demandDateVoList.add(dateVO);
				// quantityTypeVO.setDemandDateVos(demandDateVoList);
				// quantityVoList.add(quantityTypeVO);
				// demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);

			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandDetailsWithOutFilter()"
							+ e);
		}
		return demandVos;

	}

	// /////////////////////////////**********
	// Filter***********************//////////////////////

	@RequestMapping(value = "/view/getDemandAllDetailsWithFilter", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<DemandsVO> getDemandAllDetailsWithFilter(
			@RequestBody @Valid final GetsDemand demand) {
		List<DemandsVO> demandVos = new ArrayList<DemandsVO>();
		DemandsVO demandVo = null;
		QuantityTypeVO quantityTypeVO = null;
		DemandDateVO dateVO = null;
		List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		List<DemandDateVO> demandDateVoList = null;
		try {

			DemandSearchSpecification demandSearchSpecification = new DemandSearchSpecification(
					demand);
			List<GetsDemand> demandList = demandSearchRepo
					.findAll(demandSearchSpecification);
			for (GetsDemand demands : demandList) {
				demandVo = new DemandsVO();
				quantityTypeVO = new QuantityTypeVO();
				dateVO = new DemandDateVO();

				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands
						.getInventoryOrganization());
				// setting quantity type
				quantityTypeVO.setQuantityType(demands.getProductCode());
				System.out.println("demands.getDemandId()"
						+ demands.getDemandId());
				demandVo.setDemandId(demands.getDemandId());

				// setting the date type

				dateVO.setApr04Apr10(demands.getApr04Apr10());
				dateVO.setApr11Apr17(demands.getApr11Apr17());
				dateVO.setApr18Apr24(demands.getApr18Apr24());
				dateVO.setApr25May01(demands.getApr25May01());
				dateVO.setAug01Aug28(demands.getAug01Aug28());
				dateVO.setAug29Oct02(demands.getAug29Oct02());
				dateVO.setFeb29Mar06(demands.getFeb29Mar06());
				dateVO.setJan02Jan29(demands.getJan02Jan29());
				dateVO.setJan30Feb26(demands.getJan30Feb26());
				dateVO.setJul04Jul31(demands.getJul04Jul31());
				dateVO.setMar07Mar13(demands.getMar07Mar13());
				dateVO.setMar14Mar20(demands.getMar14Mar20());
				dateVO.setMar21Mar27(demands.getMar21Mar27());
				dateVO.setMar28Apr03(demands.getMar28Apr03());
				dateVO.setMay02May08(demands.getMay02May08());
				dateVO.setMay09May15(demands.getMay09May15());
				dateVO.setMay16May22(demands.getMay16May22());
				dateVO.setMay23May29(demands.getMay23May29());
				dateVO.setMay30Jul03(demands.getMay30Jul03());
				dateVO.setNov28Jan01(demands.getNov28Jan01());
				dateVO.setOct03Oct30(demands.getOct03Oct30());
				dateVO.setOct31Nov27(demands.getOct31Nov27());
				demandDateVoList = new ArrayList<DemandDateVO>();
				demandDateVoList.add(dateVO);
				quantityTypeVO.setDemandDateVos(demandDateVoList);
				quantityVoList.add(quantityTypeVO);
				demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);

			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandDetailsWithOutFilter()"
							+ e);
		}
		return demandVos;

	}

	@RequestMapping("/view/getDemandDetailsWithOutFilters")
	public @ResponseBody List<DemandsVO> getDemandDetailsWithOutFilters() {
		List<DemandsVO> demandVos = new ArrayList<DemandsVO>();
		DemandsVO demandVo = null;
		QuantityTypeVO quantityTypeVO = null;
		DemandDateVO dateVO = null;
		List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		List<DemandDateVO> demandDateVoList = null;
		try {
			List<GetsDemand> demandList = demandRepo.findAll();

			for (GetsDemand demands : demandList) {
				demandVo = new DemandsVO();
				quantityTypeVO = new QuantityTypeVO();
				dateVO = new DemandDateVO();

				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands
						.getInventoryOrganization());
				demandVo.setDemandId(demands.getDemandId());
				// setting quantity type
				quantityTypeVO.setQuantityType(demands.getProductCode());

				// setting the date type

				dateVO.setApr04Apr10(demands.getApr04Apr10());
				dateVO.setApr11Apr17(demands.getApr11Apr17());
				dateVO.setApr18Apr24(demands.getApr18Apr24());
				dateVO.setApr25May01(demands.getApr25May01());
				dateVO.setAug01Aug28(demands.getAug01Aug28());
				dateVO.setAug29Oct02(demands.getAug29Oct02());
				dateVO.setFeb29Mar06(demands.getFeb29Mar06());
				dateVO.setJan02Jan29(demands.getJan02Jan29());
				dateVO.setJan30Feb26(demands.getJan30Feb26());
				dateVO.setJul04Jul31(demands.getJul04Jul31());
				dateVO.setMar07Mar13(demands.getMar07Mar13());
				dateVO.setMar14Mar20(demands.getMar14Mar20());
				dateVO.setMar21Mar27(demands.getMar21Mar27());
				dateVO.setMar28Apr03((demands.getMar28Apr03()));
				dateVO.setMay02May08(demands.getMay02May08());
				dateVO.setMay09May15(demands.getMay09May15());
				dateVO.setMay16May22(demands.getMay16May22());
				dateVO.setMay23May29(demands.getMay23May29());
				dateVO.setMay30Jul03(demands.getMay30Jul03());
				dateVO.setNov28Jan01(demands.getNov28Jan01());
				dateVO.setOct03Oct30(demands.getOct03Oct30());
				dateVO.setOct31Nov27(demands.getOct31Nov27());
				demandDateVoList = new ArrayList<DemandDateVO>();
				demandDateVoList.add(dateVO);
				quantityTypeVO.setDemandDateVos(demandDateVoList);
				quantityVoList.add(quantityTypeVO);
				demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);

			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandDetailsWithOutFilter()"
							+ e);
		}
		return demandVos;

	}

	/*
	 * @SuppressWarnings("unchecked")
	 * 
	 * @RequestMapping("/view/getDemandDetailsWithOutFiltersExcel") public
	 * @ResponseBody void downloadDemanDetailsinExcelWithoutFilter() {
	 * List<DemandsVO> demandVos = new ArrayList<DemandsVO>(); DemandsVO
	 * demandVo = null; QuantityTypeVO quantityTypeVO = null; DemandDateVO
	 * dateVO = null; List<QuantityTypeVO> quantityVoList = new
	 * ArrayList<QuantityTypeVO>(); List<DemandDateVO> demandDateVoList = null;
	 * try { List<GetsDemand> demandList = demandRepo.findAll();
	 * 
	 * for(GetsDemand demands : demandList){ demandVo = new DemandsVO();
	 * quantityTypeVO = new QuantityTypeVO(); dateVO = new DemandDateVO();
	 * 
	 * demandVo.setDispositionId(demands.getDispositionId());
	 * demandVo.setItemNumber(demands.getItemNumber());
	 * demandVo.setItemDescription(demands.getItemDescription());
	 * demandVo.setSupplierName(demands.getSupplierName());
	 * demandVo.setInventoryOrganization(demands.getInventoryOrganization());
	 * demandVo.setDemandId(demands.getDemandId()); //setting quantity type
	 * quantityTypeVO.setQuantityType(demands.getProductCode());
	 * 
	 * //setting the date type
	 * 
	 * dateVO.setApr04Apr10(demands.getApr04Apr10());
	 * dateVO.setApr11Apr17(demands.getApr11Apr17());
	 * dateVO.setApr18Apr24(demands.getApr18Apr24());
	 * dateVO.setApr25May01(demands.getApr25May01());
	 * dateVO.setAug01Aug28(demands.getAug01Aug28());
	 * dateVO.setAug29Oct02(demands.getAug29Oct02());
	 * dateVO.setFeb29Mar06(demands.getFeb29Mar06());
	 * dateVO.setJan02Jan29(demands.getJan02Jan29());
	 * dateVO.setJan30Feb26(demands.getJan30Feb26());
	 * dateVO.setJul04Jul31(demands.getJul04Jul31());
	 * dateVO.setMar07Mar13(demands.getMar07Mar13());
	 * dateVO.setMar14Mar20(demands.getMar14Mar20());
	 * dateVO.setMar21Mar27(demands.getMar21Mar27());
	 * dateVO.setMar28Mar03(demands.getMar28Mar03());
	 * dateVO.setMay02May08(demands.getMay02May08());
	 * dateVO.setMay09May15(demands.getMay09May15());
	 * dateVO.setMay16May22(demands.getMay16May22());
	 * dateVO.setMay23May29(demands.getMay23May29());
	 * dateVO.setMay30Jul03(demands.getMay30Jul03());
	 * dateVO.setNov28Jan01(demands.getNov28Jan01());
	 * dateVO.setOct03Oct30(demands.getOct03Oct30());
	 * dateVO.setOct31Nov27(demands.getOct31Nov27()); demandDateVoList = new
	 * ArrayList<DemandDateVO>(); demandDateVoList.add(dateVO);
	 * quantityTypeVO.setDemandDateVos(demandDateVoList);
	 * quantityVoList.add(quantityTypeVO);
	 * demandVo.setQuantityVos(quantityVoList); demandVos.add(demandVo);
	 * 
	 * } ExcelUtil.writeDataToExcel(demandVos);
	 * 
	 * 
	 * }
	 * 
	 * 
	 * catch (Exception e) { System.out.println(
	 * "HospitalAlarmService.downloadDemanDetailsinExcelWithoutFilter()" + e); }
	 * 
	 * 
	 * }
	 */

	@RequestMapping("/view/getDemandAllDetailsWithOutFilter")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithOutFilter() {
		List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		DemandsDetailsVO demandVo = null;
		BackLogCalcVO backLogCalcVO = new BackLogCalcVO();
		CumBackLogCalcVO cumBackLogCalcVO = null;
		SupplierCommitCalcVO supplierCommitCalcVO = new SupplierCommitCalcVO(); // equv
																				// cum
																				// backlog
																				// vo
		PlannedSupplierCalcVO plannedSupplierCalcVO = new PlannedSupplierCalcVO();// equv
																					// baclogvo
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new
		// ArrayList<QuantityTypeVO>();
		// List<DemandDateVO> demandDateVoList = new ArrayList<DemandDateVO>();

		BigDecimal backLogPastDue = null;
		try {
			List<GetsDemand> demandList = demandRepo.findAll(new Sort(
					Sort.Direction.ASC, "dispositionId"));

			for (GetsDemand demands : demandList) {
				demandVo = new DemandsDetailsVO();
				// backLogCalcVO = new BackLogCalcVO();
				cumBackLogCalcVO = new CumBackLogCalcVO();
				// supplierCommitCalcVO = new SupplierCommitCalcVO();
				// plannedSupplierCalcVO = new PlannedSupplierCalcVO();
				// quantityTypeVO = new QuantityTypeVO();
				// dateVO = new DemandDateVO();

				if (demands.getSentFlag().equalsIgnoreCase("false")) {
					demandVo.setItemNumber("");
					demandVo.setItemDescription("");
					demandVo.setSupplierName("");
					demandVo.setInventoryOrganization("");
				} else {

					demandVo.setItemNumber(demands.getItemNumber());
					demandVo.setItemDescription(demands.getItemDescription());
					demandVo.setSupplierName(demands.getSupplierName());
					demandVo.setInventoryOrganization(demands
							.getInventoryOrganization());
				}

				demandVo.setDispositionId(demands.getDispositionId());
				// demandVo.setItemNumber(demands.getItemNumber());
				// demandVo.setItemDescription(demands.getItemDescription());
				// demandVo.setSupplierName(demands.getSupplierName());
				// demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				// setting quantity type
				// quantityTypeVO.setQuantityType(demands.getProductCode());

				// setting the date type
				demandVo.setQuantityType(demands.getProductCode());

				if (demands.getProductCode().equalsIgnoreCase(
						"Planned for Supplier")) {

					plannedSupplierCalcVO.setBackpastDue(demands.getPastDue());
					plannedSupplierCalcVO.setBackapr04Apr10(demands
							.getApr04Apr10());
					plannedSupplierCalcVO.setBackapr11Apr17(demands
							.getApr11Apr17());
					plannedSupplierCalcVO.setBackapr18Apr24(demands
							.getApr18Apr24());
					plannedSupplierCalcVO.setBackapr25May01(demands
							.getApr25May01());
					plannedSupplierCalcVO.setBackaug01Aug28(demands
							.getAug01Aug28());
					plannedSupplierCalcVO.setBackaug29Oct02(demands
							.getAug29Oct02());
					plannedSupplierCalcVO.setBackfeb29Mar06(demands
							.getFeb29Mar06());
					plannedSupplierCalcVO.setBackjan02Jan29(demands
							.getJan02Jan29());
					plannedSupplierCalcVO.setBackjan30Feb26(demands
							.getJan30Feb26());
					plannedSupplierCalcVO.setBackjul04Jul31(demands
							.getJul04Jul31());
					plannedSupplierCalcVO.setBackmar07Mar13(demands
							.getMar07Mar13());
					plannedSupplierCalcVO.setBackmar14Mar20(demands
							.getMar14Mar20());
					plannedSupplierCalcVO.setBackmar21Mar27(demands
							.getMar21Mar27());
					plannedSupplierCalcVO.setBackmar28Apr03((demands
							.getMar28Apr03()));
					plannedSupplierCalcVO.setBackmay02May08(demands
							.getMay02May08());
					plannedSupplierCalcVO.setBackmay09May15(demands
							.getMay09May15());
					plannedSupplierCalcVO.setBackmay16May22(demands
							.getMay16May22());
					plannedSupplierCalcVO.setBackmay23May29(demands
							.getMay23May29());
					plannedSupplierCalcVO.setBackmay30Jul03(demands
							.getMay30Jul03());
					plannedSupplierCalcVO.setBacknov28Jan01(demands
							.getNov28Jan01());
					plannedSupplierCalcVO.setBackoct03Oct30(demands
							.getOct03Oct30());
					plannedSupplierCalcVO.setBackoct31Nov27(demands
							.getOct31Nov27());

					// setting it to main VO
					demandVo.setApr04Apr10(plannedSupplierCalcVO
							.getBackapr04Apr10());
					demandVo.setApr11Apr17(plannedSupplierCalcVO
							.getBackapr11Apr17());
					demandVo.setApr18Apr24(plannedSupplierCalcVO
							.getBackapr18Apr24());
					demandVo.setApr25May01(plannedSupplierCalcVO
							.getBackapr25May01());
					demandVo.setAug01Aug28(plannedSupplierCalcVO
							.getBackaug01Aug28());
					demandVo.setAug29Oct02(plannedSupplierCalcVO
							.getBackaug29Oct02());
					demandVo.setFeb29Mar06(plannedSupplierCalcVO
							.getBackfeb29Mar06());
					demandVo.setJan02Jan29(plannedSupplierCalcVO
							.getBackjan02Jan29());
					demandVo.setJan30Feb26(plannedSupplierCalcVO
							.getBackjan30Feb26());
					demandVo.setJul04Jul31(plannedSupplierCalcVO
							.getBackjul04Jul31());
					demandVo.setMar07Mar13(plannedSupplierCalcVO
							.getBackmar07Mar13());
					demandVo.setMar14Mar20(plannedSupplierCalcVO
							.getBackmar14Mar20());
					demandVo.setMar21Mar27(plannedSupplierCalcVO
							.getBackmar21Mar27());
					demandVo.setMar28Apr03((plannedSupplierCalcVO
							.getBackmar28Apr03()));
					demandVo.setMay02May08(plannedSupplierCalcVO
							.getBackmay02May08());
					demandVo.setMay09May15(plannedSupplierCalcVO
							.getBackmay09May15());
					demandVo.setMay16May22(plannedSupplierCalcVO
							.getBackmay16May22());
					demandVo.setMay23May29(plannedSupplierCalcVO
							.getBackmay23May29());
					demandVo.setMay30Jul03(plannedSupplierCalcVO
							.getBackmay30Jul03());
					demandVo.setNov28Jan01(plannedSupplierCalcVO
							.getBacknov28Jan01());
					demandVo.setOct03Oct30(plannedSupplierCalcVO
							.getBackoct03Oct30());
					demandVo.setOct31Nov27(plannedSupplierCalcVO
							.getBackoct31Nov27());
					demandVo.setPastDue(plannedSupplierCalcVO.getBackpastDue());
				}
				if (demands.getProductCode().equalsIgnoreCase(
						"Supplier Commit to Planned")) {

					supplierCommitCalcVO.setcumbackapr11Apr17(demands
							.getApr11Apr17());
					supplierCommitCalcVO.setcumbackapr18Apr24(demands
							.getApr18Apr24());
					supplierCommitCalcVO.setcumbackapr25May01(demands
							.getApr25May01());
					supplierCommitCalcVO.setcumbackaug01Aug28(demands
							.getAug01Aug28());
					supplierCommitCalcVO.setcumbackaug29Oct02(demands
							.getAug29Oct02());
					supplierCommitCalcVO.setcumbackfeb29Mar06(demands
							.getFeb29Mar06());
					supplierCommitCalcVO.setcumbackjan02Jan29(demands
							.getJan02Jan29());
					supplierCommitCalcVO.setcumbackjan30Feb26(demands
							.getJan30Feb26());
					supplierCommitCalcVO.setcumbackjul04Jul31(demands
							.getJul04Jul31());
					supplierCommitCalcVO.setcumbackmar07Mar13(demands
							.getMar07Mar13());
					supplierCommitCalcVO.setcumbackmar14Mar20(demands
							.getMar14Mar20());
					supplierCommitCalcVO.setcumbackmar21Mar27(demands
							.getMar21Mar27());
					supplierCommitCalcVO.setcumbackmar28Apr03((demands
							.getMar28Apr03()));
					supplierCommitCalcVO.setcumbackmay02May08(demands
							.getMay02May08());
					supplierCommitCalcVO.setcumbackmay09May15(demands
							.getMay09May15());
					supplierCommitCalcVO.setcumbackmay16May22(demands
							.getMay16May22());
					supplierCommitCalcVO.setcumbackmay23May29(demands
							.getMay23May29());
					supplierCommitCalcVO.setcumbackmay30Jul03(demands
							.getMay30Jul03());
					supplierCommitCalcVO.setcumbacknov28Jan01(demands
							.getNov28Jan01());
					supplierCommitCalcVO.setcumbackoct03Oct30(demands
							.getOct03Oct30());
					supplierCommitCalcVO.setcumbackoct31Nov27(demands
							.getOct31Nov27());
					supplierCommitCalcVO.setcumbackapr04Apr10(demands
							.getApr04Apr10());
					supplierCommitCalcVO
							.setcumbackpastDue(demands.getPastDue());

					// setting it to main VO

					demandVo.setApr04Apr10(supplierCommitCalcVO
							.getcumbackapr04Apr10());
					demandVo.setApr11Apr17(supplierCommitCalcVO
							.getcumbackapr11Apr17());
					demandVo.setApr18Apr24(supplierCommitCalcVO
							.getcumbackapr18Apr24());
					demandVo.setApr25May01(supplierCommitCalcVO
							.getcumbackapr25May01());
					demandVo.setAug01Aug28(supplierCommitCalcVO
							.getcumbackaug01Aug28());
					demandVo.setAug29Oct02(supplierCommitCalcVO
							.getcumbackaug29Oct02());
					demandVo.setFeb29Mar06(supplierCommitCalcVO
							.getcumbackfeb29Mar06());
					demandVo.setJan02Jan29(supplierCommitCalcVO
							.getcumbackjan02Jan29());
					demandVo.setJan30Feb26(supplierCommitCalcVO
							.getcumbackjan30Feb26());
					demandVo.setJul04Jul31(supplierCommitCalcVO
							.getcumbackjul04Jul31());
					demandVo.setMar07Mar13(supplierCommitCalcVO
							.getcumbackmar07Mar13());
					demandVo.setMar14Mar20(supplierCommitCalcVO
							.getcumbackmar14Mar20());
					demandVo.setMar21Mar27(supplierCommitCalcVO
							.getcumbackmar21Mar27());
					demandVo.setMar28Apr03((supplierCommitCalcVO
							.getcumbackmar28Apr03()));
					demandVo.setMay02May08(supplierCommitCalcVO
							.getcumbackmay02May08());
					demandVo.setMay09May15(supplierCommitCalcVO
							.getcumbackmay09May15());
					demandVo.setMay16May22(supplierCommitCalcVO
							.getcumbackmay16May22());
					demandVo.setMay23May29(supplierCommitCalcVO
							.getcumbackmay23May29());
					demandVo.setMay30Jul03(supplierCommitCalcVO
							.getcumbackmay30Jul03());
					demandVo.setNov28Jan01(supplierCommitCalcVO
							.getcumbacknov28Jan01());
					demandVo.setOct03Oct30(supplierCommitCalcVO
							.getcumbackoct03Oct30());
					demandVo.setOct31Nov27(supplierCommitCalcVO
							.getcumbackoct31Nov27());
					demandVo.setPastDue(supplierCommitCalcVO
							.getcumbackpastDue());

				} else if (demands.getProductCode().equalsIgnoreCase("Backlog")) {
					backLogCalcVO.setBackpastDue(demands.getPastDue());

					// Planned for Supplier - Supplier Commit to Planned

					backLogCalcVO
							.setBackapr04Apr10(plannedSupplierCalcVO
									.getBackapr04Apr10().subtract(
											supplierCommitCalcVO
													.getcumbackapr04Apr10()));
					backLogCalcVO
							.setBackapr11Apr17(plannedSupplierCalcVO
									.getBackapr11Apr17().subtract(
											supplierCommitCalcVO
													.getcumbackapr11Apr17()));
					backLogCalcVO
							.setBackapr18Apr24(plannedSupplierCalcVO
									.getBackapr18Apr24().subtract(
											supplierCommitCalcVO
													.getcumbackapr18Apr24()));
					backLogCalcVO
							.setBackapr25May01(plannedSupplierCalcVO
									.getBackapr25May01().subtract(
											supplierCommitCalcVO
													.getcumbackapr25May01()));
					backLogCalcVO
							.setBackaug01Aug28(plannedSupplierCalcVO
									.getBackaug01Aug28().subtract(
											supplierCommitCalcVO
													.getcumbackaug01Aug28()));
					backLogCalcVO
							.setBackaug29Oct02(plannedSupplierCalcVO
									.getBackaug29Oct02().subtract(
											supplierCommitCalcVO
													.getcumbackaug29Oct02()));
					backLogCalcVO
							.setBackfeb29Mar06(plannedSupplierCalcVO
									.getBackfeb29Mar06().subtract(
											supplierCommitCalcVO
													.getcumbackfeb29Mar06()));
					backLogCalcVO
							.setBackjan02Jan29(plannedSupplierCalcVO
									.getBackjan02Jan29().subtract(
											supplierCommitCalcVO
													.getcumbackjan02Jan29()));
					backLogCalcVO
							.setBackjan30Feb26(plannedSupplierCalcVO
									.getBackjan30Feb26().subtract(
											supplierCommitCalcVO
													.getcumbackjan30Feb26()));
					backLogCalcVO
							.setBackjul04Jul31(plannedSupplierCalcVO
									.getBackjul04Jul31().subtract(
											supplierCommitCalcVO
													.getcumbackjul04Jul31()));
					backLogCalcVO
							.setBackmar07Mar13(plannedSupplierCalcVO
									.getBackmar07Mar13().subtract(
											supplierCommitCalcVO
													.getcumbackmar07Mar13()));
					backLogCalcVO
							.setBackmar14Mar20(plannedSupplierCalcVO
									.getBackmar14Mar20().subtract(
											supplierCommitCalcVO
													.getcumbackmar14Mar20()));
					backLogCalcVO
							.setBackmar21Mar27(plannedSupplierCalcVO
									.getBackmar21Mar27().subtract(
											supplierCommitCalcVO
													.getcumbackmar21Mar27()));
					backLogCalcVO.setBackmar28Apr03((plannedSupplierCalcVO
							.getBackmar28Apr03().subtract(supplierCommitCalcVO
							.getcumbackmar28Apr03())));
					backLogCalcVO
							.setBackmay02May08(plannedSupplierCalcVO
									.getBackmay02May08().subtract(
											supplierCommitCalcVO
													.getcumbackmay02May08()));
					backLogCalcVO
							.setBackmay09May15(plannedSupplierCalcVO
									.getBackmay09May15().subtract(
											supplierCommitCalcVO
													.getcumbackmay09May15()));
					backLogCalcVO
							.setBackmay16May22(plannedSupplierCalcVO
									.getBackmay16May22().subtract(
											supplierCommitCalcVO
													.getcumbackmay16May22()));
					backLogCalcVO
							.setBackmay23May29(plannedSupplierCalcVO
									.getBackmay23May29().subtract(
											supplierCommitCalcVO
													.getcumbackmay23May29()));
					backLogCalcVO
							.setBackmay30Jul03(plannedSupplierCalcVO
									.getBackmay30Jul03().subtract(
											supplierCommitCalcVO
													.getcumbackmay30Jul03()));
					backLogCalcVO
							.setBacknov28Jan01(plannedSupplierCalcVO
									.getBacknov28Jan01().subtract(
											supplierCommitCalcVO
													.getcumbacknov28Jan01()));
					backLogCalcVO
							.setBackoct03Oct30(plannedSupplierCalcVO
									.getBackoct03Oct30().subtract(
											supplierCommitCalcVO
													.getcumbackoct03Oct30()));
					backLogCalcVO
							.setBackoct31Nov27(plannedSupplierCalcVO
									.getBackoct31Nov27().subtract(
											supplierCommitCalcVO
													.getcumbackoct31Nov27()));

					// setting the details to MAIN vo

					demandVo.setApr04Apr10(backLogCalcVO.getBackapr04Apr10());
					demandVo.setApr11Apr17(backLogCalcVO.getBackapr11Apr17());
					demandVo.setApr18Apr24(backLogCalcVO.getBackapr18Apr24());
					demandVo.setApr25May01(backLogCalcVO.getBackapr25May01());
					demandVo.setAug01Aug28(backLogCalcVO.getBackaug01Aug28());
					demandVo.setAug29Oct02(backLogCalcVO.getBackaug29Oct02());
					demandVo.setFeb29Mar06(backLogCalcVO.getBackfeb29Mar06());
					demandVo.setJan02Jan29(backLogCalcVO.getBackjan02Jan29());
					demandVo.setJan30Feb26(backLogCalcVO.getBackjan30Feb26());
					demandVo.setJul04Jul31(backLogCalcVO.getBackjul04Jul31());
					demandVo.setMar07Mar13(backLogCalcVO.getBackmar07Mar13());
					demandVo.setMar14Mar20(backLogCalcVO.getBackmar14Mar20());
					demandVo.setMar21Mar27(backLogCalcVO.getBackmar21Mar27());
					demandVo.setMar28Apr03((backLogCalcVO.getBackmar28Apr03()));
					demandVo.setMay02May08(backLogCalcVO.getBackmay02May08());
					demandVo.setMay09May15(backLogCalcVO.getBackmay09May15());
					demandVo.setMay16May22(backLogCalcVO.getBackmay16May22());
					demandVo.setMay23May29(backLogCalcVO.getBackmay23May29());
					demandVo.setMay30Jul03(backLogCalcVO.getBackmay30Jul03());
					demandVo.setNov28Jan01(backLogCalcVO.getBacknov28Jan01());
					demandVo.setOct03Oct30(backLogCalcVO.getBackoct03Oct30());
					demandVo.setOct31Nov27(backLogCalcVO.getBackoct31Nov27());
					demandVo.setPastDue(backLogCalcVO.getBackpastDue());

				} else if (demands.getProductCode().equalsIgnoreCase(
						"Cum.Backlog")) {
					// demandVo.setPastDue(demands.getPastDue());

					cumBackLogCalcVO.setcumbackapr11Apr17(demands
							.getApr11Apr17());
					cumBackLogCalcVO.setcumbackapr18Apr24(demands
							.getApr18Apr24());
					cumBackLogCalcVO.setcumbackapr25May01(demands
							.getApr25May01());
					cumBackLogCalcVO.setcumbackaug01Aug28(demands
							.getAug01Aug28());
					cumBackLogCalcVO.setcumbackaug29Oct02(demands
							.getAug29Oct02());
					cumBackLogCalcVO.setcumbackfeb29Mar06(demands
							.getFeb29Mar06());
					cumBackLogCalcVO.setcumbackjan02Jan29(demands
							.getJan02Jan29());
					cumBackLogCalcVO.setcumbackjan30Feb26(demands
							.getJan30Feb26());
					cumBackLogCalcVO.setcumbackjul04Jul31(demands
							.getJul04Jul31());
					cumBackLogCalcVO.setcumbackmar07Mar13(demands
							.getMar07Mar13());
					cumBackLogCalcVO.setcumbackmar14Mar20(demands
							.getMar14Mar20());
					cumBackLogCalcVO.setcumbackmar21Mar27(demands
							.getMar21Mar27());
					cumBackLogCalcVO.setcumbackmar28Apr03((demands
							.getMar28Apr03()));
					cumBackLogCalcVO.setcumbackmay02May08(demands
							.getMay02May08());
					cumBackLogCalcVO.setcumbackmay09May15(demands
							.getMay09May15());
					cumBackLogCalcVO.setcumbackmay16May22(demands
							.getMay16May22());
					cumBackLogCalcVO.setcumbackmay23May29(demands
							.getMay23May29());
					cumBackLogCalcVO.setcumbackmay30Jul03(demands
							.getMay30Jul03());
					cumBackLogCalcVO.setcumbacknov28Jan01(demands
							.getNov28Jan01());
					cumBackLogCalcVO.setcumbackoct03Oct30(demands
							.getOct03Oct30());
					cumBackLogCalcVO.setcumbackoct31Nov27(demands
							.getOct31Nov27());
					cumBackLogCalcVO.setcumbackapr04Apr10(demands
							.getApr04Apr10());
					cumBackLogCalcVO.setcumbackpastDue(demands.getPastDue());

					// cumBackLogCalcVO.setcumbackpastDue((backLogCalcVO.getBackpastDue()));

					// setting in order

					cumBackLogCalcVO.setcumbackfeb29Mar06(cumBackLogCalcVO
							.getcumbackpastDue().add(
									backLogCalcVO.getBackfeb29Mar06()));

					cumBackLogCalcVO.setcumbackmar07Mar13(cumBackLogCalcVO
							.getcumbackfeb29Mar06().add(
									backLogCalcVO.getBackmar07Mar13()));

					cumBackLogCalcVO.setcumbackmar14Mar20(cumBackLogCalcVO
							.getcumbackmar07Mar13().add(
									backLogCalcVO.getBackmar14Mar20()));

					cumBackLogCalcVO.setcumbackmar21Mar27(cumBackLogCalcVO
							.getcumbackmar14Mar20().add(
									backLogCalcVO.getBackmar21Mar27()));

					cumBackLogCalcVO.setcumbackmar28Apr03((cumBackLogCalcVO
							.getcumbackmar21Mar27().add(backLogCalcVO
							.getBackmar28Apr03())));

					cumBackLogCalcVO.setcumbackapr04Apr10((cumBackLogCalcVO
							.getcumbackmar28Apr03().add(backLogCalcVO
							.getBackapr04Apr10())));

					cumBackLogCalcVO.setcumbackapr11Apr17((cumBackLogCalcVO
							.getcumbackapr04Apr10().add(backLogCalcVO
							.getBackapr11Apr17())));

					cumBackLogCalcVO.setcumbackapr18Apr24((cumBackLogCalcVO
							.getcumbackapr11Apr17().add(backLogCalcVO
							.getBackapr18Apr24())));

					cumBackLogCalcVO.setcumbackapr25May01(cumBackLogCalcVO
							.getcumbackapr18Apr24().add(
									backLogCalcVO.getBackapr25May01()));

					cumBackLogCalcVO.setcumbackmay02May08(cumBackLogCalcVO
							.getcumbackapr25May01().add(
									backLogCalcVO.getBackmay02May08()));

					cumBackLogCalcVO.setcumbackmay09May15(cumBackLogCalcVO
							.getcumbackmay02May08().add(
									backLogCalcVO.getBackmay09May15()));

					cumBackLogCalcVO.setcumbackmay16May22(cumBackLogCalcVO
							.getcumbackmay09May15().add(
									backLogCalcVO.getBackmay16May22()));

					cumBackLogCalcVO.setcumbackmay23May29(cumBackLogCalcVO
							.getcumbackmay16May22().add(
									backLogCalcVO.getBackmay23May29()));

					cumBackLogCalcVO.setcumbackmay30Jul03(cumBackLogCalcVO
							.getcumbackmay23May29().add(
									backLogCalcVO.getBackmay30Jul03()));

					cumBackLogCalcVO.setcumbackjul04Jul31(cumBackLogCalcVO
							.getcumbackmay30Jul03().add(
									backLogCalcVO.getBackjul04Jul31()));

					cumBackLogCalcVO.setcumbackaug01Aug28(cumBackLogCalcVO
							.getcumbackjul04Jul31().add(
									backLogCalcVO.getBackaug01Aug28()));

					cumBackLogCalcVO.setcumbackaug29Oct02(cumBackLogCalcVO
							.getcumbackaug01Aug28().add(
									backLogCalcVO.getBackaug29Oct02()));

					cumBackLogCalcVO.setcumbackoct03Oct30(cumBackLogCalcVO
							.getcumbackaug29Oct02().add(
									backLogCalcVO.getBackoct03Oct30()));

					cumBackLogCalcVO.setcumbackoct31Nov27(cumBackLogCalcVO
							.getcumbackoct03Oct30().add(
									backLogCalcVO.getBackoct31Nov27()));

					cumBackLogCalcVO.setcumbacknov28Jan01(cumBackLogCalcVO
							.getcumbackoct31Nov27().add(
									backLogCalcVO.getBacknov28Jan01()));

					cumBackLogCalcVO.setcumbackjan02Jan29(cumBackLogCalcVO
							.getcumbacknov28Jan01().add(
									backLogCalcVO.getBackjan02Jan29()));

					cumBackLogCalcVO.setcumbackjan30Feb26(cumBackLogCalcVO
							.getcumbackjan02Jan29().add(
									backLogCalcVO.getBackjan30Feb26()));

					// setting the details to MAIN vo

					demandVo.setApr04Apr10(cumBackLogCalcVO
							.getcumbackapr04Apr10());
					demandVo.setApr11Apr17(cumBackLogCalcVO
							.getcumbackapr11Apr17());
					demandVo.setApr18Apr24(cumBackLogCalcVO
							.getcumbackapr18Apr24());
					demandVo.setApr25May01(cumBackLogCalcVO
							.getcumbackapr25May01());
					demandVo.setAug01Aug28(cumBackLogCalcVO
							.getcumbackaug01Aug28());
					demandVo.setAug29Oct02(cumBackLogCalcVO
							.getcumbackaug29Oct02());
					demandVo.setFeb29Mar06(cumBackLogCalcVO
							.getcumbackfeb29Mar06());
					demandVo.setJan02Jan29(cumBackLogCalcVO
							.getcumbackjan02Jan29());
					demandVo.setJan30Feb26(cumBackLogCalcVO
							.getcumbackjan30Feb26());
					demandVo.setJul04Jul31(cumBackLogCalcVO
							.getcumbackjul04Jul31());
					demandVo.setMar07Mar13(cumBackLogCalcVO
							.getcumbackmar07Mar13());
					demandVo.setMar14Mar20(cumBackLogCalcVO
							.getcumbackmar14Mar20());
					demandVo.setMar21Mar27(cumBackLogCalcVO
							.getcumbackmar21Mar27());
					demandVo.setMar28Apr03((cumBackLogCalcVO
							.getcumbackmar28Apr03()));
					demandVo.setMay02May08(cumBackLogCalcVO
							.getcumbackmay02May08());
					demandVo.setMay09May15(cumBackLogCalcVO
							.getcumbackmay09May15());
					demandVo.setMay16May22(cumBackLogCalcVO
							.getcumbackmay16May22());
					demandVo.setMay23May29(cumBackLogCalcVO
							.getcumbackmay23May29());
					demandVo.setMay30Jul03(cumBackLogCalcVO
							.getcumbackmay30Jul03());
					demandVo.setNov28Jan01(cumBackLogCalcVO
							.getcumbacknov28Jan01());
					demandVo.setOct03Oct30(cumBackLogCalcVO
							.getcumbackoct03Oct30());
					demandVo.setOct31Nov27(cumBackLogCalcVO
							.getcumbackoct31Nov27());
					demandVo.setPastDue(cumBackLogCalcVO.getcumbackpastDue());

				} else {
					demandVo.setApr11Apr17(demands.getApr11Apr17());
					demandVo.setApr18Apr24(demands.getApr18Apr24());
					demandVo.setApr25May01(demands.getApr25May01());
					demandVo.setAug01Aug28(demands.getAug01Aug28());
					demandVo.setAug29Oct02(demands.getAug29Oct02());
					demandVo.setFeb29Mar06(demands.getFeb29Mar06());
					demandVo.setJan02Jan29(demands.getJan02Jan29());
					demandVo.setJan30Feb26(demands.getJan30Feb26());
					demandVo.setJul04Jul31(demands.getJul04Jul31());
					demandVo.setMar07Mar13(demands.getMar07Mar13());
					demandVo.setMar14Mar20(demands.getMar14Mar20());
					demandVo.setMar21Mar27(demands.getMar21Mar27());
					demandVo.setMar28Apr03((demands.getMar28Apr03()));
					demandVo.setMay02May08(demands.getMay02May08());
					demandVo.setMay09May15(demands.getMay09May15());
					demandVo.setMay16May22(demands.getMay16May22());
					demandVo.setMay23May29(demands.getMay23May29());
					demandVo.setMay30Jul03(demands.getMay30Jul03());
					demandVo.setNov28Jan01(demands.getNov28Jan01());
					demandVo.setOct03Oct30(demands.getOct03Oct30());
					demandVo.setOct31Nov27(demands.getOct31Nov27());
					demandVo.setApr04Apr10(demands.getApr04Apr10());
				}

				/*
				 * demandVo.setApr04Apr10(demands.getApr04Apr10());
				 * demandVo.setApr11Apr17(demands.getApr11Apr17());
				 * demandVo.setApr18Apr24(demands.getApr18Apr24());
				 * demandVo.setApr25May01(demands.getApr25May01());
				 * demandVo.setAug01Aug28(demands.getAug01Aug28());
				 * demandVo.setAug29Oct02(demands.getAug29Oct02());
				 * demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				 * demandVo.setJan02Jan29(demands.getJan02Jan29());
				 * demandVo.setJan30Feb26(demands.getJan30Feb26());
				 * demandVo.setJul04Jul31(demands.getJul04Jul31());
				 * demandVo.setMar07Mar13(demands.getMar07Mar13());
				 * demandVo.setMar14Mar20(demands.getMar14Mar20());
				 * demandVo.setMar21Mar27(demands.getMar21Mar27());
				 * demandVo.setMar28Apr03((demands.getMar28Apr03()));
				 * demandVo.setMay02May08(demands.getMay02May08());
				 * demandVo.setMay09May15(demands.getMay09May15());
				 * demandVo.setMay16May22(demands.getMay16May22());
				 * demandVo.setMay23May29(demands.getMay23May29());
				 * demandVo.setMay30Jul03(demands.getMay30Jul03());
				 * demandVo.setNov28Jan01(demands.getNov28Jan01());
				 * demandVo.setOct03Oct30(demands.getOct03Oct30());
				 * demandVo.setOct31Nov27(demands.getOct31Nov27());
				 */

				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());

				// demandDateVoList.add(dateVO);
				// quantityTypeVO.setDemandDateVos(demandDateVoList);
				// quantityVoList.add(quantityTypeVO);
				// demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);

			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandDetailsWithOutFilter()"
							+ e);
		}
		return demandVos;

	}

	@RequestMapping(value = "/view/getDemandAllDetailsWithFilterNew", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithFilterNew(
			@RequestBody @Valid final GetsDemand demand) {

		List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		DemandsDetailsVO demandVo = null;
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new
		// ArrayList<QuantityTypeVO>();
		// List<DemandDateVO> demandDateVoList = new ArrayList<DemandDateVO>();
		try {
			DemandSearchSpecification demandSearchSpecification = new DemandSearchSpecification(
					demand);
			List<GetsDemand> demandList = demandSearchRepo
					.findAll(demandSearchSpecification);

			for (GetsDemand demands : demandList) {
				demandVo = new DemandsDetailsVO();
				// quantityTypeVO = new QuantityTypeVO();
				// dateVO = new DemandDateVO();

				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands
						.getInventoryOrganization());
				// setting quantity type
				// quantityTypeVO.setQuantityType(demands.getProductCode());

				// setting the date type
				demandVo.setQuantityType(demands.getProductCode());
				demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03(demands.getMar28Apr03());
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());

				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());

				// demandDateVoList.add(dateVO);
				// quantityTypeVO.setDemandDateVos(demandDateVoList);
				// quantityVoList.add(quantityTypeVO);
				// demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);

			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandDetailsWithOutFilter()"
							+ e);
		}
		return demandVos;

	}

	@RequestMapping(value = "/view/getDemandDetailsWithOutFiltersExcel", produces = "application/vnd.ms-excel")
	// @RequestMapping("/view/getDemandDetailsWithOutFiltersExcel", method =
	// RequestMethod.POST, produces="application/json")
	public @ResponseBody void downloadDemanDetailsinExcelWithoutFilter(
			HttpServletResponse response) {
		List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		DemandsDetailsVO demandVo = null;
		BackLogCalcVO backLogCalcVO = new BackLogCalcVO();
		CumBackLogCalcVO cumBackLogCalcVO = null;
		SupplierCommitCalcVO supplierCommitCalcVO = new SupplierCommitCalcVO(); // equv
																				// cum
																				// backlog
																				// vo
		PlannedSupplierCalcVO plannedSupplierCalcVO = new PlannedSupplierCalcVO();// equv
																					// baclogvo
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new
		// ArrayList<QuantityTypeVO>();
		// List<DemandDateVO> demandDateVoList = new ArrayList<DemandDateVO>();
		ClassPathResource pdfFile = new ClassPathResource("pdf-sample.pdf");
		ResponseEntity<InputStreamResource> entity = null;
		try {
			List<GetsDemand> demandList = demandRepo.findAll();

			for (GetsDemand demands : demandList) {
				demandVo = new DemandsDetailsVO();
				cumBackLogCalcVO = new CumBackLogCalcVO();
				// quantityTypeVO = new QuantityTypeVO();
				// dateVO = new DemandDateVO();

				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands
						.getInventoryOrganization());
				// setting quantity type
				// quantityTypeVO.setQuantityType(demands.getProductCode());

				// setting the date type
				/*
				 * demandVo.setQuantityType(demands.getProductCode());
				 * demandVo.setApr04Apr10(demands.getApr04Apr10());
				 * demandVo.setApr11Apr17(demands.getApr11Apr17());
				 * demandVo.setApr18Apr24(demands.getApr18Apr24());
				 * demandVo.setApr25May01(demands.getApr25May01());
				 * demandVo.setAug01Aug28(demands.getAug01Aug28());
				 * demandVo.setAug29Oct02(demands.getAug29Oct02());
				 * demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				 * demandVo.setJan02Jan29(demands.getJan02Jan29());
				 * demandVo.setJan30Feb26(demands.getJan30Feb26());
				 * demandVo.setJul04Jul31(demands.getJul04Jul31());
				 * demandVo.setMar07Mar13(demands.getMar07Mar13());
				 * demandVo.setMar14Mar20(demands.getMar14Mar20());
				 * demandVo.setMar21Mar27(demands.getMar21Mar27());
				 * demandVo.setMar28Apr03(demands.getMar28Apr03());
				 * demandVo.setMay02May08(demands.getMay02May08());
				 * demandVo.setMay09May15(demands.getMay09May15());
				 * demandVo.setMay16May22(demands.getMay16May22());
				 * demandVo.setMay23May29(demands.getMay23May29());
				 * demandVo.setMay30Jul03(demands.getMay30Jul03());
				 * demandVo.setNov28Jan01(demands.getNov28Jan01());
				 * demandVo.setOct03Oct30(demands.getOct03Oct30());
				 * demandVo.setOct31Nov27(demands.getOct31Nov27());
				 */

				if (demands.getProductCode().equalsIgnoreCase(
						"Planned for Supplier")) {

					plannedSupplierCalcVO.setBackpastDue(demands.getPastDue());
					plannedSupplierCalcVO.setBackapr04Apr10(demands
							.getApr04Apr10());
					plannedSupplierCalcVO.setBackapr11Apr17(demands
							.getApr11Apr17());
					plannedSupplierCalcVO.setBackapr18Apr24(demands
							.getApr18Apr24());
					plannedSupplierCalcVO.setBackapr25May01(demands
							.getApr25May01());
					plannedSupplierCalcVO.setBackaug01Aug28(demands
							.getAug01Aug28());
					plannedSupplierCalcVO.setBackaug29Oct02(demands
							.getAug29Oct02());
					plannedSupplierCalcVO.setBackfeb29Mar06(demands
							.getFeb29Mar06());
					plannedSupplierCalcVO.setBackjan02Jan29(demands
							.getJan02Jan29());
					plannedSupplierCalcVO.setBackjan30Feb26(demands
							.getJan30Feb26());
					plannedSupplierCalcVO.setBackjul04Jul31(demands
							.getJul04Jul31());
					plannedSupplierCalcVO.setBackmar07Mar13(demands
							.getMar07Mar13());
					plannedSupplierCalcVO.setBackmar14Mar20(demands
							.getMar14Mar20());
					plannedSupplierCalcVO.setBackmar21Mar27(demands
							.getMar21Mar27());
					plannedSupplierCalcVO.setBackmar28Apr03((demands
							.getMar28Apr03()));
					plannedSupplierCalcVO.setBackmay02May08(demands
							.getMay02May08());
					plannedSupplierCalcVO.setBackmay09May15(demands
							.getMay09May15());
					plannedSupplierCalcVO.setBackmay16May22(demands
							.getMay16May22());
					plannedSupplierCalcVO.setBackmay23May29(demands
							.getMay23May29());
					plannedSupplierCalcVO.setBackmay30Jul03(demands
							.getMay30Jul03());
					plannedSupplierCalcVO.setBacknov28Jan01(demands
							.getNov28Jan01());
					plannedSupplierCalcVO.setBackoct03Oct30(demands
							.getOct03Oct30());
					plannedSupplierCalcVO.setBackoct31Nov27(demands
							.getOct31Nov27());

					// setting it to main VO
					demandVo.setApr04Apr10(plannedSupplierCalcVO
							.getBackapr04Apr10());
					demandVo.setApr11Apr17(plannedSupplierCalcVO
							.getBackapr11Apr17());
					demandVo.setApr18Apr24(plannedSupplierCalcVO
							.getBackapr18Apr24());
					demandVo.setApr25May01(plannedSupplierCalcVO
							.getBackapr25May01());
					demandVo.setAug01Aug28(plannedSupplierCalcVO
							.getBackaug01Aug28());
					demandVo.setAug29Oct02(plannedSupplierCalcVO
							.getBackaug29Oct02());
					demandVo.setFeb29Mar06(plannedSupplierCalcVO
							.getBackfeb29Mar06());
					demandVo.setJan02Jan29(plannedSupplierCalcVO
							.getBackjan02Jan29());
					demandVo.setJan30Feb26(plannedSupplierCalcVO
							.getBackjan30Feb26());
					demandVo.setJul04Jul31(plannedSupplierCalcVO
							.getBackjul04Jul31());
					demandVo.setMar07Mar13(plannedSupplierCalcVO
							.getBackmar07Mar13());
					demandVo.setMar14Mar20(plannedSupplierCalcVO
							.getBackmar14Mar20());
					demandVo.setMar21Mar27(plannedSupplierCalcVO
							.getBackmar21Mar27());
					demandVo.setMar28Apr03((plannedSupplierCalcVO
							.getBackmar28Apr03()));
					demandVo.setMay02May08(plannedSupplierCalcVO
							.getBackmay02May08());
					demandVo.setMay09May15(plannedSupplierCalcVO
							.getBackmay09May15());
					demandVo.setMay16May22(plannedSupplierCalcVO
							.getBackmay16May22());
					demandVo.setMay23May29(plannedSupplierCalcVO
							.getBackmay23May29());
					demandVo.setMay30Jul03(plannedSupplierCalcVO
							.getBackmay30Jul03());
					demandVo.setNov28Jan01(plannedSupplierCalcVO
							.getBacknov28Jan01());
					demandVo.setOct03Oct30(plannedSupplierCalcVO
							.getBackoct03Oct30());
					demandVo.setOct31Nov27(plannedSupplierCalcVO
							.getBackoct31Nov27());
					demandVo.setPastDue(plannedSupplierCalcVO.getBackpastDue());
				}
				if (demands.getProductCode().equalsIgnoreCase(
						"Supplier Commit to Planned")) {

					supplierCommitCalcVO.setcumbackapr11Apr17(demands
							.getApr11Apr17());
					supplierCommitCalcVO.setcumbackapr18Apr24(demands
							.getApr18Apr24());
					supplierCommitCalcVO.setcumbackapr25May01(demands
							.getApr25May01());
					supplierCommitCalcVO.setcumbackaug01Aug28(demands
							.getAug01Aug28());
					supplierCommitCalcVO.setcumbackaug29Oct02(demands
							.getAug29Oct02());
					supplierCommitCalcVO.setcumbackfeb29Mar06(demands
							.getFeb29Mar06());
					supplierCommitCalcVO.setcumbackjan02Jan29(demands
							.getJan02Jan29());
					supplierCommitCalcVO.setcumbackjan30Feb26(demands
							.getJan30Feb26());
					supplierCommitCalcVO.setcumbackjul04Jul31(demands
							.getJul04Jul31());
					supplierCommitCalcVO.setcumbackmar07Mar13(demands
							.getMar07Mar13());
					supplierCommitCalcVO.setcumbackmar14Mar20(demands
							.getMar14Mar20());
					supplierCommitCalcVO.setcumbackmar21Mar27(demands
							.getMar21Mar27());
					supplierCommitCalcVO.setcumbackmar28Apr03((demands
							.getMar28Apr03()));
					supplierCommitCalcVO.setcumbackmay02May08(demands
							.getMay02May08());
					supplierCommitCalcVO.setcumbackmay09May15(demands
							.getMay09May15());
					supplierCommitCalcVO.setcumbackmay16May22(demands
							.getMay16May22());
					supplierCommitCalcVO.setcumbackmay23May29(demands
							.getMay23May29());
					supplierCommitCalcVO.setcumbackmay30Jul03(demands
							.getMay30Jul03());
					supplierCommitCalcVO.setcumbacknov28Jan01(demands
							.getNov28Jan01());
					supplierCommitCalcVO.setcumbackoct03Oct30(demands
							.getOct03Oct30());
					supplierCommitCalcVO.setcumbackoct31Nov27(demands
							.getOct31Nov27());
					supplierCommitCalcVO.setcumbackapr04Apr10(demands
							.getApr04Apr10());
					supplierCommitCalcVO
							.setcumbackpastDue(demands.getPastDue());

					// setting it to main VO

					demandVo.setApr04Apr10(supplierCommitCalcVO
							.getcumbackapr04Apr10());
					demandVo.setApr11Apr17(supplierCommitCalcVO
							.getcumbackapr11Apr17());
					demandVo.setApr18Apr24(supplierCommitCalcVO
							.getcumbackapr18Apr24());
					demandVo.setApr25May01(supplierCommitCalcVO
							.getcumbackapr25May01());
					demandVo.setAug01Aug28(supplierCommitCalcVO
							.getcumbackaug01Aug28());
					demandVo.setAug29Oct02(supplierCommitCalcVO
							.getcumbackaug29Oct02());
					demandVo.setFeb29Mar06(supplierCommitCalcVO
							.getcumbackfeb29Mar06());
					demandVo.setJan02Jan29(supplierCommitCalcVO
							.getcumbackjan02Jan29());
					demandVo.setJan30Feb26(supplierCommitCalcVO
							.getcumbackjan30Feb26());
					demandVo.setJul04Jul31(supplierCommitCalcVO
							.getcumbackjul04Jul31());
					demandVo.setMar07Mar13(supplierCommitCalcVO
							.getcumbackmar07Mar13());
					demandVo.setMar14Mar20(supplierCommitCalcVO
							.getcumbackmar14Mar20());
					demandVo.setMar21Mar27(supplierCommitCalcVO
							.getcumbackmar21Mar27());
					demandVo.setMar28Apr03((supplierCommitCalcVO
							.getcumbackmar28Apr03()));
					demandVo.setMay02May08(supplierCommitCalcVO
							.getcumbackmay02May08());
					demandVo.setMay09May15(supplierCommitCalcVO
							.getcumbackmay09May15());
					demandVo.setMay16May22(supplierCommitCalcVO
							.getcumbackmay16May22());
					demandVo.setMay23May29(supplierCommitCalcVO
							.getcumbackmay23May29());
					demandVo.setMay30Jul03(supplierCommitCalcVO
							.getcumbackmay30Jul03());
					demandVo.setNov28Jan01(supplierCommitCalcVO
							.getcumbacknov28Jan01());
					demandVo.setOct03Oct30(supplierCommitCalcVO
							.getcumbackoct03Oct30());
					demandVo.setOct31Nov27(supplierCommitCalcVO
							.getcumbackoct31Nov27());
					demandVo.setPastDue(supplierCommitCalcVO
							.getcumbackpastDue());

				} else if (demands.getProductCode().equalsIgnoreCase("Backlog")) {
					backLogCalcVO.setBackpastDue(demands.getPastDue());

					// Planned for Supplier - Supplier Commit to Planned

					backLogCalcVO
							.setBackapr04Apr10(plannedSupplierCalcVO
									.getBackapr04Apr10().subtract(
											supplierCommitCalcVO
													.getcumbackapr04Apr10()));
					backLogCalcVO
							.setBackapr11Apr17(plannedSupplierCalcVO
									.getBackapr11Apr17().subtract(
											supplierCommitCalcVO
													.getcumbackapr11Apr17()));
					backLogCalcVO
							.setBackapr18Apr24(plannedSupplierCalcVO
									.getBackapr18Apr24().subtract(
											supplierCommitCalcVO
													.getcumbackapr18Apr24()));
					backLogCalcVO
							.setBackapr25May01(plannedSupplierCalcVO
									.getBackapr25May01().subtract(
											supplierCommitCalcVO
													.getcumbackapr25May01()));
					backLogCalcVO
							.setBackaug01Aug28(plannedSupplierCalcVO
									.getBackaug01Aug28().subtract(
											supplierCommitCalcVO
													.getcumbackaug01Aug28()));
					backLogCalcVO
							.setBackaug29Oct02(plannedSupplierCalcVO
									.getBackaug29Oct02().subtract(
											supplierCommitCalcVO
													.getcumbackaug29Oct02()));
					backLogCalcVO
							.setBackfeb29Mar06(plannedSupplierCalcVO
									.getBackfeb29Mar06().subtract(
											supplierCommitCalcVO
													.getcumbackfeb29Mar06()));
					backLogCalcVO
							.setBackjan02Jan29(plannedSupplierCalcVO
									.getBackjan02Jan29().subtract(
											supplierCommitCalcVO
													.getcumbackjan02Jan29()));
					backLogCalcVO
							.setBackjan30Feb26(plannedSupplierCalcVO
									.getBackjan30Feb26().subtract(
											supplierCommitCalcVO
													.getcumbackjan30Feb26()));
					backLogCalcVO
							.setBackjul04Jul31(plannedSupplierCalcVO
									.getBackjul04Jul31().subtract(
											supplierCommitCalcVO
													.getcumbackjul04Jul31()));
					backLogCalcVO
							.setBackmar07Mar13(plannedSupplierCalcVO
									.getBackmar07Mar13().subtract(
											supplierCommitCalcVO
													.getcumbackmar07Mar13()));
					backLogCalcVO
							.setBackmar14Mar20(plannedSupplierCalcVO
									.getBackmar14Mar20().subtract(
											supplierCommitCalcVO
													.getcumbackmar14Mar20()));
					backLogCalcVO
							.setBackmar21Mar27(plannedSupplierCalcVO
									.getBackmar21Mar27().subtract(
											supplierCommitCalcVO
													.getcumbackmar21Mar27()));
					backLogCalcVO.setBackmar28Apr03((plannedSupplierCalcVO
							.getBackmar28Apr03().subtract(supplierCommitCalcVO
							.getcumbackmar28Apr03())));
					backLogCalcVO
							.setBackmay02May08(plannedSupplierCalcVO
									.getBackmay02May08().subtract(
											supplierCommitCalcVO
													.getcumbackmay02May08()));
					backLogCalcVO
							.setBackmay09May15(plannedSupplierCalcVO
									.getBackmay09May15().subtract(
											supplierCommitCalcVO
													.getcumbackmay09May15()));
					backLogCalcVO
							.setBackmay16May22(plannedSupplierCalcVO
									.getBackmay16May22().subtract(
											supplierCommitCalcVO
													.getcumbackmay16May22()));
					backLogCalcVO
							.setBackmay23May29(plannedSupplierCalcVO
									.getBackmay23May29().subtract(
											supplierCommitCalcVO
													.getcumbackmay23May29()));
					backLogCalcVO
							.setBackmay30Jul03(plannedSupplierCalcVO
									.getBackmay30Jul03().subtract(
											supplierCommitCalcVO
													.getcumbackmay30Jul03()));
					backLogCalcVO
							.setBacknov28Jan01(plannedSupplierCalcVO
									.getBacknov28Jan01().subtract(
											supplierCommitCalcVO
													.getcumbacknov28Jan01()));
					backLogCalcVO
							.setBackoct03Oct30(plannedSupplierCalcVO
									.getBackoct03Oct30().subtract(
											supplierCommitCalcVO
													.getcumbackoct03Oct30()));
					backLogCalcVO
							.setBackoct31Nov27(plannedSupplierCalcVO
									.getBackoct31Nov27().subtract(
											supplierCommitCalcVO
													.getcumbackoct31Nov27()));

					// setting the details to MAIN vo

					demandVo.setApr04Apr10(backLogCalcVO.getBackapr04Apr10());
					demandVo.setApr11Apr17(backLogCalcVO.getBackapr11Apr17());
					demandVo.setApr18Apr24(backLogCalcVO.getBackapr18Apr24());
					demandVo.setApr25May01(backLogCalcVO.getBackapr25May01());
					demandVo.setAug01Aug28(backLogCalcVO.getBackaug01Aug28());
					demandVo.setAug29Oct02(backLogCalcVO.getBackaug29Oct02());
					demandVo.setFeb29Mar06(backLogCalcVO.getBackfeb29Mar06());
					demandVo.setJan02Jan29(backLogCalcVO.getBackjan02Jan29());
					demandVo.setJan30Feb26(backLogCalcVO.getBackjan30Feb26());
					demandVo.setJul04Jul31(backLogCalcVO.getBackjul04Jul31());
					demandVo.setMar07Mar13(backLogCalcVO.getBackmar07Mar13());
					demandVo.setMar14Mar20(backLogCalcVO.getBackmar14Mar20());
					demandVo.setMar21Mar27(backLogCalcVO.getBackmar21Mar27());
					demandVo.setMar28Apr03((backLogCalcVO.getBackmar28Apr03()));
					demandVo.setMay02May08(backLogCalcVO.getBackmay02May08());
					demandVo.setMay09May15(backLogCalcVO.getBackmay09May15());
					demandVo.setMay16May22(backLogCalcVO.getBackmay16May22());
					demandVo.setMay23May29(backLogCalcVO.getBackmay23May29());
					demandVo.setMay30Jul03(backLogCalcVO.getBackmay30Jul03());
					demandVo.setNov28Jan01(backLogCalcVO.getBacknov28Jan01());
					demandVo.setOct03Oct30(backLogCalcVO.getBackoct03Oct30());
					demandVo.setOct31Nov27(backLogCalcVO.getBackoct31Nov27());
					demandVo.setPastDue(backLogCalcVO.getBackpastDue());

				} else if (demands.getProductCode().equalsIgnoreCase(
						"Cum.Backlog")) {
					// demandVo.setPastDue(demands.getPastDue());

					cumBackLogCalcVO.setcumbackapr11Apr17(demands
							.getApr11Apr17());
					cumBackLogCalcVO.setcumbackapr18Apr24(demands
							.getApr18Apr24());
					cumBackLogCalcVO.setcumbackapr25May01(demands
							.getApr25May01());
					cumBackLogCalcVO.setcumbackaug01Aug28(demands
							.getAug01Aug28());
					cumBackLogCalcVO.setcumbackaug29Oct02(demands
							.getAug29Oct02());
					cumBackLogCalcVO.setcumbackfeb29Mar06(demands
							.getFeb29Mar06());
					cumBackLogCalcVO.setcumbackjan02Jan29(demands
							.getJan02Jan29());
					cumBackLogCalcVO.setcumbackjan30Feb26(demands
							.getJan30Feb26());
					cumBackLogCalcVO.setcumbackjul04Jul31(demands
							.getJul04Jul31());
					cumBackLogCalcVO.setcumbackmar07Mar13(demands
							.getMar07Mar13());
					cumBackLogCalcVO.setcumbackmar14Mar20(demands
							.getMar14Mar20());
					cumBackLogCalcVO.setcumbackmar21Mar27(demands
							.getMar21Mar27());
					cumBackLogCalcVO.setcumbackmar28Apr03((demands
							.getMar28Apr03()));
					cumBackLogCalcVO.setcumbackmay02May08(demands
							.getMay02May08());
					cumBackLogCalcVO.setcumbackmay09May15(demands
							.getMay09May15());
					cumBackLogCalcVO.setcumbackmay16May22(demands
							.getMay16May22());
					cumBackLogCalcVO.setcumbackmay23May29(demands
							.getMay23May29());
					cumBackLogCalcVO.setcumbackmay30Jul03(demands
							.getMay30Jul03());
					cumBackLogCalcVO.setcumbacknov28Jan01(demands
							.getNov28Jan01());
					cumBackLogCalcVO.setcumbackoct03Oct30(demands
							.getOct03Oct30());
					cumBackLogCalcVO.setcumbackoct31Nov27(demands
							.getOct31Nov27());
					cumBackLogCalcVO.setcumbackapr04Apr10(demands
							.getApr04Apr10());
					cumBackLogCalcVO.setcumbackpastDue(demands.getPastDue());

					// cumBackLogCalcVO.setcumbackpastDue((backLogCalcVO.getBackpastDue()));

					cumBackLogCalcVO.setcumbackfeb29Mar06(cumBackLogCalcVO
							.getcumbackpastDue().add(
									backLogCalcVO.getBackfeb29Mar06()));

					cumBackLogCalcVO.setcumbackmar07Mar13(cumBackLogCalcVO
							.getcumbackfeb29Mar06().add(
									backLogCalcVO.getBackmar07Mar13()));

					cumBackLogCalcVO.setcumbackmar14Mar20(cumBackLogCalcVO
							.getcumbackmar07Mar13().add(
									backLogCalcVO.getBackmar14Mar20()));

					cumBackLogCalcVO.setcumbackmar21Mar27(cumBackLogCalcVO
							.getcumbackmar14Mar20().add(
									backLogCalcVO.getBackmar21Mar27()));

					cumBackLogCalcVO.setcumbackmar28Apr03((cumBackLogCalcVO
							.getcumbackmar21Mar27().add(backLogCalcVO
							.getBackmar28Apr03())));

					cumBackLogCalcVO.setcumbackapr04Apr10((cumBackLogCalcVO
							.getcumbackmar28Apr03().add(backLogCalcVO
							.getBackapr04Apr10())));

					cumBackLogCalcVO.setcumbackapr11Apr17((cumBackLogCalcVO
							.getcumbackapr04Apr10().add(backLogCalcVO
							.getBackapr11Apr17())));

					cumBackLogCalcVO.setcumbackapr18Apr24((cumBackLogCalcVO
							.getcumbackapr11Apr17().add(backLogCalcVO
							.getBackapr18Apr24())));

					cumBackLogCalcVO.setcumbackapr25May01(cumBackLogCalcVO
							.getcumbackapr18Apr24().add(
									backLogCalcVO.getBackapr25May01()));

					cumBackLogCalcVO.setcumbackmay02May08(cumBackLogCalcVO
							.getcumbackapr25May01().add(
									backLogCalcVO.getBackmay02May08()));

					cumBackLogCalcVO.setcumbackmay09May15(cumBackLogCalcVO
							.getcumbackmay02May08().add(
									backLogCalcVO.getBackmay09May15()));

					cumBackLogCalcVO.setcumbackmay16May22(cumBackLogCalcVO
							.getcumbackmay09May15().add(
									backLogCalcVO.getBackmay16May22()));

					cumBackLogCalcVO.setcumbackmay23May29(cumBackLogCalcVO
							.getcumbackmay16May22().add(
									backLogCalcVO.getBackmay23May29()));

					cumBackLogCalcVO.setcumbackmay30Jul03(cumBackLogCalcVO
							.getcumbackmay23May29().add(
									backLogCalcVO.getBackmay30Jul03()));

					cumBackLogCalcVO.setcumbackjul04Jul31(cumBackLogCalcVO
							.getcumbackmay30Jul03().add(
									backLogCalcVO.getBackjul04Jul31()));

					cumBackLogCalcVO.setcumbackaug01Aug28(cumBackLogCalcVO
							.getcumbackjul04Jul31().add(
									backLogCalcVO.getBackaug01Aug28()));

					cumBackLogCalcVO.setcumbackaug29Oct02(cumBackLogCalcVO
							.getcumbackaug01Aug28().add(
									backLogCalcVO.getBackaug29Oct02()));

					cumBackLogCalcVO.setcumbackoct03Oct30(cumBackLogCalcVO
							.getcumbackaug29Oct02().add(
									backLogCalcVO.getBackoct03Oct30()));

					cumBackLogCalcVO.setcumbackoct31Nov27(cumBackLogCalcVO
							.getcumbackoct03Oct30().add(
									backLogCalcVO.getBackoct31Nov27()));

					cumBackLogCalcVO.setcumbacknov28Jan01(cumBackLogCalcVO
							.getcumbackoct31Nov27().add(
									backLogCalcVO.getBacknov28Jan01()));

					cumBackLogCalcVO.setcumbackjan02Jan29(cumBackLogCalcVO
							.getcumbacknov28Jan01().add(
									backLogCalcVO.getBackjan02Jan29()));

					cumBackLogCalcVO.setcumbackjan30Feb26(cumBackLogCalcVO
							.getcumbackjan02Jan29().add(
									backLogCalcVO.getBackjan30Feb26()));

					// setting the details to MAIN vo

					demandVo.setApr04Apr10(cumBackLogCalcVO
							.getcumbackapr04Apr10());
					demandVo.setApr11Apr17(cumBackLogCalcVO
							.getcumbackapr11Apr17());
					demandVo.setApr18Apr24(cumBackLogCalcVO
							.getcumbackapr18Apr24());
					demandVo.setApr25May01(cumBackLogCalcVO
							.getcumbackapr25May01());
					demandVo.setAug01Aug28(cumBackLogCalcVO
							.getcumbackaug01Aug28());
					demandVo.setAug29Oct02(cumBackLogCalcVO
							.getcumbackaug29Oct02());
					demandVo.setFeb29Mar06(cumBackLogCalcVO
							.getcumbackfeb29Mar06());
					demandVo.setJan02Jan29(cumBackLogCalcVO
							.getcumbackjan02Jan29());
					demandVo.setJan30Feb26(cumBackLogCalcVO
							.getcumbackjan30Feb26());
					demandVo.setJul04Jul31(cumBackLogCalcVO
							.getcumbackjul04Jul31());
					demandVo.setMar07Mar13(cumBackLogCalcVO
							.getcumbackmar07Mar13());
					demandVo.setMar14Mar20(cumBackLogCalcVO
							.getcumbackmar14Mar20());
					demandVo.setMar21Mar27(cumBackLogCalcVO
							.getcumbackmar21Mar27());
					demandVo.setMar28Apr03((cumBackLogCalcVO
							.getcumbackmar28Apr03()));
					demandVo.setMay02May08(cumBackLogCalcVO
							.getcumbackmay02May08());
					demandVo.setMay09May15(cumBackLogCalcVO
							.getcumbackmay09May15());
					demandVo.setMay16May22(cumBackLogCalcVO
							.getcumbackmay16May22());
					demandVo.setMay23May29(cumBackLogCalcVO
							.getcumbackmay23May29());
					demandVo.setMay30Jul03(cumBackLogCalcVO
							.getcumbackmay30Jul03());
					demandVo.setNov28Jan01(cumBackLogCalcVO
							.getcumbacknov28Jan01());
					demandVo.setOct03Oct30(cumBackLogCalcVO
							.getcumbackoct03Oct30());
					demandVo.setOct31Nov27(cumBackLogCalcVO
							.getcumbackoct31Nov27());
					demandVo.setPastDue(cumBackLogCalcVO.getcumbackpastDue());

				} else {
					demandVo.setApr11Apr17(demands.getApr11Apr17());
					demandVo.setApr18Apr24(demands.getApr18Apr24());
					demandVo.setApr25May01(demands.getApr25May01());
					demandVo.setAug01Aug28(demands.getAug01Aug28());
					demandVo.setAug29Oct02(demands.getAug29Oct02());
					demandVo.setFeb29Mar06(demands.getFeb29Mar06());
					demandVo.setJan02Jan29(demands.getJan02Jan29());
					demandVo.setJan30Feb26(demands.getJan30Feb26());
					demandVo.setJul04Jul31(demands.getJul04Jul31());
					demandVo.setMar07Mar13(demands.getMar07Mar13());
					demandVo.setMar14Mar20(demands.getMar14Mar20());
					demandVo.setMar21Mar27(demands.getMar21Mar27());
					demandVo.setMar28Apr03((demands.getMar28Apr03()));
					demandVo.setMay02May08(demands.getMay02May08());
					demandVo.setMay09May15(demands.getMay09May15());
					demandVo.setMay16May22(demands.getMay16May22());
					demandVo.setMay23May29(demands.getMay23May29());
					demandVo.setMay30Jul03(demands.getMay30Jul03());
					demandVo.setNov28Jan01(demands.getNov28Jan01());
					demandVo.setOct03Oct30(demands.getOct03Oct30());
					demandVo.setOct31Nov27(demands.getOct31Nov27());
					demandVo.setApr04Apr10(demands.getApr04Apr10());
				}

				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());
				demandVo.setPastDue(demands.getPastDue());
				// demandDateVoList.add(dateVO);
				// quantityTypeVO.setDemandDateVos(demandDateVoList);
				// quantityVoList.add(quantityTypeVO);
				// demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
			}
			// ExcelUtil excelUtil = new ExcelUtil();
			ExcelUtil.writeDataToExcel(demandVos, response);
			/*
			 * entity = ResponseEntity .ok()
			 * .contentLength(pdfFile.contentLength()) .contentType(
			 * MediaType.parseMediaType("application/octet-stream")) .body(new
			 * InputStreamResource(pdfFile.getInputStream()));
			 */

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.downloadDemanDetailsinExcelWithoutFilter()"
							+ e);
		}
		// return entity;

	}

	@RequestMapping(value = "/view/updateDemandDetails", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody void updateDemandDetails(
			@RequestBody @Valid final GetsDemand demand) {
		GetsDemand checkDemand = null;
		try {
			checkDemand = demandUpdateRepository.findOne(demand
					.getDispositionId());

			if (null != checkDemand) {
				checkDemand.setApr04Apr10(demand.getApr04Apr10());
				checkDemand.setApr11Apr17(demand.getApr11Apr17());
				checkDemand.setApr18Apr24(demand.getApr18Apr24());
				checkDemand.setApr25May01(demand.getApr25May01());
				checkDemand.setAug01Aug28(demand.getAug01Aug28());
				checkDemand.setAug29Oct02(demand.getAug29Oct02());
				checkDemand.setFeb29Mar06(demand.getFeb29Mar06());
				checkDemand.setJan02Jan29(demand.getJan02Jan29());
				checkDemand.setJan30Feb26(demand.getJan30Feb26());
				checkDemand.setJul04Jul31(demand.getJul04Jul31());
				checkDemand.setMar07Mar13(demand.getMar07Mar13());
				checkDemand.setMar14Mar20(demand.getMar14Mar20());
				checkDemand.setMar21Mar27(demand.getMar21Mar27());
				checkDemand.setMar28Apr03(demand.getMar28Apr03());
				checkDemand.setMay02May08(demand.getMay02May08());
				checkDemand.setMay09May15(demand.getMay09May15());
				checkDemand.setMay16May22(demand.getMay16May22());
				checkDemand.setMay23May29(demand.getMay23May29());
				checkDemand.setMay30Jul03(demand.getMay30Jul03());
				checkDemand.setNov28Jan01(demand.getNov28Jan01());
				checkDemand.setOct03Oct30(demand.getOct03Oct30());
				checkDemand.setOct31Nov27(demand.getOct31Nov27());

				demandUpdateRepository.save(checkDemand);

			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandDetailsWithOutFilter()"
							+ e);
		}

	}

	@RequestMapping("/view/getDemandAllDetailsWithOutFilterRole/{userName}")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithOutFilter(
			@PathVariable("userName") String userName) {
		List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		DemandsDetailsVO demandVo = null;
		List<GetsDemand> demandList = null;
		String rollName = null;

		try {
			if (null != userName) {

				demandList = demandRepo.findByUserName(userName, new Sort(
						Sort.Direction.ASC, "dispositionId"));

				if (demandList.size() > 0) {
					rollName = demandList.get(0).getRollName();
					if (rollName.equalsIgnoreCase("Buyer")) {
						demandList.clear();
						demandList = demandRepo.findAll(new Sort(
								Sort.Direction.ASC, "dispositionId"));

					}

				}

				for (GetsDemand demands : demandList) {
					demandVo = new DemandsDetailsVO();

					if (demands.getSentFlag().equalsIgnoreCase("false")) {
						demandVo.setItemNumber("");
						demandVo.setItemDescription("");
						demandVo.setSupplierName("");
						demandVo.setInventoryOrganization("");
					} else {

						demandVo.setItemNumber(demands.getItemNumber());
						demandVo.setItemDescription(demands
								.getItemDescription());
						demandVo.setSupplierName(demands.getSupplierName());
						demandVo.setInventoryOrganization(demands
								.getInventoryOrganization());
					}

					demandVo.setDispositionId(demands.getDispositionId());

					// setting the date type
					demandVo.setQuantityType(demands.getProductCode());
					demandVo.setApr04Apr10(demands.getApr04Apr10());
					demandVo.setApr11Apr17(demands.getApr11Apr17());
					demandVo.setApr18Apr24(demands.getApr18Apr24());
					demandVo.setApr25May01(demands.getApr25May01());
					demandVo.setAug01Aug28(demands.getAug01Aug28());
					demandVo.setAug29Oct02(demands.getAug29Oct02());
					demandVo.setFeb29Mar06(demands.getFeb29Mar06());
					demandVo.setJan02Jan29(demands.getJan02Jan29());
					demandVo.setJan30Feb26(demands.getJan30Feb26());
					demandVo.setJul04Jul31(demands.getJul04Jul31());
					demandVo.setMar07Mar13(demands.getMar07Mar13());
					demandVo.setMar14Mar20(demands.getMar14Mar20());
					demandVo.setMar21Mar27(demands.getMar21Mar27());
					demandVo.setMar28Apr03(demands.getMar28Apr03());
					demandVo.setMay02May08(demands.getMay02May08());
					demandVo.setMay09May15(demands.getMay09May15());
					demandVo.setMay16May22(demands.getMay16May22());
					demandVo.setMay23May29(demands.getMay23May29());
					demandVo.setMay30Jul03(demands.getMay30Jul03());
					demandVo.setNov28Jan01(demands.getNov28Jan01());
					demandVo.setOct03Oct30(demands.getOct03Oct30());
					demandVo.setOct31Nov27(demands.getOct31Nov27());

					demandVo.setDemandId(demands.getDemandId());
					demandVo.setSentFlag(demands.getSentFlag());
					demandVo.setEditFlag(demands.getEditFlag());
					demandVo.setPastDue(demands.getPastDue());

					// demandDateVoList.add(dateVO);
					// quantityTypeVO.setDemandDateVos(demandDateVoList);
					// quantityVoList.add(quantityTypeVO);
					// demandVo.setQuantityVos(quantityVoList);
					demandVos.add(demandVo);

				}
			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandDetailsWithOutFilter()"
							+ e);
		}
		return demandVos;

	}

	@RequestMapping(value = "/view/getDemandAllDetailsWithFilterRole", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithFilterRole(
			@RequestBody @Valid final GetsDemand demand) {

		List<GetsDemand> demandList = null;
		List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		DemandsDetailsVO demandVo = null;
		String rollName = null;

		try {

			if (null != demand.getUserName()) {

				demandList = demandRepo.findByUserName(demand.getUserName(),
						new Sort(Sort.Direction.ASC, "dispositionId"));

				if (demandList.size() > 0) {
					rollName = demandList.get(0).getRollName();
					if (rollName.equalsIgnoreCase("Buyer")) {
						demandList.clear();
						// demandList = demandRepo.findAll(new
						// Sort(Sort.Direction.ASC, "dispositionId"));
						DemandSearchSpecification demandSearchSpecification = new DemandSearchSpecification(
								demand);
						demandList = demandSearchRepo
								.findAll(demandSearchSpecification);

					} else {
						DemandSearchSupplierSpecification demandSearchSpecification = new DemandSearchSupplierSpecification(
								demand);
						demandList = demandSearchRepo
								.findAll(demandSearchSpecification);
					}

				}

				for (GetsDemand demands : demandList) {
					demandVo = new DemandsDetailsVO();

					if (demands.getSentFlag().equalsIgnoreCase("false")) {
						demandVo.setItemNumber("");
						demandVo.setItemDescription("");
						demandVo.setSupplierName("");
						demandVo.setInventoryOrganization("");
					} else {

						demandVo.setItemNumber(demands.getItemNumber());
						demandVo.setItemDescription(demands
								.getItemDescription());
						demandVo.setSupplierName(demands.getSupplierName());
						demandVo.setInventoryOrganization(demands
								.getInventoryOrganization());
					}

					demandVo.setDispositionId(demands.getDispositionId());

					// setting the date type
					demandVo.setQuantityType(demands.getProductCode());
					demandVo.setApr04Apr10(demands.getApr04Apr10());
					demandVo.setApr11Apr17(demands.getApr11Apr17());
					demandVo.setApr18Apr24(demands.getApr18Apr24());
					demandVo.setApr25May01(demands.getApr25May01());
					demandVo.setAug01Aug28(demands.getAug01Aug28());
					demandVo.setAug29Oct02(demands.getAug29Oct02());
					demandVo.setFeb29Mar06(demands.getFeb29Mar06());
					demandVo.setJan02Jan29(demands.getJan02Jan29());
					demandVo.setJan30Feb26(demands.getJan30Feb26());
					demandVo.setJul04Jul31(demands.getJul04Jul31());
					demandVo.setMar07Mar13(demands.getMar07Mar13());
					demandVo.setMar14Mar20(demands.getMar14Mar20());
					demandVo.setMar21Mar27(demands.getMar21Mar27());
					demandVo.setMar28Apr03(demands.getMar28Apr03());
					demandVo.setMay02May08(demands.getMay02May08());
					demandVo.setMay09May15(demands.getMay09May15());
					demandVo.setMay16May22(demands.getMay16May22());
					demandVo.setMay23May29(demands.getMay23May29());
					demandVo.setMay30Jul03(demands.getMay30Jul03());
					demandVo.setNov28Jan01(demands.getNov28Jan01());
					demandVo.setOct03Oct30(demands.getOct03Oct30());
					demandVo.setOct31Nov27(demands.getOct31Nov27());

					demandVo.setDemandId(demands.getDemandId());
					demandVo.setSentFlag(demands.getSentFlag());
					demandVo.setEditFlag(demands.getEditFlag());

					// demandDateVoList.add(dateVO);
					// quantityTypeVO.setDemandDateVos(demandDateVoList);
					// quantityVoList.add(quantityTypeVO);
					// demandVo.setQuantityVos(quantityVoList);
					demandVos.add(demandVo);

				}
			}
		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandAllDetailsWithFilterRole()"
							+ e);
		}
		return demandVos;

	}

	@RequestMapping(value = "/view/downloadExcelSearchWithFilter/{itemNumber}/{buyerName}/{supplierName}/{supplierCode}/{buissnessUnit}", method = RequestMethod.GET)
	public @ResponseBody List<DemandsDetailsVO> downloadExcelSearchWithFilter(
			@PathVariable("itemNumber") String itemNumber,
			@PathVariable("buyerName") String buyerName,
			@PathVariable("supplierName") String supplierName,
			@PathVariable("supplierCode") String supplierCode,
			@PathVariable("buissnessUnit") String buissnessUnit,
			HttpServletResponse response) {

		List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		DemandsDetailsVO demandVo = null;
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new
		// ArrayList<QuantityTypeVO>();
		// List<DemandDateVO> demandDateVoList = new ArrayList<DemandDateVO>();
		try {
			DemandSearchSpecificationFilterExcel demandSearchSpecification = new DemandSearchSpecificationFilterExcel(
					itemNumber, buyerName, supplierName, supplierCode,
					buissnessUnit);
			List<GetsDemand> demandList = demandSearchRepo.findAll(
					demandSearchSpecification, new Sort(Sort.Direction.ASC,
							"dispositionId"));

			for (GetsDemand demands : demandList) {
				demandVo = new DemandsDetailsVO();
				// quantityTypeVO = new QuantityTypeVO();
				// dateVO = new DemandDateVO();

				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands
						.getInventoryOrganization());
				// setting quantity type
				// quantityTypeVO.setQuantityType(demands.getProductCode());

				// setting the date type
				demandVo.setQuantityType(demands.getProductCode());
				demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03(demands.getMar28Apr03());
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());

				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());
				demandVo.setPastDue(demands.getPastDue());

				// demandDateVoList.add(dateVO);
				// quantityTypeVO.setDemandDateVos(demandDateVoList);
				// quantityVoList.add(quantityTypeVO);
				// demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);

			}
			ExcelUtil.writeDataToExcel(demandVos, response);

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getDemandDetailsWithOutFilter()"
							+ e);
		}
		return demandVos;

	}

	@RequestMapping(value = "/view/postOnlyXml", method = RequestMethod.POST, consumes = "application/xml", produces = "application/xml")
	public @ResponseBody CommonBaseEvents postOnlyXML(
			@RequestBody CommonBaseEvents track) {

		System.out.println("BookingController.postOnlyXML()");
		String result = "Track saved : " + track;
		System.out.println("BookingController.postOnlyXML()" + result);
		// String gener = track.getSinger();

		// System.out.println("BookingController.postOnlyXML()" + gener );

		// Response.status(201).entity(track).build();

		return track;
	}

	@RequestMapping(value = "/view/postOnlyXmls", method = RequestMethod.POST, consumes = "application/xml", produces = "application/xml")
	public @ResponseBody CommonBaseEventType postOnlyXMLs(
			@RequestBody CommonBaseEventType track) {

		BigDecimal reslut = track.getNs2InformationModelInstance()
				.getNs2FunctionBlockInstances().getNs2FunctionBlockInstance()
				.getNs2Properties().getNutrunner().getStatus()
				.getLastMaintenanceTS();
		// BigDecimal result= track.getStatus().getCurrentTorque();

		System.out.println("CommonBaseEvent.postOnlyXML()" + reslut);
		// String result = "Track saved : " + track;
		// System.out.println("BookingController.postOnlyXML()" + result);
		// Response.status(201).entity(track).build();

		return track;
	}

	@RequestMapping(value = "/view/postXml", method = RequestMethod.POST, consumes = "application/xml", produces = "application/xml")
	public @ResponseBody Track postXML(@RequestBody Track track) {

		System.out.println("BookingController.postOnlyXML()");
		String result = "Track saved : " + track;
		System.out.println("BookingController.postOnlyXML()" + result);
		// String gener = track.getSinger();

		// System.out.println("BookingController.postOnlyXML()" + gener );

		// Response.status(201).entity(track).build();

		return track;
	}

	@RequestMapping(value = "/view/postXMLs", method = RequestMethod.POST, consumes = "text/plain")
	public @ResponseBody String postXMLs(@RequestBody String result) {

		String results = result;
		System.out.println("BookingController.postXMLs()" + result);
		return results;

	}

	@RequestMapping("/view/getMachineDataByDeviceId/{deviceId}")
	public @ResponseBody List<Map<Object, Object>> getMachineDataByDeviceId(
			@PathVariable("deviceId") Long deviceId) {
		/*
		 * List<MachineDataVO> machineDatavo = new ArrayList<MachineDataVO>();
		 * MachineDataVO dataVO = null;
		 */

		List<Object> retListData = new ArrayList<Object>();
		Map<Object, Object> objMap = null;
		List<Map<Object, Object>> list = new ArrayList<Map<Object, Object>>();
		try {
			System.out
					.println("HospitalAlarmService.getMachineDataByDeviceId()***********");
			List<Object[]> retList = machineDataRepo
					.getMachineDataByDeviceId(deviceId);

			System.out.println("listData!!!!!!!!!!" + retList);
			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<Object, Object>();
				objMap.put("processId", (retList.get(i))[1]);
				String str = (String) retList.get(i)[0];
				str = str.replaceAll("\\n", "");
				str = str.replaceAll("\\s+", "");
				str = str.replaceAll("\\t", "");
				str = str.replaceAll("\\\\", "");

				JSONParser parser = new JSONParser();

				JSONObject a = (JSONObject) parser.parse(str);
				// for(int i = 0; i < a.size(); i++){
				/*
				 * Set<String> keys = a.keySet(); for(String ks :keys){
				 * System.out.println("Keys : " + ks); // String jsonObj =
				 * (String)a.get(ks); //
				 * System.out.println("ParseJM2MData.readJson()" + jsonObj);
				 * 
				 * if(a.get(ks) instanceof Long){ Long value = (Long)a.get(ks);
				 * System.out.println("ParseJM2MData.readJson()" + value);
				 * 
				 * }else if (a.get(ks) instanceof String){
				 * 
				 * }else if (a.get(ks) instanceof JSONArray){
				 * 
				 * }
				 * 
				 * }
				 */

				Long id = (Long) a.get("_id");
				Long nutrunnerId = (Long) a.get("nutrunnerId");
				Long assetId = (Long) a.get("assetId");
				String timestamp = (String) a.get("timestamp");
				String result = (String) a.get("result");
				String prgdate = (String) a.get("prgdate");
				Long nr = (Long) a.get("nr");
				String date = (String) a.get("date");
				Long prgnr = (Long) a.get("prgnr");
				String prgname = (String) a.get("prgname");
				String idcode = (String) a.get("idcode");
				String toolserial = (String) a.get("toolserial");
				Long cycle = (Long) a.get("cycle");
				Double MCEfactor = (Double) a.get("MCEfactor");
				String celLid = (String) a.get("cellid");
				Long nominaltorque = (Long) a.get("nominaltorque");
				String torqueunit = (String) a.get("torqueunit");
				String channel = (String) a.get("channel");
				Double totaltime = (Double) a.get("total time");
				JSONArray tighteningsteps = (JSONArray) a
						.get("tighteningsteps");
				// System.out.println("ParseJM2MData.readJson()" +
				// tighteningsteps);
				for (int j = 0; j < tighteningsteps.size(); j++) {
					// System.out.println("ParseJM2MData.readJson()" +
					// tighteningsteps.get(j));
					JSONObject eachRow = (JSONObject) tighteningsteps.get(j);
					String resultTight = (String) eachRow.get("result");
					String lastcmd = (String) eachRow.get("lastcmd");
					Long speed = (Long) eachRow.get("speed");
					Double torque = (Double) eachRow.get("torque");
					Long anglethresholdnom = (Long) eachRow
							.get("anglethresholdnom");
					Double angle = (Double) eachRow.get("angle");
					Long row = (Long) eachRow.get("row");
					Double duration = (Double) eachRow.get("duration");
					Long category = (Long) eachRow.get("category");
					JSONObject jsonObj = (JSONObject) eachRow.get("graph");
					JSONArray torquevalues = (JSONArray) jsonObj
							.get("torquevalues");
					JSONArray timevalues = (JSONArray) jsonObj
							.get("timevalues");
					JSONArray anglevalues = (JSONArray) jsonObj
							.get("anglevalues");

					objMap.put("torquevalues", torquevalues.toString());
					objMap.put("timevalues", timevalues.toString());
					objMap.put("anglevalues", anglevalues.toString());

					JSONArray tighteningFunc = (JSONArray) eachRow
							.get("tighteningfunctions");

					for (int k = 0; k < tighteningFunc.size(); k++) {
						JSONObject eachRowtighteningFunc = (JSONObject) tighteningFunc
								.get(k);
						String name = (String) eachRowtighteningFunc
								.get("name");
						Double act = (Double) eachRowtighteningFunc.get("act");
						Long nom = (Long) eachRowtighteningFunc.get("nom");

						System.out.println("ParseJM2MData.jsonObj()" + name
								+ ":" + act + ":" + nom);
					}

					System.out.println("ParseJM2MData.readJson()"
							+ eachRow.get("result"));

				}

				retListData.add(str);
				System.out.println("String is data: " + retListData);
				/*
				 * ObjectMapper objectMapper=new ObjectMapper(); String
				 * jsonData=objectMapper.writeValueAsString(str);
				 * 
				 * System.out .println("jsonData data: " + jsonData);
				 */

				list.add(objMap);

			}

		} catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getMachineDataByDeviceId()"
							+ e);
		}
		return list;

	}

	@RequestMapping(value = "/view/postJsonValue", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody String postJsonValue(@RequestBody String jsonValue)
			throws ParseException {
		System.out
				.println("MachineConnectService.getDemandAllDetailsWithFilter()"
						+ jsonValue);

		JSONParser parser = new JSONParser();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");
		SimpleDateFormat formatter1 = new SimpleDateFormat(
				"yyyy-MM-dd:HH:mm:ss");

		SimpleDateFormat formatter2 = new SimpleDateFormat(
				"yyyy-MM-dd:HH:mm:ss");
		List<M2mResult> tighenIds = new ArrayList<M2mResult>();

		try {
			JSONObject a = (JSONObject) parser.parse(jsonValue);
			String angleStatus = (String) a.get("angleStatus");
			Long tighteningId = (Long) a.get("tighteningId");
			if(null!=tighteningId){
				Integer tightIds = getRandomNumberInRange(1000,2000);
				tighteningId = tightIds.longValue();
			}
			String idCode = (String) a.get("idCode");
			Long maxAngle = (Long) a.get("maxAngle");
			Long maxTorque = (Long) a.get("maxTorque");
			Long minTorque = (Long) a.get("minTorque");
			Long torque = (Long) a.get("minTorque");

			Long minAngle = (Long) a.get("minAngle");
			Long cellId = (Long) a.get("cellId");
			Long targetTorque = (Long) a.get("targetTorque");

			String timeLastProgramChange = (String) a
					.get("timeLastProgramChange");
			Long okCounterLimit = (Long) a.get("okCounterLimit");
			String tighteningStatus = (String) a.get("tighteningStatus");
			Long targetAngle = (Long) a.get("targetAngle");
			String controllerName = (String) a.get("controllerName");

			Long okCounter = (Long) a.get("okCounter");
			Long angle = (Long) a.get("angle");
			Long tighteningProgramNumber = (Long) a
					.get("tighteningProgramNumber");
			String ok_Nokstatus = (String) a.get("ok_Nokstatus");
			
			if(tighteningId>1500){
				ok_Nokstatus="NOK";
			}
			Long channelId = (Long) a.get("channelId");
			Long jobNumber = (Long) a.get("jobNumber");

			String timestamp = (String) a.get("timestamp");
			String torqueStatus = (String) a.get("torqueStatus");
			if(tighteningId>1500){
				torqueStatus="NOK";
			}
			Date date = formatter.parse(timeLastProgramChange);
			String d = formatter.format(date);
			Date dateTime = formatter.parse(timestamp);
			String aa = formatter1.format(dateTime);

			String results1 = replaceCharAt(d, 10, 'c');
			results1 = results1.replaceAll("c", " ");
			String results2 = replaceCharAt(aa, 10, 'c');
			results2 = results2.replaceAll("c", " ");
			/*
			 * Date d1 = formatter2.parse(d); String d2 = formatter2.format(d1);
			 * 
			 * Date a1= formatter2.parse(aa); String a2= formatter2.format(a1);
			 */
			BigDecimal tightIdsfromJson = BigDecimal.valueOf(tighteningId);
			M2mResult result = new M2mResult();
			result.setAnglestatus(angleStatus);
			result.setAngle(BigDecimal.valueOf(angle));
			result.setChannelid(BigDecimal.valueOf(channelId));
			result.setCellid(BigDecimal.valueOf(cellId));
			result.setControllername(controllerName);
			result.setIdcode(idCode);
			result.setJobbigint(BigDecimal.valueOf(jobNumber));
			result.setMaxangle(BigDecimal.valueOf(maxAngle));
			result.setMaxtorque(BigDecimal.valueOf(maxTorque));
			result.setMinangle(BigDecimal.valueOf(minAngle));
			result.setMintorque(BigDecimal.valueOf(minTorque));
			result.setOkcounter(BigDecimal.valueOf(okCounter));
			result.setOkcounterlimit(BigDecimal.valueOf(okCounterLimit));
			result.setTargetangle(BigDecimal.valueOf(targetAngle));

			result.setTargettorque(BigDecimal.valueOf(targetTorque));
			result.setTighteingid(BigDecimal.valueOf(tighteningId));

			result.setTighteningprogrambigint(BigDecimal
					.valueOf(tighteningProgramNumber));
			result.setTighteningstatus(tighteningStatus);
			result.setTimelastprogramchange(Timestamp.valueOf(results1));
			result.setTimestamp(Timestamp.valueOf(results2));
			result.setTorque(BigDecimal.valueOf(torque));
			result.setTorquestatus(torqueStatus);

			Integer deviceIds = getRandomNumberInRange(12,13);
			M2mDevice device = new M2mDevice();
			device.setId(deviceIds.longValue());
			result.setM2mDevice(device);

			System.out.println("HospitalAlarmService.postJsonValue() new DeviceIds :" + deviceIds.longValue());
			M2mDevice deviceId = machineDeviceRepo.findOne(device.getId());

		
			if (null != deviceId) {
				tighenIds = deviceId.getM2mResults();
				if (null != tighenIds) {
					for (int i = 0; i <= tighenIds.size(); i++) {
						if (tighenIds.size() == 0) {
							machineResultRepo.save(result);
						} else {

							M2mResult resultId = machineResultRepo
									.findOne(tighenIds.get(i).getResultid());
							if (null != resultId) {
								BigDecimal tighId = resultId.getTighteingid();
								System.out.println("Tightening Ids is : "
										+ tighId);
								/*
								 * if(tighId.equals(tightIdsfromJson)) {
								 */
								resultId.setAnglestatus(angleStatus);
								resultId.setAngle(BigDecimal.valueOf(angle));
								resultId.setChannelid(BigDecimal
										.valueOf(channelId));
								resultId.setCellid(BigDecimal.valueOf(cellId));
								resultId.setControllername(controllerName);
								resultId.setIdcode(idCode);
								resultId.setJobbigint(BigDecimal
										.valueOf(jobNumber));
								resultId.setMaxangle(BigDecimal
										.valueOf(maxAngle));
								resultId.setMaxtorque(BigDecimal
										.valueOf(maxTorque));
								resultId.setMinangle(BigDecimal
										.valueOf(minAngle));
								resultId.setMintorque(BigDecimal
										.valueOf(minTorque));
								resultId.setOkcounter(BigDecimal
										.valueOf(okCounter));
								resultId.setOkcounterlimit(BigDecimal
										.valueOf(okCounterLimit));
								resultId.setTargetangle(BigDecimal
										.valueOf(targetAngle));

								resultId.setTargettorque(BigDecimal
										.valueOf(targetTorque));
								resultId.setTighteingid(BigDecimal
										.valueOf(tighteningId));

								resultId.setTighteningprogrambigint(BigDecimal
										.valueOf(tighteningProgramNumber));
								resultId.setTighteningstatus(tighteningStatus);
								resultId.setTimelastprogramchange(Timestamp
										.valueOf(results1));
								resultId.setTimestamp(Timestamp
										.valueOf(results2));
								resultId.setTorque(BigDecimal.valueOf(torque));
								resultId.setTorquestatus(torqueStatus);
								resultId.setM2mDevice(device);

								machineResultRepo.save(resultId);
								break;
								/* } *//*
										 * else{
										 * resultId.setAnglestatus(angleStatus);
										 * resultId
										 * .setAngle(BigDecimal.valueOf(angle));
										 * resultId
										 * .setChannelid(BigDecimal.valueOf
										 * (channelId));
										 * resultId.setCellid(BigDecimal
										 * .valueOf(cellId));
										 * resultId.setControllername
										 * (controllerName);
										 * resultId.setIdcode(idCode);
										 * resultId.setJobbigint
										 * (BigDecimal.valueOf(jobNumber));
										 * resultId
										 * .setMaxangle(BigDecimal.valueOf
										 * (maxAngle));
										 * resultId.setMaxtorque(BigDecimal
										 * .valueOf(maxTorque));
										 * resultId.setMinangle
										 * (BigDecimal.valueOf(minAngle));
										 * resultId
										 * .setMintorque(BigDecimal.valueOf
										 * (minTorque));
										 * resultId.setOkcounter(BigDecimal
										 * .valueOf(okCounter));
										 * resultId.setOkcounterlimit
										 * (BigDecimal.valueOf(okCounterLimit));
										 * resultId
										 * .setTargetangle(BigDecimal.valueOf
										 * (targetAngle));
										 * 
										 * resultId.setTargettorque(BigDecimal.
										 * valueOf(targetTorque));
										 * resultId.setTighteingid
										 * (BigDecimal.valueOf(tighteningId));
										 * 
										 * 
										 * resultId.setTighteningprogrambigint(
										 * BigDecimal
										 * .valueOf(tighteningProgramNumber));
										 * resultId
										 * .setTighteningstatus(tighteningStatus
										 * ); resultId.setTimelastprogramchange(
										 * Timestamp.valueOf(results1));
										 * resultId
										 * .setTimestamp(Timestamp.valueOf
										 * (results2));
										 * resultId.setTorque(BigDecimal
										 * .valueOf(torque));
										 * resultId.setTorquestatus
										 * (torqueStatus);
										 * resultId.setM2mDevice(device);
										 * 
										 * machineResultRepo.save(resultId); }
										 */

							}

						}

						System.out.println("value of if i is " + i);

					}

				}

			}

			/*
			 * List<M2mResult> devices =
			 * machineResultRepo.findByM2mDevice(device); if(null!=devices &&
			 * devices.size()>0){ machineResultRepo.save(result); }
			 */

		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return jsonValue;

	}

	
	
	public  Integer getRandomNumberInRange(Integer min, Integer max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}

	public String replaceCharAt(String s, int pos, char c) {
		return s.substring(0, pos) + c + s.substring(pos + 1);
	}

	@RequestMapping(value = "/view/upload", method = RequestMethod.POST)
	public @ResponseBody String handleFileUpload(
			@RequestParam("name") String name,
			@RequestParam("file") MultipartFile file) {
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				String fileName = file.getOriginalFilename();
				System.out.println("BookingController.handleFileUpload()"
						+ fileName);
				String fileLocation = new File("static\\pdf").getAbsolutePath()
						+ "\\" + fileName;
				// FileOutputStream fos = new FileOutputStream(fileLocation);
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(fileLocation));
				stream.write(bytes);
				stream.close();
				return "You successfully uploaded " + name + "!";
			} catch (Exception e) {
				return "You failed to upload " + name + " => " + e.getMessage();
			}
		} else {
			return "You failed to upload " + name
					+ " because the file was empty.";
		}
	}

	@RequestMapping(value = "/view/download/pdf/{fileName}", method = RequestMethod.GET)
	public @ResponseBody void downloadPdfFile(
			@PathVariable("fileName") String fileName,
			HttpServletResponse response) throws URISyntaxException,
			IOException {
		// URL url = this.getClass().getResource("src/main/resources/pdf.pdf");
		// File file = new
		// File(ClassLoader.getSystemResource("src/main/resources/pdf.pdf").getFile());

		ClassLoader classLoader = getClass().getClassLoader();
		// File file = new
		// File(classLoader.getResource("src/main/resources/pdf.pdf").getFile());

		/*
		 * InputStream inputStream =
		 * getClass().getClassLoader().getResourceAsStream("pdf.pdf"); File file
		 * = new File(inputStream);
		 */
		String fileNames = "classpath:" + fileName + ".pdf";
		System.out.println("BookingController.downloadPdfFile()" + fileNames);
		Resource resource = resourceLoader.getResource(fileNames);

		File file = resource.getFile();

		System.out.println("PdfUploadDownloadService.downloadPdfFile()");
		try (InputStream fileInputStream = new FileInputStream(file);
				OutputStream output = response.getOutputStream();) {

			response.reset();

			response.setContentType("application/octet-stream");
			response.setContentLength((int) (file.length()));

			response.setHeader("Content-Disposition", "attachment; filename=\""
					+ file.getName() + "\"");

			IOUtils.copyLarge(fileInputStream, output);
			output.flush();
		} catch (IOException e) {
			System.out
					.println("PdfUploadDownloadService.downloadPdfFile()" + e);
		}

	}

	@RequestMapping(value = "/view/parsePdf", method = RequestMethod.GET)
	public @ResponseBody void parsePdfFile(final HttpServletRequest request,
			final HttpServletResponse response) throws URISyntaxException,
			IOException, java.text.ParseException, DocumentException {
		// URL url = this.getClass().getResource("src/main/resources/pdf.pdf");
		// File file = new
		// File(ClassLoader.getSystemResource("src/main/resources/pdf.pdf").getFile());

		ClassLoader classLoader = getClass().getClassLoader();
		// File file = new
		// File(classLoader.getResource("src/main/resources/pdf.pdf").getFile());

		/*
		 * InputStream inputStream =
		 * getClass().getClassLoader().getResourceAsStream("pdf.pdf"); File file
		 * = new File(inputStream);
		 * 
		 * Resource resource =
		 * resourceLoader.getResource("classpath:sample.pdf");
		 * 
		 * File file1 = resource.getFile();
		 */

		File file1 = new File("D:/GEGDC/SM358224/sample.pdf");

		PdfParserDTO parserDTO = new PdfParserDTO();
		SimpleDateFormat strDate = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");

		System.out.println("PdfUploadDownloadService.downloadPdfFile()");
		try {
			PdfReader reader = new PdfReader(file1.getPath());
			StringBuffer header = inspectPdf(reader);
			parserDTO.setHeader(header.toString());

			System.out.println("This PDF has " + reader.getNumberOfPages()
					+ " pages.");
			System.out.println("This PDF size " + reader.getFileLength() + "kb"
					+ parserDTO.getHeader().length());

			parserDTO.setFileSize(new BigDecimal(reader.getFileLength()));
			parserDTO.setPages(new BigDecimal(reader.getNumberOfPages()));
			HashMap hMap = new HashMap();
			hMap = reader.getInfo();
			Iterator iterator = hMap.keySet().iterator();
			while (iterator.hasNext()) {
				String key = (String) iterator.next();
				parserDTO.setAuthor((String) hMap.get("Author"));
				parserDTO.setTitle((String) hMap.get("Title"));
				String modDate = (String) hMap.get("ModDate");
				modDate = modDate.substring(2, 10);
				Date modDateFor = strDate.parse(modDate);
				formatter.format(modDateFor);
				parserDTO.setModifiedDate(modDateFor);

				String createDate = (String) hMap.get("CreationDate");
				createDate = createDate.substring(2, 10);
				Date createDateFor = strDate.parse(modDate);
				formatter.format(createDateFor);
				parserDTO.setCreationDate(createDateFor);

			}

			PdfDictionary root = reader.getCatalog();
			// root.size();
			System.out.println("PDF Root size " + reader.getNumberOfPages());
			for (int i = 1; i <= reader.getNumberOfPages(); i++) {

				if (i == 1) {
					String firstPage = PdfTextExtractor.getTextFromPage(reader,
							1);
					firstPage = firstPage.replace("\n", " ");
					String operator = firstPage.substring(29, 44);
					String revesion = firstPage.substring(239, 241);
					parserDTO.setPurposeType(operator);
					parserDTO.setRevision(revesion);

					System.out.println("iTextReadDemo.main()" + firstPage);
				}
				if (i == 3) {
					String thrdPage = PdfTextExtractor.getTextFromPage(reader,
							3);
					thrdPage = thrdPage.replace("\n", " ");
					String modality = thrdPage.substring(133, 136);
					parserDTO.setModality(modality);

					System.out.println("iTextReadDemo.main(222)" + modality);
				}
				// String page = PdfTextExtractor.getTextFromPage(reader,i);
			}

			// System.out.println("Page Content:\n\n"+page+"\n\n");
			// Scanner scanner =new Scanner(System.in);
			System.out.println("enter path of your pdf file");
			// String fileName=scanner.nextLine();
			/*
			 * BodyContentHandler handler = new BodyContentHandler(); Metadata
			 * metadata = new Metadata(); FileInputStream inputstream = new
			 * FileInputStream(new
			 * File("D:/GEGDC/AS345085/Predix2.0/TOGAF_9_1_Quickstart_(V0_9).pdf"
			 * )); ParseContext pcontext = new ParseContext();
			 * 
			 * //parsing the document using PDF parser PDFParser pdfparser = new
			 * PDFParser(); pdfparser.parse(inputstream, handler,
			 * metadata,pcontext);
			 * 
			 * //getting the content of the document
			 * System.out.println("Contents of the PDF :" + handler.toString());
			 * 
			 * //getting metadata of the document
			 * System.out.println("Metadata of the PDF:"); String[]
			 * metadataNames = metadata.names();
			 * 
			 * for(String name : metadataNames) { System.out.println(name+ " : "
			 * + metadata.get(name)); }
			 */

			// System.out.println("Is this document tampered: "+reader.isTampered());
			// System.out.println("Is this document encrypted: "+reader.isEncrypted());

			PDDocument document = null;
			document = PDDocument.load(file1.getPath());
			File file = new File(file1.getPath());
			List pages = document.getDocumentCatalog().getAllPages();
			Iterator iter = pages.iterator();
			int i = 0;
			System.out.println("iTextReadDemo.main()" + file.getName());
			parserDTO.setFileName(file.getName());

			/*
			 * FileOutputStream out =null; while (iter.hasNext()) { PDPage page
			 * = (PDPage) iter.next(); PDResources resources =
			 * page.getResources(); Map pageImages = resources.getImages(); if
			 * (pageImages != null) { Iterator imageIter =
			 * pageImages.keySet().iterator(); while (imageIter.hasNext()) {
			 * i++; out = new FileOutputStream(new
			 * File(file.getParentFile()+"/images", String.format("%1$05d", i) +
			 * ".jpg")); String key = (String) imageIter.next(); PDXObjectImage
			 * image = (PDXObjectImage) pageImages.get(key);
			 * image.write2OutputStream(out); } } }
			 */

			PdfParser pdfParser = new PdfParser();
			pdfParser.setAuthor(parserDTO.getAuthor());
			pdfParser.setTitle(parserDTO.getTitle());
			pdfParser.setFileSize(parserDTO.getFileSize());
			pdfParser.setModifiedDate(parserDTO.getModifiedDate());
			pdfParser.setCreationDate(parserDTO.getCreationDate());
			pdfParser.setPurposeType(parserDTO.getPurposeType());
			pdfParser.setRevision(parserDTO.getRevision());
			pdfParser.setModality(parserDTO.getModality());
			pdfParser.setPages(parserDTO.getPages());
			pdfParser.setFileName(parserDTO.getFileName());
			pdfParser.setHeader(parserDTO.getHeader());

			pdfParserRespo.save(pdfParser);

		} catch (IOException e) {
			System.out
					.println("PdfUploadDownloadService.downloadPdfFile()" + e);
		}

	}

	public StringBuffer inspectPdf(PdfReader reader) throws IOException,
			DocumentException {
		// File file1 = new File("D:\\GEGDC\\SM358224\\sample.pdf");

		// PdfReader reader = new PdfReader(file1.getPath());
		StringBuffer header = new StringBuffer();
		List<HashMap<String, Object>> bookmarks = SimpleBookmark
				.getBookmark(reader);
		for (int i = 0; i < bookmarks.size(); i++) {
			header = showTitle(bookmarks.get(i), header);
		}
		reader.close();
		return header;
	}

	public StringBuffer showTitle(HashMap<String, Object> bm,
			StringBuffer header) {
		// System.out.println((String)bm.get("Title"));
		String title = (String) bm.get("Title");
		// StringBuffer header = new StringBuffer();
		header.append(title + "\n");
		// String header = header.toString();
		// System.out.println(buffer.toString());
		List<HashMap<String, Object>> kids = (List<HashMap<String, Object>>) bm
				.get("Kids");
		/*
		 * if (kids != null) { for (int i = 0; i < kids.size(); i++) {
		 * showTitle(kids.get(i),header); } }
		 */
		return header;
	}

	@RequestMapping(value = "/view/getPdfParserDetailsWithFilter", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<PdfParserDTO> getPdfParserDetailsWithFilter(
			@RequestBody @Valid final PdfParser parse) {

		List<PdfParserDTO> pdfVos = new ArrayList<PdfParserDTO>();
		PdfParserDTO parseVo = null;
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new
		// ArrayList<QuantityTypeVO>();
		// List<DemandDateVO> demandDateVoList = new ArrayList<DemandDateVO>();
		try {
			PdfParseSearchSpecification searchSpecification = new PdfParseSearchSpecification(
					parse);
			List<PdfParser> pdfList = pdfParserRespo
					.findAll(searchSpecification);

			for (PdfParser pdfparse : pdfList) {
				parseVo = new PdfParserDTO();
				parseVo.setFileName(pdfparse.getFileName());
				parseVo.setAuthor(pdfparse.getAuthor());
				parseVo.setCreationDate(pdfparse.getCreationDate());
				parseVo.setFilePath(pdfparse.getFilePath());
				parseVo.setFileSize(pdfparse.getFileSize());
				parseVo.setFileType(pdfparse.getFileType());
				parseVo.setHeader(pdfparse.getHeader());
				parseVo.setImageName(pdfparse.getImageName());
				parseVo.setImagePath(pdfparse.getImagePath());
				parseVo.setModality(pdfparse.getModality());
				parseVo.setModifiedDate(pdfparse.getModifiedDate());
				parseVo.setPages(pdfparse.getPages());
				parseVo.setPurposeType(pdfparse.getPurposeType());
				parseVo.setRevision(pdfparse.getRevision());
				parseVo.setTitle(pdfparse.getTitle());

				pdfVos.add(parseVo);

			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getPdfParserDetailsWithFilter()"
							+ e);
		}
		return pdfVos;

	}

	@RequestMapping("/view/scheduleUpdate")
	public String scheduleUpdate() {
		System.out.println("ShopVisitServiceImpl.scheduleUpdate()");
		final String result = "Hello Thread";
		try {
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {

				public void run() {
					/*
					 * final SchedulerVO schedulerVO = new SchedulerVO();
					 * schedulerVO.setStatus("Scheduler Staretd.....");
					 */
					System.out.println(result);
					List<CwcOrderVO> events = new ArrayList<CwcOrderVO>();
					List<CwcSearchportionPoc> entities = cwcOrderSearchService
							.findAll();
					for (CwcSearchportionPoc ent : entities) {
						long id = ent.getCwcOrder();
						// List<CwcSearchportionPoc> details =
						String status = ent.getStatus();
						if (status.equalsIgnoreCase("BOOKED")) {
							ent.setStatus("SHIPPED");
							cwcOrderSearchService.save(ent);
						} else if (status.equalsIgnoreCase("SHIPPED")) {
							ent.setStatus("RELEASED");
							cwcOrderSearchService.save(ent);
						} else if (status.equalsIgnoreCase("RELEASED")) {
							ent.setStatus("BOOK");
							cwcOrderSearchService.save(ent);
						}
					}

					// schedulerVOs.add(schedulerVO);

				}
			}, 0, 30 * 10000);
			// timer.cancel();
		} catch (Exception e) {
			System.out.println(e);
		}
		return result;
	}

	@SuppressWarnings("nls")
	@RequestMapping(value = "/view/findParkingAreasByLongitudeAndLatitude/{latitude}/{longitude}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Map<String, Object>> findParkingAreasByLongitudeAndLatitude(
			@PathVariable("latitude") String latitude,
			@PathVariable("longitude") String longitude) {

		List<ParkingZoneDTO> parkingZoneDtos = new ArrayList<ParkingZoneDTO>();
		ParkingZoneDTO zoneDTO = null;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			Double lati = Double.parseDouble(latitude);
			Double longi = Double.parseDouble(longitude);

			List<Object[]> retList = parkingzoneInfo
					.findParkingAreasByLongitudeAndLatitude(lati, longi);
			System.out
					.println("SmartParkingService.findParkingAreasByLongitudeAndLatitude() size is : "
							+ retList.size());

			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("zoneId", (retList.get(i))[0]);
				objMap.put("areaName", (retList.get(i))[1]);
				objMap.put("latitude", (retList.get(i))[2]);
				objMap.put("longitude", (retList.get(i))[3]);
				list.add(objMap);

			}

			System.out
					.println("SmartParkingService.findParkingAreasByLocation()");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}

	@SuppressWarnings("nls")
	@RequestMapping(value = "/view/findParkingLocationByZoneId/{zoneId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<ParkingLocationDTO> findParkingLocationByZoneId(
			@PathVariable("zoneId") String zoneId) {
		List<ParkingLocationDTO> parkingLocList = new ArrayList<ParkingLocationDTO>();
		ParkingLocationDTO locDto = null;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			Double zoneIds = Double.parseDouble(zoneId);

			ParkingZoneDetail detals = parkingzoneInfo.findOne(zoneIds
					.longValue());

			List<ParkingLocation> locDts = detals.getParkingLocations();

			for (ParkingLocation location : locDts) {
				locDto = new ParkingLocationDTO();
				locDto.setLoclatitude(location.getLatitude());
				locDto.setLocId(location.getLocId());
				locDto.setLocName(location.getLocName());
				locDto.setLoclongitude(location.getLongitude());
				locDto.setType(location.getType());
				locDto.setTotalSlots(location.getTotalSlots());
				parkingLocList.add(locDto);

			}

			System.out
					.println("SmartParkingService.findParkingLocationByZoneId() size is : "
							+ locDts.size() + locDts.get(0).getLocId());

			/*
			 * for(int i = 0; i < retList.size(); i++){ objMap = new
			 * HashMap<String, Object>(); objMap.put("zoneId",
			 * (retList.get(i))[0]); objMap.put("areaName",
			 * (retList.get(i))[1]); objMap.put("latitude",
			 * (retList.get(i))[2]); objMap.put("longitude",
			 * (retList.get(i))[3]); list.add(objMap);
			 * 
			 * }
			 */

			System.out
					.println("SmartParkingService.findParkingAreasByLocation()");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return parkingLocList;

	}

	/*
	 * @RequestMapping(value= "/view/finTseriesDataByLocationId/{locId}" ,
	 * method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 * public @ResponseBody List<ParkingLocationDTO>
	 * finTseriesDataByLocationId(@PathVariable("locId") String locId){
	 * 
	 * }
	 */

	@RequestMapping(value = "/view/getFlightParameters", method = RequestMethod.GET)
	public @ResponseBody List<FlightParametersDTO> getFlightParameters() {
		System.out.println("BookingController.getFlightParameters()");
		List<FlightParametersDTO> flightParametersList = new ArrayList<FlightParametersDTO>();
		FlightParametersDTO flightParametersDTO = null;

		try {
			List<AvioDataNew1> flightDataFromDb = flightDataEntityRepo
					.findByflightId(1);
			// List<AvioDataNew1> flightDataFromDb =
			// flightDataEntityRepo.findAll();
			for (AvioDataNew1 flightDataEntity : flightDataFromDb) {
				flightParametersDTO = new FlightParametersDTO();
				flightParametersDTO.setE07(flightDataEntity.getE07());
				flightParametersDTO.setE08(flightDataEntity.getE08());
				flightParametersDTO.setE60(flightDataEntity.getE60());
				flightParametersDTO.setE61(flightDataEntity.getE61());
				flightParametersDTO.setL01(flightDataEntity.getL01());
				flightParametersDTO.setM61(flightDataEntity.getM61());

				flightParametersList.add(flightParametersDTO);
			}
		} catch (Exception e) {
			System.out.println("Exception in getFlightParameters()");
			e.printStackTrace();
		}
		return flightParametersList;
	}

	@RequestMapping(value = "/view/loadCSVtoDB", method = RequestMethod.GET)
	public @ResponseBody String loadCSVtoDB() {
		String result = "";
		try {

			CSVLoader loader = new CSVLoader(this.getCon());
			loader.loadCSV("D:\\GEGDC\\SM358224\\Tableau\\employee.csv",
					"EMPLOYEE1", true);
			result = "Success";
		} catch (Exception e) {
			result = "Failure";
			System.out.println("Exception in getFlightParameters()");
			e.printStackTrace();

		}
		return result;

	}

	private Connection getCon() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager
					.getConnection(
							"jdbc:oracle:thin:@teld09895-vip.tsg.ge.com:1521:annpod011",
							"datasvrvr", "I37as_5WpXhGEP");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return connection;
	}

	@RequestMapping(value = "/view/loadLogData", method = RequestMethod.GET)
	public @ResponseBody String loadLogData() {
		String result = "";
		try {

			CSVLoader loader = new CSVLoader(this.getCon());
			loader.loadCSV("D:\\GEGDC\\SM358224\\Tableau\\testing.csv",
					"LOG_DATA", true);
			result = "Success";
		} catch (Exception e) {
			result = "Failure";
			System.out.println("Exception in getFlightParameters()");
			e.printStackTrace();

		}
		return result;

	}

	@RequestMapping(value = "/view/getsupplierconnectWithFilter", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<SupplierConnectSearchVO> getsupplierconnectWithFilter(
			@RequestBody @Valid final SupplierConnectTbl supplierconnect) {
		List<SupplierConnectSearchVO> supplierVos = new ArrayList<SupplierConnectSearchVO>();
		SupplierConnectSearchVO connectVo = null;
		try {

			SupplierSearchSpecification supplierSearchSpecification = new SupplierSearchSpecification(
					supplierconnect);
			List<SupplierConnectTbl> demandList = supplierSearchEntityRepository
					.findAll(supplierSearchSpecification);
			for (SupplierConnectTbl supply : demandList) {
				connectVo = new SupplierConnectSearchVO();
				connectVo.setApprovalStatus(supply.getApprovalStatus());
				connectVo.setDueDt(supply.getDueDt());
				connectVo.setId(supply.getId());
				connectVo.setInvoiceAmount(supply.getInvoiceAmount());
				connectVo.setInvoiceNumber(supply.getInvoiceNumber());
				connectVo.setInvoiceSubmitDt(supply.getInvoiceSubmitDt());
				connectVo.setOrganizationName(supply.getOrganizationName());
				connectVo.setOrgId(supply.getOrgId());
				connectVo.setPaymentTerm(supply.getPaymentTerm());
				connectVo.setPoExpiryDt(supply.getPoExpiryDt());
				connectVo.setPoNumber(supply.getPoNumber());
				supplierVos.add(connectVo);
			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getsupplierconnectWithFilter()"
							+ e);
		}
		return supplierVos;

	}

	@RequestMapping(value = "/view/getsupplierconnectWithoutFilter", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SupplierConnectSearchVO> getsupplierconnectWithFilter() {
		List<SupplierConnectSearchVO> supplierVos = new ArrayList<SupplierConnectSearchVO>();
		SupplierConnectSearchVO connectVo = null;
		try {

			// SupplierSearchSpecification supplierSearchSpecification = new
			// SupplierSearchSpecification(supplierconnect);
			List<SupplierConnectTbl> demandList = supplierSearchEntityRepository
					.findAll();
			for (SupplierConnectTbl supply : demandList) {
				connectVo = new SupplierConnectSearchVO();
				connectVo.setApprovalStatus(supply.getApprovalStatus());
				connectVo.setDueDt(supply.getDueDt());
				connectVo.setId(supply.getId());
				connectVo.setInvoiceAmount(supply.getInvoiceAmount());
				connectVo.setInvoiceNumber(supply.getInvoiceNumber());
				connectVo.setInvoiceSubmitDt(supply.getInvoiceSubmitDt());
				connectVo.setOrganizationName(supply.getOrganizationName());
				connectVo.setOrgId(supply.getOrgId());
				connectVo.setPaymentTerm(supply.getPaymentTerm());
				connectVo.setPoExpiryDt(supply.getPoExpiryDt());
				connectVo.setPoNumber(supply.getPoNumber());
				supplierVos.add(connectVo);
			}

		}

		catch (Exception e) {
			System.out
					.println("HospitalAlarmService.getsupplierconnectWithFilter()"
							+ e);
		}
		return supplierVos;

	}

	@RequestMapping(value = "/view/testPostService", method = RequestMethod.POST, produces = "application/text")
	public @ResponseBody String testPostService(@RequestBody String body) {
		String result = null;
		try {
			result = body;
			boolean status = isJSONValid(result);
			if (status) {
				result = "Valid JSON";
			} else {
				result = "Inavalid JSON";
			}

		} catch (Exception e) {
			System.out.println("BookingController.testPostService()" + e);
		}
		return result;

	}

	public boolean isJSONValid(String jsonInString) {
		Gson gson = new Gson();
		try {
			gson.fromJson(jsonInString, Object.class);
			return true;
		} catch (com.google.gson.JsonSyntaxException ex) {
			return false;
		}
	}

	@RequestMapping(value = "/getFlightTimeStampDetails/{startdate}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FlightMasterDTO> getFlightTimeStampDetails(
			@PathVariable("startdate") String startdate) {
		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		try {
			System.out.println("AircraftService.getFlightTimeStampDetails()");

			List<FlightMaster> dataList = (List<FlightMaster>) flightMasterRepo
					.findByStartDate(startdate);
			for (FlightMaster flightMstr : dataList) {
				flightTimeStamp = new FlightMasterDTO();
				BeanUtils.copyProperties(flightMstr, flightTimeStamp);
				// System.out.println("AircraftService.getFlightTimeStampDetails()"+flightMstr);
				// System.out.println("WithOutAfterCopy Result"+flightTimeStamp);
				aircraftLists.add(flightTimeStamp);
			}

		}

		catch (Exception e) {
			e.printStackTrace();

		}
		return aircraftLists;

	}

	/*@RequestMapping(value = "/view/getFlightDetails/{flightDate}/{flightTime}/{recordType}/{triggerChannel}/{startTime}/{endTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightDetails(
			@PathVariable("flightDate") String flightDate,
			@PathVariable("flightTime") String flightTime,
			@PathVariable("recordType") String recordType,
			@PathVariable("triggerChannel") String triggerChannel,
			@PathVariable("startTime") String startTime,
			@PathVariable("endTime") String endTime) {
		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			System.out.println("AircraftService.getFlightTimeStampDetails()");

			String filterQueryMnfctr = "";

			List<Object[]> retList = filghtFleetrepo2.getFlightDetails(
					flightDate, flightTime, recordType, triggerChannel,
					startTime, endTime);

			for (int i = 0; i < retList.size(); i++) {

				objMap = new HashMap<String, Object>();
				objMap.put("fleetId", (retList.get(i))[0]);
				objMap.put("airspeed", (retList.get(i))[1]);
				objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
				objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
				objMap.put("elapsedTime", (retList.get(i))[4]);
				objMap.put("elevatorPosition", (retList.get(i))[5]);
				objMap.put("flapPosition", (retList.get(i))[6]);
				objMap.put("gearUpAndLocked", (retList.get(i))[7]);
				objMap.put("leftAileronPosition", (retList.get(i))[8]);
				objMap.put("peakValleyIndicator", (retList.get(i))[9]);
				objMap.put("pressureAltitude", (retList.get(i))[10]);
				objMap.put("recordType", (retList.get(i))[11]);

				objMap.put("retardantDoorOpen", (retList.get(i))[12]);
				objMap.put("retardantTankFloat", (retList.get(i))[13]);
				objMap.put("rollAcceleration", (retList.get(i))[14]);
				objMap.put("strainGauge1", (retList.get(i))[15]);
				objMap.put("strainGauge2", (retList.get(i))[16]);
				objMap.put("strainGauge3", (retList.get(i))[17]);
				objMap.put("strainGauge4", (retList.get(i))[18]);
				objMap.put("strainGauge5", (retList.get(i))[19]);
				objMap.put("strainGauge6", (retList.get(i))[20]);
				objMap.put("strainGauge7", (retList.get(i))[21]);
				objMap.put("strainGauge8", (retList.get(i))[22]);
				objMap.put("timestamp", (retList.get(i))[23]);
				objMap.put("triggerChannel", (retList.get(i))[24]);
				objMap.put("verticalAcceleration", (retList.get(i))[25]);
				objMap.put("startDate", (retList.get(i))[26]);
				objMap.put("startTime", (retList.get(i))[27]);
				objMap.put("flightId", (retList.get(i))[28]);

				list.add(objMap);

			}

		}

		catch (Exception e) {
			e.printStackTrace();

		}

		return list;
	}*/

	@RequestMapping(value = "/view/getFlightDetailss", method = RequestMethod.GET, produces = "application/json")
	List<Map<String, Object>> getFlightDetails() {
		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			System.out.println("AircraftService.getFlightTimeStampDetails()");

			List<Object[]> retList = filghtFleetrepo2.getFlightDetailss();

			for (int i = 0; i < retList.size(); i++) {

				objMap = new HashMap<String, Object>();
				objMap.put("fleetId", (retList.get(i))[0]);
				objMap.put("airspeed", (retList.get(i))[1]);
				objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
				objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
				objMap.put("elapsedTime", (retList.get(i))[4]);
				objMap.put("elevatorPosition", (retList.get(i))[5]);
				objMap.put("flapPosition", (retList.get(i))[6]);
				objMap.put("gearUpAndLocked", (retList.get(i))[7]);
				objMap.put("leftAileronPosition", (retList.get(i))[8]);
				objMap.put("peakValleyIndicator", (retList.get(i))[9]);
				objMap.put("pressureAltitude", (retList.get(i))[10]);
				objMap.put("recordType", (retList.get(i))[11]);

				objMap.put("retardantDoorOpen", (retList.get(i))[12]);
				objMap.put("retardantTankFloat", (retList.get(i))[13]);
				objMap.put("rollAcceleration", (retList.get(i))[14]);
				objMap.put("strainGauge1", (retList.get(i))[15]);
				objMap.put("strainGauge2", (retList.get(i))[16]);
				objMap.put("strainGauge3", (retList.get(i))[17]);
				objMap.put("strainGauge4", (retList.get(i))[18]);
				objMap.put("strainGauge5", (retList.get(i))[19]);
				objMap.put("strainGauge6", (retList.get(i))[20]);
				objMap.put("strainGauge7", (retList.get(i))[21]);
				objMap.put("strainGauge8", (retList.get(i))[22]);
				objMap.put("timestamp", (retList.get(i))[23]);
				objMap.put("verticalAcceleration", (retList.get(i))[24]);
				objMap.put("startDate", (retList.get(i))[25]);

				objMap.put("startTime", (retList.get(i))[26]);
				objMap.put("flightId", (retList.get(i))[27]);

				list.add(objMap);

			}

		}

		catch (Exception e) {
			e.printStackTrace();

		}
		return list;

	}

	@RequestMapping(value = "/view/getFlightDetailsWithSpec/{flightDate}/{flightTime}/{recordType}/{triggerChannel}/{startTime}/{endTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FlightMasterDTO> getFlightDetailsWithSpec(
			@PathVariable("flightDate") String flightDate,
			@PathVariable("flightTime") String flightTime,
			@PathVariable("recordType") String recordType,
			@PathVariable("triggerChannel") String triggerChannel,
			@PathVariable("startTime") String startTime,
			@PathVariable("endTime") String endTime) {
		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			System.out.println("AircraftService.getFlightTimeStampDetails()");

			String filterQueryMnfctr = "";
			FleetSearchSpecification demandSearchSpecification = new FleetSearchSpecification(
					flightDate, flightTime, recordType, triggerChannel,
					startTime, endTime);

			List<FleetData2> dataList = (List<FleetData2>) filghtFleetrepo2
					.findAll(demandSearchSpecification);

			for (FleetData2 flightMstr : dataList) {
				flightTimeStamp = new FlightMasterDTO();
				BeanUtils.copyProperties(flightMstr, flightTimeStamp);
				// System.out.println("AircraftService.getFlightTimeStampDetails()"+flightMstr);
				// System.out.println("WithOutAfterCopy Result"+flightTimeStamp);
				aircraftLists.add(flightTimeStamp);
			}

		}

		catch (Exception e) {
			e.printStackTrace();

		}

		return aircraftLists;
	}

	// new filter code

/*	@RequestMapping(value = "/view/getFlightDetailsWithDynamicfilter/{flightDate}/{flightTime}/{recordType}/{triggerChannel}/{startTime}/{endTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightDetailsWithDynamicfilter(
			@PathVariable("flightDate") String flightDate,
			@PathVariable("flightTime") String flightTime,
			@PathVariable("recordType") String recordType,
			@PathVariable("triggerChannel") String triggerChannel,
			@PathVariable("startTime") String startTime,
			@PathVariable("endTime") String endTime) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		if (startTime.equalsIgnoreCase("''")) {
			startTime = "";
		}
		if (endTime.equalsIgnoreCase("''")) {
			endTime = "";
		}

		try {
			System.out
					.println("AircraftService.getFlightDetailsWithDynamicfilter()");

			List<Object[]> retList = null;
			Double startElapsedTm = null;
			Double endElapsedTm = null;
			
			if (startTime != null && !startTime.equalsIgnoreCase("") && !startTime.equalsIgnoreCase("''")
					&& endTime != null && !endTime.equalsIgnoreCase("") && !endTime.equalsIgnoreCase("''")) {
				
				startElapsedTm = Double.valueOf(startTime);
				endElapsedTm = Double.valueOf(endTime);
				
			}

			if (null != flightDate && null != flightTime && null != recordType) {
				if (recordType.equalsIgnoreCase("TR")) {

					if (!StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTREndTime(
								flightDate, flightTime, recordType,
								triggerChannel, endTime);
					} else if (!StringUtils.isNotBlank(endTime)
							&& StringUtils.isNotBlank(startTime)) {

						retList = filghtFleetrepo2.getFlDtlsTRStartTime(
								flightDate, flightTime, recordType,
								triggerChannel, startTime);
					} else if (!StringUtils.isNotBlank(startTime)
							&& !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithoutTime(
								flightDate, flightTime, recordType,
								triggerChannel);
					} else if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithBothTime(
								flightDate, flightTime, recordType,
								triggerChannel, startElapsedTm, endElapsedTm);

					}

				} else if (recordType.equalsIgnoreCase("PE")) {

					if (!StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEEndTime(
								flightDate, flightTime, recordType, endTime);
					} else if (!StringUtils.isNotBlank(endTime)
							&& StringUtils.isNotBlank(startTime)) {

						retList = filghtFleetrepo2.getFlDtlsPEStartTime(
								flightDate, flightTime, recordType, startTime);
					} else if (!StringUtils.isNotBlank(startTime)
							&& !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithoutTime(
								flightDate, flightTime, recordType);
					} else if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithTime(
								flightDate, flightTime, recordType, startElapsedTm, endElapsedTm);
					}

				}

				for (int i = 0; i < retList.size(); i++) {

					objMap = new HashMap<String, Object>();
					objMap.put("fleetId", (retList.get(i))[0]);
					objMap.put("airspeed", (retList.get(i))[1]);
					objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
					objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
					objMap.put("elapsedTime", (retList.get(i))[4]);
					objMap.put("elevatorPosition", (retList.get(i))[5]);
					objMap.put("flapPosition", (retList.get(i))[6]);
					objMap.put("gearUpAndLocked", (retList.get(i))[7]);
					objMap.put("leftAileronPosition", (retList.get(i))[8]);
					objMap.put("peakValleyIndicator", (retList.get(i))[9]);
					objMap.put("pressureAltitude", (retList.get(i))[10]);
					objMap.put("recordType", (retList.get(i))[11]);

					objMap.put("retardantDoorOpen", (retList.get(i))[12]);
					objMap.put("retardantTankFloat", (retList.get(i))[13]);
					objMap.put("rollAcceleration", (retList.get(i))[14]);
					objMap.put("strainGauge1", (retList.get(i))[15]);
					objMap.put("strainGauge2", (retList.get(i))[16]);
					objMap.put("strainGauge3", (retList.get(i))[17]);
					objMap.put("strainGauge4", (retList.get(i))[18]);
					objMap.put("strainGauge5", (retList.get(i))[19]);
					objMap.put("strainGauge6", (retList.get(i))[20]);
					objMap.put("strainGauge7", (retList.get(i))[21]);
					objMap.put("strainGauge8", (retList.get(i))[22]);
					objMap.put("timestamp", (retList.get(i))[23]);
					objMap.put("triggerChannel", (retList.get(i))[24]);
					objMap.put("verticalAcceleration", (retList.get(i))[25]);
					objMap.put("startDate", (retList.get(i))[26]);
					objMap.put("startTime", (retList.get(i))[27]);
					objMap.put("flightId", (retList.get(i))[28]);

					list.add(objMap);

				}

			}
		}

		catch (Exception e) {
			e.printStackTrace();

		}

		return list;
	}*/
	
	@RequestMapping(value = "/view/getFlightDetailsWithDynamicfilter/{flightDate}/{flightTime}/{recordType}/{triggerChannel}/{startTime}/{endTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightDetailsWithDynamicfilter(
			@PathVariable("flightDate") String flightDate,
			@PathVariable("flightTime") String flightTime,
			@PathVariable("recordType") String recordType,
			@PathVariable("triggerChannel") String triggerChannel,
			@PathVariable("startTime") String startTime,
			@PathVariable("endTime") String endTime) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		if (startTime.equalsIgnoreCase("''")) {
			startTime = "";
		}
		if (endTime.equalsIgnoreCase("''")) {
			endTime = "";
		}
		

		try {
			System.out
					.println("AircraftService.getFlightDetailsWithDynamicfilter()");

			List<Object[]> retList = null;
			Double startElapsedTm = null;
			Double endElapsedTm = null;
			
			if (startTime != null && !startTime.equalsIgnoreCase("") && !startTime.equalsIgnoreCase("''")
					&& endTime != null && !endTime.equalsIgnoreCase("") && !endTime.equalsIgnoreCase("''")) {
				
				startElapsedTm = Double.valueOf(startTime);
				endElapsedTm = Double.valueOf(endTime);
				
			}
			BigDecimal triggerChannelBD = null;
			
			if (triggerChannel != null && !triggerChannel.equalsIgnoreCase("") && !triggerChannel.equalsIgnoreCase("''")) {
				 
				 triggerChannelBD=new BigDecimal(triggerChannel);
				
			}

			if (null != flightDate && null != flightTime && null != recordType) {
				if (recordType.equalsIgnoreCase("TR")) {

					if (!StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTREndTime(
								flightDate, flightTime, recordType,
								triggerChannelBD, endTime);
					} else if (!StringUtils.isNotBlank(endTime)
							&& StringUtils.isNotBlank(startTime)) {

						retList = filghtFleetrepo2.getFlDtlsTRStartTime(
								flightDate, flightTime, recordType,
								triggerChannelBD, startTime);
					} else if (!StringUtils.isNotBlank(startTime)
							&& !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithoutTime(
								flightDate, flightTime, recordType,
								triggerChannelBD);
					} else if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithBothTime(
								flightDate, flightTime, recordType,
								triggerChannelBD, startElapsedTm, endElapsedTm);

					}

				} else if (recordType.equalsIgnoreCase("PE")) {
					
					System.out
							.println("Inside PE:" + triggerChannel);

					if (!StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEEndTime(
								flightDate, flightTime, recordType, endTime);
					} else if (!StringUtils.isNotBlank(endTime)
							&& StringUtils.isNotBlank(startTime)) {

						retList = filghtFleetrepo2.getFlDtlsPEStartTime(
								flightDate, flightTime, recordType, startTime);
					} else if (!StringUtils.isNotBlank(startTime)
							&& !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithoutTime(
								flightDate, flightTime, recordType);
					} else if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithTime(
								flightDate, flightTime, recordType, startElapsedTm,
								endElapsedTm);
					}

				}else{
					if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsWithBothTime(
								flightDate, flightTime, 
								 startElapsedTm, endElapsedTm);
					}
				}

				for (int i = 0; i < retList.size(); i++) {

					objMap = new HashMap<String, Object>();
					objMap.put("fleetId", (retList.get(i))[0]);
					objMap.put("airspeed", (retList.get(i))[1]);
					objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
					objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
					objMap.put("elapsedTime", (retList.get(i))[4]);
					objMap.put("elevatorPosition", (retList.get(i))[5]);
					objMap.put("flapPosition", (retList.get(i))[6]);
					objMap.put("gearUpAndLocked", (retList.get(i))[7]);
					objMap.put("leftAileronPosition", (retList.get(i))[8]);
					objMap.put("peakValleyIndicator", (retList.get(i))[9]);
					objMap.put("pressureAltitude", (retList.get(i))[10]);
					objMap.put("recordType", (retList.get(i))[11]);

					objMap.put("retardantDoorOpen", (retList.get(i))[12]);
					objMap.put("retardantTankFloat", (retList.get(i))[13]);
					objMap.put("rollAcceleration", (retList.get(i))[14]);
					objMap.put("strainGauge1", (retList.get(i))[15]);
					objMap.put("strainGauge2", (retList.get(i))[16]);
					objMap.put("strainGauge3", (retList.get(i))[17]);
					objMap.put("strainGauge4", (retList.get(i))[18]);
					objMap.put("strainGauge5", (retList.get(i))[19]);
					objMap.put("strainGauge6", (retList.get(i))[20]);
					objMap.put("strainGauge7", (retList.get(i))[21]);
					objMap.put("strainGauge8", (retList.get(i))[22]);
					objMap.put("timestamp", (retList.get(i))[23]);
					objMap.put("triggerChannel", (retList.get(i))[24]);
					objMap.put("verticalAcceleration", (retList.get(i))[25]);
					objMap.put("startDate", (retList.get(i))[26]);
					objMap.put("startTime", (retList.get(i))[27]);
					objMap.put("flightId", (retList.get(i))[28]);

					list.add(objMap);

				}

			}
		}

		catch (Exception e) {
			e.printStackTrace();

		}

		return list;
	}

	// rakesh

	@RequestMapping(value = "/view/getFlightPlottingData/{flightId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FleetData2DTO> getFlightPlottingData(
			@PathVariable("flightId") long flightId) {

		List<FleetData2DTO> FleetData2DtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO FleetData2Dto = null;
		try {
			System.out
					.println("AircraftService.getFlightPlottingData() : start");
			List<FleetData2> FleetData2List = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingData(flightId);
			for (FleetData2 FleetData2 : FleetData2List) {
				FleetData2Dto = new FleetData2DTO();
				BeanUtils.copyProperties(FleetData2, FleetData2Dto);
				FleetData2DtoList.add(FleetData2Dto);
			}
			System.out.println("AircraftService.getFlightPlottingData() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FleetData2DtoList;
	}

	/*@RequestMapping(value = "/view/getFlightPlottingDataElapsedTime/{flightId}/{startElapsedTime}/{endElapsedTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FleetData2DTO> getFlightPlottingDataElapsedTime(
			@PathVariable("flightId") long flightId,
			@PathVariable("startElapsedTime") String startElapsedTime,
			@PathVariable("endElapsedTime") String endElapsedTime) {

		List<FleetData2DTO> FleetData2DtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO FleetData2Dto = null;
		try {
			System.out
					.println("AircraftService.getFlightPlottingDataElapsedTime() : start");

			List<FleetData2> FleetData2List = new ArrayList<FleetData2>();

			if (startElapsedTime != null && startElapsedTime != ""
					&& startElapsedTime != "''" && endElapsedTime != null
					&& endElapsedTime != "" && endElapsedTime != "''") {
				FleetData2List = (List<FleetData2>) filghtFleetrepo2
						.getFlightPlottingDataElapsedTime(flightId,
								startElapsedTime, endElapsedTime);
			} else {
				FleetData2List = (List<FleetData2>) filghtFleetrepo2
						.getFlightPlottingData(flightId);
			}

			for (FleetData2 FleetData2 : FleetData2List) {
				FleetData2Dto = new FleetData2DTO();
				BeanUtils.copyProperties(FleetData2, FleetData2Dto);
				FleetData2Dto.setFlightId(flightId);
				FleetData2DtoList.add(FleetData2Dto);
			}
			System.out
					.println("AircraftService.getFlightPlottingDataElapsedTime() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FleetData2DtoList;
	}*/
	
	@RequestMapping(value = "/view/getFlightPlottingDataElapsedTime/{flightId}/{startElapsedTime}/{endElapsedTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FleetData2DTO> getFlightPlottingDataElapsedTime(
			@PathVariable("flightId") long flightId,
			@PathVariable("startElapsedTime") String startElapsedTime,
			@PathVariable("endElapsedTime") String endElapsedTime) {

		List<FleetData2DTO> fleetData2DtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetData2Dto = null;
		try {
			System.out
					.println("AircraftService.getFlightPlottingDataElapsedTime() : start");

			List<FleetData2> fleetData2List = new ArrayList<FleetData2>();
			
			Double startElapsedTm;
			Double endElapsedTm;
			

			if (startElapsedTime != null && !startElapsedTime.equalsIgnoreCase("") && !startElapsedTime.equalsIgnoreCase("''")
					&& endElapsedTime != null && !endElapsedTime.equalsIgnoreCase("") && !endElapsedTime.equalsIgnoreCase("''")) {
				
				startElapsedTm = Double.valueOf(startElapsedTime);
				endElapsedTm = Double.valueOf(endElapsedTime);
				
				fleetData2List = (List<FleetData2>) filghtFleetrepo2
						.getFlightPlottingDataElapsedTime(flightId,	startElapsedTm, endElapsedTm);
			} else {
				fleetData2List = (List<FleetData2>) filghtFleetrepo2.getFlightPlottingData(flightId);
			}

			for (FleetData2 FleetData2 : fleetData2List) {
				fleetData2Dto = new FleetData2DTO();
				BeanUtils.copyProperties(FleetData2, fleetData2Dto);
				fleetData2Dto.setFlightId(flightId);
				fleetData2DtoList.add(fleetData2Dto);
			}
			System.out
					.println("AircraftService.getFlightPlottingDataElapsedTime() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fleetData2DtoList;
	}
	
	@RequestMapping(value = "/view/getFlightMinMaxElapsedTime/{flightId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Map<String, Object> getFlightMinMaxElapsedTime(
			@PathVariable("flightId") long flightId) {

		
		List<Object[]> retList = null;
		 Map<String, Object> hm = new HashMap<>();
		try {
			System.out
					.println("AircraftService.getFlightPlottingData() : start");
		retList =  filghtFleetrepo2
					.getFlightMinMaxElapsedTime(flightId);
			
			//objMap.put("strainGauge5", (retList.get(i))[19]);
			Object result = null;
			for (int i = 0; i < retList.size(); i++) {
				hm.put("maxElapsedTime", (retList.get(i))[0]);
				hm.put("minElapsedTime", (retList.get(i))[1]);
							
			}
			System.out
					.println("BookingController.getFlightMinMaxElapsedTime() result" + result);
			
			
		
			System.out.println("AircraftService.getFlightPlottingData() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
	}
	
	@RequestMapping(value = "/view/getFlightMinMaxElapsedTimeForStartTime/{startTime}", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody Map<String, Object> getFlightMinMaxElapsedTime(
                  @PathVariable("startTime") String startTime) {

           
           List<Object[]> retList = null;
           Map<String, Object> hm = new HashMap<>();
           try {
                  System.out
                               .println("AircraftService.getFlightPlottingData() : start");
             Long  flightId = null;     
                  
           List<FlightMaster> dataList = (List<FlightMaster>) flightMasterRepo.findByStartTime(startTime);
           for(FlightMaster master : dataList){
        	   if(master.getStartTime().equalsIgnoreCase(startTime)){
        		   flightId = master.getFlightId();
        		   System.out
						.println("flightId is : " + flightId);
        	   }
        	   
           }
                  
           retList =  filghtFleetrepo2
                               .getFlightMinMaxElapsedTime(flightId);
                  
                  //objMap.put("strainGauge5", (retList.get(i))[19]);
                  Object result = null;
                  for (int i = 0; i < retList.size(); i++) {
                	  Double maxTime = (Double) (retList.get(i))[0];
                	  Integer maxInt = maxTime.intValue();
                	  
                	  Double minTime = (Double) (retList.get(i))[1];
                	  Integer minInt = minTime.intValue();
                	  
                	  
                        hm.put("maxElapsedTime", maxInt);
                        hm.put("minElapsedTime", minInt);
                                             
                  }
                  System.out
                               .println("BookingController.getFlightMinMaxElapsedTime() result" + result);
                  
                  
           
                  System.out.println("AircraftService.getFlightPlottingData() : end");
           } catch (Exception e) {
                  e.printStackTrace();
           }
           return hm;
    }
	
	@RequestMapping(value = "/view/getFlightMinMaxElapsedTimeForStartTime/{flightDate}/{startTime}", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody Map<String, Object> getFlightMinMaxElapsedTime(
    		@PathVariable("flightDate") String flightDate, @PathVariable("startTime") String startTime) {

           
           List<Object[]> retList = null;
           Map<String, Object> hm = new HashMap<>();
           try {
                  System.out
                               .println("AircraftService.getFlightMinMaxElapsedTime() : start");
             Long  flightId = null;     
             List<Object[]> retList1 = null;     
             
          
             retList1 = flightMasterRepo.findByStartTimeAndDate(flightDate,startTime);
             Map<String, Object> hm1 = new HashMap<>();
             
             for (int i = 0; i < retList1.size(); i++) {
                   hm1.put("flightId", (retList1.get(i))[0]);
            
             }
             
             flightId = (Long) hm1.get("flightId");
             System.out
					.println("flightId is :" + flightId);
                  
           retList =  filghtFleetrepo2
                               .getFlightMinMaxElapsedTime(flightId);
                  
                  //objMap.put("strainGauge5", (retList.get(i))[19]);
                  Object result = null;
                  for (int i = 0; i < retList.size(); i++) {
                	  Double maxTime = (Double) (retList.get(i))[0];
                	  Integer maxInt = maxTime.intValue();
                	  
                	  Double minTime = (Double) (retList.get(i))[1];
                	  Integer minInt = minTime.intValue();
                	  
                	  
                        hm.put("maxElapsedTime", maxInt);
                        hm.put("minElapsedTime", minInt);
                                             
                  }
                  System.out
                               .println("BookingController.getFlightMinMaxElapsedTime() result" + result);
                  
                  
           
                  System.out.println("AircraftService.getFlightPlottingData() : end");
           } catch (Exception e) {
                  e.printStackTrace();
           }
           return hm;
    }
	
	@RequestMapping(value = "/view/getRegressionDynamicAnalysis/{flightId}/{strainGauge}/{params}", method = RequestMethod.GET)
	public @ResponseBody String getRegressionDynamicAnalysis(
			@PathVariable("flightId") long flightId,@PathVariable("strainGauge") String strainGauge,@PathVariable("params") String params) {

		/*String analyticsInputStr = "{ \"data\": {\"data_set\": {\"verticalAcceleration\": [\"1.0\", \"1.2\",\"1.3\",\"1.1\"],\"airspeed\": [\"54.3\",\"53.8\",\"53.6\",\"53.7\"]}, \"number of clusters\":\"3\",\"method\":\"0\"}}";
		System.out.println("analyticsInputStr is :: " + analyticsInputStr);*/

		System.out.println("AircraftService.getRegressionAnalysis() : start");

		List<FleetData2DTO> fleetDataDtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetDataDto = null;
		String analyticsResult = "";
		
		//airborne - start
		Double takeoffSpeed = 0.0;
		Double takeoffPeriod = 0.0;
		Double takeoffAltiDiff = 0.0;
		Double landingSpeed = 0.0;
		Double landingPeriod = 0.0;
		Double landingAltiDiff = 0.0;
		Double landingMaxAlti = 0.0;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> flightSegmentsDataList = new ArrayList<Map<String, Object>>();

		Double startTakeoffElapsedTime = 0.0;
		Double endTakeoffElapsedTime = 0.0;
		Double startTakeoffPressureAltitude;
		Double endTakeoffPressureAltitude;
		Double startLandingElapsedTime = 0.0;
		Double endLandingElapsedTime = 0.0;
		Double startLandingPressureAltitude;
		Double endLandingPressureAltitude;
		Double airborneFltSegmentDuration;

		List<FleetData2> airborneEntityList = new ArrayList<FleetData2>();
		FleetData2DTO airborneDto = null;
		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();

		List<FleetData2> groundEntityList = new ArrayList<FleetData2>();
		FleetData2DTO groundDto = null;
		List<FleetData2DTO> groundDtoList = new ArrayList<FleetData2DTO>();

		int takeoffEndIndex = 0;
		//airborne - end

		try {
			List<FleetData2> fleetDataList = (List<FleetData2>) filghtFleetrepo2.getFlightPlottingData(flightId);
			for (FleetData2 fleetData : fleetDataList) {
				fleetDataDto = new FleetData2DTO();
				BeanUtils.copyProperties(fleetData, fleetDataDto);
				fleetDataDto.setFlightId(flightId);
				fleetDataDtoList.add(fleetDataDto);
			}			
			//airborne flight data-start			
				int takeofflistSize = fleetDataDtoList.size();

				if (flightId == 101 || flightId == 102) {
					takeoffSpeed = 97.0;
					takeoffPeriod = 20.0;
					takeoffAltiDiff = 200.0;
					landingSpeed = 85.0;
					landingPeriod = 20.0;
					landingAltiDiff = 200.0;
					landingMaxAlti = 1100.0;
				} else {
					takeoffSpeed = 100.0;
					takeoffPeriod = 20.0;
					takeoffAltiDiff = 200.0;
					landingSpeed = 85.0;
					landingPeriod = 20.0;
					landingAltiDiff = 200.0;
				}

				if (flightId == 101 || flightId == 102) {
					outer: for (int i = 0; i < takeofflistSize; i++) {
						if (null != fleetDataDtoList.get(i).getAirspeed()) {
							if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
								startTakeoffElapsedTime = fleetDataDtoList.get(i)
										.getElapsedTime();
								startTakeoffPressureAltitude = fleetDataDtoList
										.get(i).getPressureAltitude();
								i++;

								inner: for (int j = i; j < takeofflistSize; j++) {
									if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
										endTakeoffElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
											continue inner;
										}
										// Airspeed >100 continuously for a period
										// of at least 20 seconds
										endTakeoffPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
											// pressure altitude value has increased
											// by at least 200 feet
											System.out
													.println("flight takeoff data range found--> startTakeoffElapsedTime="
															+ startTakeoffElapsedTime
															+ " : endTakeoffElapsedTime="
															+ endTakeoffElapsedTime);
											takeoffEndIndex = j;
											break outer;
										}
										continue inner;
									}
									continue outer;
								}// end of inner for loop
							}
						}// null check end
					}// end of outer for loop

					int landinglistSize = fleetDataDtoList.size();

					outerlanding: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
						if (null != fleetDataDtoList.get(i).getAirspeed()) {
							if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed
									&& fleetDataDtoList.get(i)
											.getPressureAltitude() < landingMaxAlti) {
								startLandingElapsedTime = fleetDataDtoList.get(i)
										.getElapsedTime();
								startLandingPressureAltitude = fleetDataDtoList
										.get(i).getPressureAltitude();
								i++;

								innerlanding: for (int j = i; j < landinglistSize; j++) {
									if (null != fleetDataDtoList.get(j).getAirspeed()) {
										if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed
												&& fleetDataDtoList.get(j)
														.getPressureAltitude() < landingMaxAlti) {
											endLandingElapsedTime = fleetDataDtoList
													.get(j).getElapsedTime();
											if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
												continue innerlanding;
											}
											// Airspeed <85 continuously for a
											// period of at least 20 seconds
											endLandingPressureAltitude = fleetDataDtoList
													.get(j).getPressureAltitude();
											if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
												// pressure altitude value has
												// changed by at most 200 feet
												System.out
														.println("flight landing data range found--> startLandingElapsedTime="
																+ startLandingElapsedTime
																+ " : endLandingElapsedTime="
																+ endLandingElapsedTime);

												airborneFltSegmentDuration = startLandingElapsedTime
														- startTakeoffElapsedTime;

												objMap = new HashMap<String, Object>();
												objMap.put(
														"startTakeoffElapsedTime",
														startTakeoffElapsedTime);
												objMap.put("endTakeoffElapsedTime",
														endTakeoffElapsedTime);
												objMap.put(
														"startLandingElapsedTime",
														startLandingElapsedTime);
												objMap.put("endLandingElapsedTime",
														endLandingElapsedTime);
												objMap.put(
														"airborneFltSegmentDuration",
														airborneFltSegmentDuration);

												break outerlanding;
											}
											continue innerlanding;
										}
									}
									continue outerlanding;
								}// end of inner for loop
							}
						}// null check end
					}// end of outer for loop
				} else if (flightId == 103) {
					startTakeoffElapsedTime = 709.51;
					startLandingElapsedTime = 3534.69;
					objMap = new HashMap<String, Object>();
					objMap.put("startTakeoffElapsedTime", startTakeoffElapsedTime);
					objMap.put("endTakeoffElapsedTime", 730.61);
					objMap.put("startLandingElapsedTime", startLandingElapsedTime);
					objMap.put("endLandingElapsedTime", 3559.11);
					objMap.put("airborneFltSegmentDuration", 2825.18);
				} else {
					outer1: for (int i = 0; i < takeofflistSize; i++) {
						if (null != fleetDataDtoList.get(i).getAirspeed()) {
							if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
								startTakeoffElapsedTime = fleetDataDtoList.get(i)
										.getElapsedTime();
								startTakeoffPressureAltitude = fleetDataDtoList
										.get(i).getPressureAltitude();
								i++;

								inner1: for (int j = i; j < takeofflistSize; j++) {
									if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
										endTakeoffElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
											continue inner1;
										}
										// Airspeed >100 continuously for a period
										// of at least 20 seconds
										endTakeoffPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
											// pressure altitude value has increased
											// by at least 200 feet
											System.out
													.println("flight takeoff data range found--> startTakeoffElapsedTime="
															+ startTakeoffElapsedTime
															+ " : endTakeoffElapsedTime="
															+ endTakeoffElapsedTime);
											takeoffEndIndex = j;
											break outer1;
										}
										continue inner1;
									}
									continue outer1;
								}// end of inner for loop
							}
						}// null check end
					}// end of outer for loop

					int landinglistSize = fleetDataDtoList.size();

					outerlanding1: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
						if (null != fleetDataDtoList.get(i).getAirspeed()) {
							if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed) {
								startLandingElapsedTime = fleetDataDtoList.get(i)
										.getElapsedTime();
								startLandingPressureAltitude = fleetDataDtoList
										.get(i).getPressureAltitude();
								i++;

								innerlanding1: for (int j = i; j < landinglistSize; j++) {
									if (null != fleetDataDtoList.get(j)
											.getAirspeed()) {
										if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed) {
											endLandingElapsedTime = fleetDataDtoList
													.get(j).getElapsedTime();
											if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
												continue innerlanding1;
											}
											// Airspeed <85 continuously for a
											// period of at least 20 seconds
											endLandingPressureAltitude = fleetDataDtoList
													.get(j).getPressureAltitude();
											if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
												// pressure altitude value has
												// changed by at most 200 feet
												System.out
														.println("flight landing data range found--> startLandingElapsedTime="
																+ startLandingElapsedTime
																+ " : endLandingElapsedTime="
																+ endLandingElapsedTime);

												airborneFltSegmentDuration = startLandingElapsedTime
														- startTakeoffElapsedTime;

												objMap = new HashMap<String, Object>();
												objMap.put(
														"startTakeoffElapsedTime",
														startTakeoffElapsedTime);
												objMap.put("endTakeoffElapsedTime",
														endTakeoffElapsedTime);
												objMap.put(
														"startLandingElapsedTime",
														startLandingElapsedTime);
												objMap.put("endLandingElapsedTime",
														endLandingElapsedTime);
												objMap.put(
														"airborneFltSegmentDuration",
														airborneFltSegmentDuration);

												break outerlanding1;
											}
											continue innerlanding1;
										}
									}
									continue outerlanding1;
								}// end of inner for loop
							}
						}// null check end
					}// end of outer for loop
				}

				List<Object[]> retList = null;
				Double maxElapsedTime = 0.0;

				retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);
				for (int i = 0; i < retList.size(); i++) {
					maxElapsedTime = (Double) retList.get(i)[0];
				}
				System.out.println("maxElapsedTime=" + maxElapsedTime);

				// Airborne Flight Segment Data
				airborneEntityList = (List<FleetData2>) filghtFleetrepo2
						.getFlightPlottingDataElapsedTime(flightId,
								startTakeoffElapsedTime, startLandingElapsedTime);
				for (FleetData2 airborneEntity : airborneEntityList) {
					airborneDto = new FleetData2DTO();
					BeanUtils.copyProperties(airborneEntity, airborneDto);
					airborneDto.setFlightId(flightId);
					airborneDtoList.add(airborneDto);
				}
			//airborne flight data-end			
			
			JSONObject obj = new JSONObject();
			
			List<String> airSpeedDbl = new ArrayList<String>();
			List<String> verticalDbl = new ArrayList<String>();
			
			List<Double> strainGaugeArray = new ArrayList<Double>();
			
			List<Double> airspeedArray = new ArrayList<Double>();
			List<Double> pressureAltitudeArray = new ArrayList<Double>();
			List<Double> rollAccelerationArray = new ArrayList<Double>();
			List<Double> verticalAccelerationArray = new ArrayList<Double>();
			List<String> peakValleyIndicatorArray = new ArrayList<String>();
			List<Double> flapPositionArray = new ArrayList<Double>();
			List<Double> elevatorPositionArray = new ArrayList<Double>();
			List<BigDecimal> retardantDoorOpenArray = new ArrayList<BigDecimal>();
			List<BigDecimal> gearUpAndLockedArray = new ArrayList<BigDecimal>();
								
			List<Double> elapsedArray = new ArrayList<Double>();
			for(int i=0;i<airborneDtoList.size();i++){
				elapsedArray.add(airborneDtoList.get(i).getElapsedTime());
				
				if(strainGauge.equalsIgnoreCase("strainGauge1")){
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge1());
					
				}else if(strainGauge.equalsIgnoreCase("strainGauge3")){
					
						strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge3());
				}else if(strainGauge.equalsIgnoreCase("strainGauge6")){
					
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge6());
					
				}
				else if(strainGauge.equalsIgnoreCase("strainGauge8")){
						
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge8());
					
				}
				
				airspeedArray.add(airborneDtoList.get(i).getAirspeed());
				pressureAltitudeArray.add(airborneDtoList.get(i).getPressureAltitude());
				rollAccelerationArray.add(airborneDtoList.get(i).getRollAcceleration());
				verticalAccelerationArray.add(airborneDtoList.get(i).getVerticalAcceleration());
				peakValleyIndicatorArray.add(airborneDtoList.get(i).getPeakValleyIndicator());
				flapPositionArray.add(airborneDtoList.get(i).getFlapPosition());
				elevatorPositionArray.add(airborneDtoList.get(i).getElevatorPosition());
				retardantDoorOpenArray.add(airborneDtoList.get(i).getRetardantDoorOpen());
				gearUpAndLockedArray.add(airborneDtoList.get(i).getGearUpAndLocked());
			
			}
			
			obj.put("starinGauge",strainGaugeArray);
			 
			if(params.contains("airspeed")){
				 obj.put("airspeed",airspeedArray);
				
			}
			if(params.contains("pressureAltitude")){
				 obj.put("pressureAltitude",pressureAltitudeArray);
			}
			if(params.contains("rollAcceleration")){
				 obj.put("rollAcceleration",rollAccelerationArray);
			}
			if(params.contains("verticalAcceleration")){
				 obj.put("verticalAcceleration",verticalAccelerationArray);
			}
			 if(params.contains("peakValleyIndicator")){
				 obj.put("peakValleyIndicator",peakValleyIndicatorArray);
			}
			if(params.contains("flapPosition")){
				 obj.put("flapPosition",flapPositionArray);
			}
			if(params.contains("elevatorPosition")){
				 obj.put("elevatorPosition",elevatorPositionArray);
			}
			if(params.contains("retardantDoorOpen")){
				 obj.put("retardantDoorOpen",retardantDoorOpenArray);
			}
			 if(params.contains("gearUpAndLocked")){
				 obj.put("gearUpAndLocked",gearUpAndLockedArray);
			}
			String splitArr[] = params.split(",");
		    obj.put("inputParam",splitArr);
			 
			 
			/* StringWriter out = new StringWriter();
		     obj.write(out);
		      
		      String jsonText = out.toString();
		    	String finalJson = jsonText ;
				System.out.println("finalJson is *************:" + finalJson);*/
			

			/*HttpResponse<String> jsonResponse = Unirest
					.post("https://predix-analytics-catalog-release.run.aws-usw02-pr.ice.predix.io/api/v1/catalog/analytics/0b53fdb0-68a2-447c-be16-332d5e667ecb/execution")
					.header("content-type", "application/json")
					.header("authorization",
							"Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiIzMmZiODQ0Mzc5ZGU0ZGJmODZlZTFiOTVhNzY4Y2VlMSIsInN1YiI6ImNsaWVudDEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUudXNlciIsImFuYWx5dGljcy56b25lcy43ZWQ3YTc0My0zMjkyLTQ3ZmEtYWUwMC04MGNiOTQ3ZmMwZTMudXNlciJdLCJjbGllbnRfaWQiOiJjbGllbnQxIiwiY2lkIjoiY2xpZW50MSIsImF6cCI6ImNsaWVudDEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImJjNGQzMWRiIiwiaWF0IjoxNDg5OTkyNjAxLCJleHAiOjE0OTQzMTI2MDAsImlzcyI6Imh0dHBzOi8vZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyIiwiYXVkIjpbInVhYSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUiLCJvcGVuaWQiLCJhbmFseXRpY3Muem9uZXMuN2VkN2E3NDMtMzI5Mi00N2ZhLWFlMDAtODBjYjk0N2ZjMGUzIiwiY2xpZW50MSJdfQ.ECBnSn-Xfe0dWb9PCQj1k9rxLJW0d3eW0FPfFKKgyVlfxgoXh_p8VdmqgNPOzOhTvUrHZmrwUD5jqyicUP-RT85l_6mPZ4dWYrHR6hUzsUWuYK5OL8R9ddjqEWNv2CO9IZspctmes01UZmciOXjCDZQOesTZchPRsUIfccPO41E7Lt3mIcRSTdqwr8AUy-i_6rIplp6Em7EWW87-KIVtLcxYf4sg_ecpEbHrf0tSzegUoG7kkFNuhlvyzGnSu6oO8qs2czKpIrIDzPsTkwhyMRdTaoqRW2IkY59QiGuac3XjIkIvkiTFSe3bXRZviFfV22lLMhxjhKKdAG70pj4K_w")
					.header("predix-zone-id",
							"75b9c70d-9e0e-4b82-b642-b4b3cdc0320e")
					.header("cache-control", "no-cache")
					.body(finalJson).asString();*/
/*
			System.out.println("sm jsonResponse status="
					+ jsonResponse.getStatus());
			System.out.println("sm  jsonResponse result="
					+ jsonResponse.getBody());
			JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			JsonParser parser = new JsonParser();
			JsonObject finalResult = (JsonObject) parser.parse(jsonObject.get("result").toString());*/
			
			/*JsonArray airSpeedArr = 	(JsonArray) finalResult.get("airspeed");
			System.out.println("airSpeedArr="+airSpeedArr);			
			JsonArray vertAccArr = 	(JsonArray) finalResult.get("verticalAcceleration");
			System.out.println("vertAccArr="+vertAccArr);
			JsonArray clusterNoArr = 	(JsonArray) finalResult.get("cluster number");
			System.out.println("clusterNoArr="+clusterNoArr);*/
			
				 String result = "{\"PredictedValue\": [820.249999999977, "
					 		+ "752.1399999999862, 704.7699999999886, 814.3299999999821, "
					 		+ "675.1499999999902], \"tValue\": [0.0, 0.0, 0.0, -0.0, 0.0],"
					 		+ " \"StdError\": [44, 55, 66, 66, 77],"
					 		+ " \"RSquared\": 1.0, \"Coeff\": [1198.4593679844183, 5.758556755376162,"
					 		+ " 1438.174509706936, -0.310710620526665, 961.3957921936526], "
					 		+ "\"pValue\":  [1.6, 3.5, 456, 34, 34]}";
		    	 
//		    	 System.out.println("App.main()" + result);

		    		JSONParser parser = new JSONParser();
		    	 	org.json.simple.JSONObject a = new JSONObject();
		    	 	a = (JSONObject) parser.parse(result);
					
				String PredictedValue = a.get("PredictedValue").toString();
				String RSquared = a.get("RSquared").toString();
				
				JSONArray Coeff = (JSONArray) a.get("Coeff");
				JSONArray StdError = (JSONArray) a.get("StdError");	
				JSONArray pValue = (JSONArray) a.get("pValue");
				JSONArray tValue = (JSONArray) a.get("tValue");
	
				JSONObject resultObj = new JSONObject();
				resultObj.put("PredictedValue", PredictedValue);
				resultObj.put("ActualValue", strainGaugeArray);
				resultObj.put("flightId", flightId);				
				resultObj.put("elapseTime", elapsedArray);
				
				resultObj.put("RSquared", RSquared);
				
				String param = null;
				Double coEff = null;
				Long stdErr = null;
				String pVal = null;
				Double tVal = null;
				
							
				Map<String,String> regressionMap = new HashMap<String,String>();
				List<Map<String,String>> mapList = new ArrayList<Map<String,String>>();
				RegressionCalDTO regressionCalDTO = null;
				List<RegressionCalDTO> dtoList = new ArrayList<RegressionCalDTO>();
				
				for(int i=0;i<splitArr.length;i++){
					regressionMap = new HashMap<String,String>();
					regressionCalDTO = new RegressionCalDTO();
					coEff = (Double) Coeff.get(i);
					param = splitArr[i];
					stdErr = (Long) StdError.get(i);
					pVal = pValue.get(i).toString();
					tVal = (Double) tValue.get(i);
									
					/*regressionCalDTO.setCoeff(coEff.toString());
					regressionCalDTO.setParam(param);
					regressionCalDTO.setpValue(pVal);
					regressionCalDTO.setStdError(stdErr.toString());
					regressionCalDTO.settValue(tVal.toString());*/
					
					regressionMap.put("coEff", coEff.toString());
					regressionMap.put("param", param.toString());
					regressionMap.put("stdErr", stdErr.toString());
					regressionMap.put("pVal", pVal.toString());
					regressionMap.put("tVal", tVal.toString());
					mapList.add(regressionMap);
					
					dtoList.add(regressionCalDTO);
				}
			
				
			System.out.println("json result");
			resultObj.put("mapList", mapList);
			analyticsResult = resultObj.toString();			

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getAnalyticsInput()");
			e.printStackTrace();
		}
		return analyticsResult;

	}
	
	
	


	/*
	 * public static void main(String[] args) { SupplierConnectSearchVO
	 * supplierconnect = new SupplierConnectSearchVO(); Gson gson = new Gson();
	 * System.out.println("BookingController.main()" +
	 * gson.toJson(supplierconnect)); ; }
	 */
}
