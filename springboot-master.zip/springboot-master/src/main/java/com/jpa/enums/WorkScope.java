package com.jpa.enums;

public enum WorkScope {

	HIGH,
	
	LOW,
	
	MEDIUM
}
