package com.jpa.enums;

public enum PartKey {

	
}
