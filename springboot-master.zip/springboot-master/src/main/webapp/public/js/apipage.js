
/**
  * Renders all the widgets on the tab and triggers the datasources that are used by the widgets.
  * Customize your widgets by:
  *  - Overriding or extending widget API methods
  *  - Changing widget settings or options
  */
'use strict';

define(['angular',
        'controllers-module',
        'common/angular/services/directive-binder',
        'widgets/datagrid/datagrid.api'
        ], function(angular, controllers,Datagrid) {  
	
	// Controller definition
			controllers
					.controller(
							"ApiPageCtrl",
							[
									"$scope",
									"$rootScope",
									"$http",
									"$state",
									"directiveBinder",
									function($scope,$rootScope, $http,$state,directiveBinder) {
										
										/*$scope.oTablemodalDashbrd = $('table[data-table-name="dt-array"]').iidsBasicDataGrid({
											useFloater: false, //turn off cell filtering layer
											visibility : 'invisible',
											'isResponsive' : true,
											"bAutoWidth": false,
											"aLengthMenu": [5,10, 20, 50, 100],
											"iDisplayLength": 5,
											"oLanguage": {
												"sSearch": "Search all columns:"
											},
											'aoColumns': [
											              	{
																'sTitle' : 'Username',
																'mDataProp' : 'esn',
																//'sWidth':'70px',
															//	'bSortable': false
															}],
												'fnInitComplete' : function(fnSettings,	json) {
														$("#dt-array").css(	"width", "100%");
												}
										//	'aaData':orderReportsDataiip
											});*/
										
										$scope.availableLimits = [2, 5, 10];
										$scope.limit = 10;
										$scope.queryModel ;
										
										$scope.page = 0;
										$scope.rowsPerPage = 50;
										$scope.itemCount = 0;
										$scope.limitPerPage = 5;
									
										
										$scope.showAPIDtl=function(query,data){
											 											
											console.log("query Name..."+query + "data ..." + data);
											  $rootScope.grpNameDisplay = data.grpName;
											  
											  $rootScope.qryNameDisplay  = query;
										    	//$scope.apiId = data.apiId;
										    	$scope.grpName = data.grpName;
										    	$scope.queryName = query;
										    	var qryName = query;
										    	$scope.queryList = data.queryList;
										    	for (var int2 = 0; int2 < $scope.queryList.length; int2++) {
										    		
										    		$scope.queryNames = $scope.queryList[int2].queryName;
										    		
										    		var qry = $scope.queryNames;
										    		
										    		console.log(qryName);
										    		
										    		if(query.trim()  == qry.trim()){
										    			$scope.queryId = $scope.queryList[int2].queryId;
										    		}
										    		
										    		/*if(qryName == queryName){
										    			$scope.queryId = $scope.queryList[int2].queryId;
										    			
										    		}*/
										    		
										    	}
										    	console.log($scope.queryId);
										    	
										    	
										    	
										    	console.log("Group Name..."+$scope.grpName + "queryName ..." + $scope.queryName);
										    	$http({
													method: "GET",
												/*	 dataType: "json",*/
													url: "/getEngineDetails" + "/" + $scope.queryId
												}).success(function(data){
												 
												$state.go("apiPage");	
												 
												console.log("Details Qry :"+ JSON.stringify(data));
												
												 $rootScope.engineURLs =data;
												 $scope.engineUrl = data;
												 $rootScope.paramInfoDtl = [];
												 $rootScope.info = "";
												 for (var int = 0; int < $scope.engineUrl.length; int++) {
													 $scope.parameterInfoNames = $scope.engineUrl[int].parameterInfoModels;
														console.log(JSON.stringify($scope.parameterInfoNames));
														for (var int3 = 0; int3 < $scope.parameterInfoNames.length; int3++) {
															$rootScope.paramInfoDtl.push($scope.parameterInfoNames[int3].paramInfoDtl);
															$rootScope.info = $rootScope.info + "\n"  + $scope.parameterInfoNames[int3].paramInfoDtl;
															
														}
													 
												 }
												console.log("String ****** "+$rootScope.info);
												$('#servicePanelSecQry').css('display','block');
												//$('#servicePanelSec').css('display','none');
												//$('#servicePanelSec1').css('display','none');
												//$('#servicePanelSecChk').css('display','none');
												$('#tabDiv').css('display','none');
												$('#servicePanelSecQryAll').css('display','block');
												$('#showDtl').css('display','none');
												$('#serviceReq').css('display','block');
												$('#tabDet').css('display','none');
												
												/*$scope.services =[];
												$scope.services=$scope.services1;*/
												
												}).error(function(data){
													console.log("Details Qry :"+ data)	;
													
												});
										    	
										    	//alert("Inside the page");
										    }
										  $scope.showRequest  = function(id,groupName) {
												//alert('Inside Get');
											  	$rootScope.grpNameDisplay = groupName;
												$scope.urlid = id;
												//alert(	$scope.urlid );
													$http({
														method: "GET",
														url: "/getEngineDetails" + "/" + $scope.urlid
													}).success(function(data){
														$rootScope.engineURLs=data;
														console.log("URL :"+ data);
														/*for (var int = 0; int < $scope.engineURLs.length; int++) {
															var  url = $scope.engineURLs[int].url;
															console.log(url);
														}*/
														/*angular.forEach(data, function(key,value) {;
													    }, data);*/
														$state.go("apiPage");	
														$('#serviceReq').css('display','block');
														$('#servicePanelSecQry').css('display','block');
														//$('#servicePanelSec').css('display','none');
														//$('#servicePanelSec1').css('display','none');
														//$('#servicePanelSecChk').css('display','none');
														$('#tabDiv').css('display','none');
														$('#servicePanelSecQryAll').css('display','block');
														$('#showDtl').css('display','none');
														$('#serviceReq').css('display','block');
														$('#tabDet').css('display','none');
												
													}).error(function(data){
													
													});
												}
										  
										  $scope.showDtl  = function(item, event,url,urlKey,parameterMandatory) {
												var id = 'esn' 
													
												//alert(url);
												$('#showDtl').css('display','block');
												$('#showDtlTab').css('display','none');
												$('#showDtlTab1').css('display','none');
												$('#tabDet').css('display','none');
												$('#dynamicDiv').empty();
												for (var int = 0; int < $scope.engineURLs.length; int++) {
													var parameterNames = $scope.engineURLs[int].parameterNames;
													console.log(JSON.stringify(parameterNames));
													$scope.parameterNames =[];
													if(undefined == parameterNames.length){
														$scope.parameterName = JSON.stringify(parameterNames.parameterName);
														
														var param = JSON.stringify(parameterNames.parameterName);
														
														param = param.replace(/"/g, '');
														
														//$('#dynamicDiv').append("<p>"+JSON.stringify(parameterNames.parameterName)+"</p>");
														$('#dynamicDiv').append("<p style='margin-left:5px;'>"+param+"</p>" + "<p style='margin-left:5px;'><input  class='ng-valid ng-dirty' type = 'text'   width= '10px' id='model" + int+	"'" +  "></p>" );
														$scope.parameterNames.push(JSON.stringify(parameterNames.parameterName));
													}else{
														for (var int2 = 0; int2 < parameterNames.length; int2++) {
															var parameterName = parameterNames[int2].parameterName;
															console.log(parameterName);
															$scope.parameterName = parameterName;
															$scope.parameterNames.push(parameterName);
															//$scope.textCnt = int2; 
															$('#dynamicDiv').append("<p style='margin-left:5px;'>"+parameterName+"</p>" + "<p style='margin-left:5px;'><input  class='ng-valid ng-dirty' type = 'text'  width= '10px' id='model" + int2+	"'" +  "></p>" );
															
														}	
													}
												
												}
												$scope.url = url;
												$scope.urlKey = urlKey;
												$scope.parameterMandatory = parameterMandatory;
												console.log($scope.urlKey);
												console.log("Parameter Mandatory : " + $scope.parameterMandatory)
												
											}
										  
										  $scope.getEngineTableDtls = function(item, event) {
												


												//$("#showDtlTab").load(location.href+" #showDtlTab>*","");

												$('#showDtlTab').empty();
												$('#showDtlTab1').empty();
												$('#errorId').empty();
												var jsonKeyVal1 = null ;
												var jsonKeyValTh = [] ;
												var jsonKeyValTd = [] ;
												var jsonArray = null;
												var x = 0;
												var tdData = [];
												var element = null;
												var jsonKeyVal = null; 
												var jsonArrayllpDetailsList=null;
												var jsonArrayShop=null;
												var colWidth = null;
												var errorCode = null;
												var errorMsg = null;
												
												console.log("Parameter Names : " + $scope.parameterNames);
												var idlnth = $("div input[id^='model']").length;
												
												var parameters = [];
												
												var url;
												//$scope.parameters = [];
												for (var i = 0; i < idlnth; i++) {
													//alert($("#model"+i).val()); 
													var val = $("#model"+i).val();
													if(val.indexOf(",")>0){
														var arr = val.split(',');
														console.log(arr);
														parameters.push(arr);
													}else{
														parameters.push($("#model"+i).val());
													}
													//alert($scope.parameterName);
													//$scope.parameters.push($("#esn"+i).val());
													
																	
												}
											//	console.log("Parameters:"+ parameters + "Size of Parameters : " + parameters.length);
												console.log(parameters);
												//alert('Inside the cntrl' + $scope.esn0 + $scope.esn1 + $scope.url) ;
												//alert($scope.url);
												
												if ($scope.parameterMandatory == 'N') {
													url = "/getEngineTableDtlsSingle/"
															+ parameters
															+ '/'
															+ $scope.urlKey
															+ '/'
															+ $scope.parameterNames
															

												}

												else {
													url = "/getEngineTableDtls/"
															+ parameters
															+ '/' + $scope.urlKey
															+ '/'
															+ $scope.parameterNames
														
												}
												
												$http({
													method: "GET",
													/* dataType: "json",*/
													url: url
												}).success(function(data){
													
													// $('#showDtlTab').empty().load();
													//$scope.modalShown = !$scope.modalShown;
													console.log(JSON.stringify(data));
													
													
													$(".checkbox1").prop("checked", false);
													$(".selectAll").prop("checked", false);
													 $scope.modalShown = false;
													 if(""!=data.errorCode && undefined!=data.errorCode){
															$('#showDtlTab').css('display','none');
															$('#showDtlTab1').css('display','none');
															 $('#errorId').css('display','block');
															 $('#tabDet').css('display','none');
															$('#errorId').append("<h3 style='color:red;'>"+  data.errorMsg + ". Please enter valid input"+ "</h3></br>");
															 $scope.modalShown = false;
															 $scope.showDataForSingle = false;
															 $scope.showDataForArray = false;
														}else if(""!=data){
														var keys = [];
														var key=null;
														
														
														for(var k in data){
														keys.push(k);
														}
														for(var count =0; count<keys.length;count++){
															
															if(data[keys[count]] instanceof Object){
																//alert(" keys found");
																key= keys[count];
																$scope.modalShown = true;
																alert($scope.modalShown);
																$scope.finalListForPopup = data[key.toString()];
																console.log("finalList: " + $scope.finalListForPopup);
																$rootScope.orderReportsDataiip = $scope.finalListForPopup;
																$scope.showDataForSingle = false;
																$scope.showDataForArray = true;
																
																//alert("Key is  " + key);
															}else{
																//alert("no keys found");
																$scope.modalShown = !$scope.modalShown;
																$scope.finalListForPopup = data;
																console.log("finalList for no key: " + $scope.finalListForPopup);
																$rootScope.orderReportsDataiip = $scope.finalListForPopup;
																$scope.showDataForSingle = true;
																$scope.showDataForArray = false;
															}
															/*if(keys.length==0){
																alert("no keys found");
																$scope.modalShown = !$scope.modalShown;
																$scope.finalListForPopup = data;
																$rootScope.orderReportsDataiip = $scope.finalListForPopup;
															}*/
															
														}
													
														
														
													}
														else{
														$('#showDtlTab').css('display','none');
														$('#showDtlTab1').css('display','none');
														 $('#errorId').css('display','block');
														 $('#tabDet').css('display','none');
														 $('#errorId').append("<h3 style='color:red;'>"+ "Invalid input please enter the valid data" + "</h3></br>");
														 $scope.modalShown = false;
													}
													
												
												}).error(function(data){
													$('#showDtlTab').css('display','none');
													$('#showDtlTab1').css('display','none');
													 $('#errorId').css('display','block');
													 $('#tabDet').css('display','none');
													 $('#errorId').append("<h3 style='color:red;'>"+ "Invalid input please enter the valid data" + "</h3></br>");
													 $scope.modalShown = false;
													console.log(data)
													
												});
												
											
											}
										   var completeList;
										  function checkColumns(dataList){
											  console.log(dataList);
											  completeList=dataList;
										  }
										 
										 $scope.update=function(){
											 // console.log($rootScope.allList);
											  $('#nav').empty();
											  //$('#apibox').BootSideMenu({side:"left", autoClose:false});
											 // $('#apibox').css({position: "relative",left:"-650px"});
											 
											  $('#apibox').attr('data-status', 'closed');
											  $('#apibox').css({position: "relative"});
											  $('#apibox').animate({
													left:-(650)
											 		
												});
											  $('#tabSec').animate({
													left:-(550)
											 		
												});
											  /*$('#toggle').animate({
													left:-(650)
											 		
												});*/
											  $('#tabSec').css({position: "relative",width:"1000px"});
											  $('#tab').css({position: "relative",width:""});
											  
											 
											 // $('#secDiv').append("<div> <button id='toggle'  onclick = 'changeToggle()' class='voice voice-brand btn btn-primary'>change</button></div>");
									  $('#toggleRight').css('display','block');
									  $('#toggleLeft').css('display','none');
										
											  var finalKeys=[];
											  var finalJson = [];
											  
											  $scope.pageSize = 5;
									 		    $scope.startlimit = 5;
									 		    $scope.endlimit = -5;
											 
											  $scope.range = [];
											  $scope.prevPage = true;
										      	$scope.nextPage = true;
										      	$scope.mainsearch = [];	
										      	
											  $('#errorId1').css('display','none');
											  var alldata=$rootScope.orderReportsDataiip;
											  var objectZero=null;
											  var keepGoing = true;
											  
											  if($.isArray(alldata)){
												  $.each(alldata, function(item, val){
													  if(keepGoing){
														if(item==0){
															  objectZero=val;
															  keepGoing=false;
														  }
													  }
												   });
											  }
											  else if(alldata instanceof Object){
												  objectZero=alldata;
												  keepGoing=false;
												  
											  }
											 
											  	console.log(objectZero);
											    var finalKeys=[];
											  	$.each(objectZero,function(key,value){
											  		if(key!='$$hashKey'){
											  			finalKeys.push(key);
											  		}
											  		
											  	});
											  	
											  	 var checkedfinalKeys=[];
											  	$.each(finalKeys,function(item,val){
											  		if($('#'+val).prop('checked')){
											  			checkedfinalKeys.push(val);
											  		}
											  		
											  	});
											  		
											  	if($.isArray(alldata)){
											  		
											  		angular.forEach(alldata, function(key, val){
														   var JsonData = {};
														   for(var i=0;i<checkedfinalKeys.length;i++){
															   JsonData[checkedfinalKeys[i]] = alldata[val][checkedfinalKeys[i]];
															   console.log(JsonData);
															 }
														   finalJson.push(JsonData);
													   });
											  	}else if(alldata instanceof Object){
											  		
											  		var JsonData = {};
											  		 for(var i=0;i<checkedfinalKeys.length;i++){
												  		 angular.forEach(alldata, function(key, val){
												           if(checkedfinalKeys[i]==val){
													  			 JsonData[val] = key;
												           }
													   console.log(JsonData);
													     });
													 }
											  		 finalJson.push(JsonData);

											  	}
											  	
											  	console.log(JSON.stringify(finalJson));
											  	

											  
											    if(!$(".checkbox1:checked").length > 0 ){
												  //alert ('Please select at least one column');
												  $scope.modalShown = true;
												  $('#errorId1').css('display','block');
										   		 $('#errorId1').append("<h3 style='color:red;font-size:15px;'>"+ "Please select at least one column to display " + "</h3></br>");
											    }else{
												  $scope.modalShown = false;
												  if(undefined!=$rootScope.orderReportsDataiip){
												 $scope.mainsearch.push($rootScope.orderReportsDataiip);
												 
												 
												 if($.isArray($rootScope.orderReportsDataiip)){
													 for (var i = 0; i < Math.ceil($rootScope.orderReportsDataiip.length / 5); i++) {
															$scope.range.push(i);
														}
												 }else if($rootScope.orderReportsDataiip instanceof Object){
													 for (var i = 0; i < Math.ceil(1 / 5); i++) {
															$scope.range.push(i);
														}
												 }
												
													
													if ($scope.range.length > 1) {
														$scope.nextPage = false;
														$scope.prevPage = false;
													}
													 
														$rootScope.allList=$rootScope.orderReportsDataiip;
														
														    $scope.selectedCols=finalJson;
																									
														    $('#tabDet').css('display','block');
														    
														
												 $('#showDtlTab1').css('display','block');
												
											 }
												
												  
											  }
											  
											
										 }	
										 
										
										
										 $scope.currentPagination = function (currentPage){
											 $scope.tab = currentPage;
											 $scope.currentPage = currentPage;
											 $scope.startlimit = $scope.currentPage* $scope.pageSize;
											 $scope.endlimit = -5;
											 if ($scope.currentPage==$scope.range.length){
												 if(undefined!=$rootScope.orderReportsDataiip){
													 if($.isArray($rootScope.orderReportsDataiip)){
														 $scope.endlimit = (($scope.currentPage-1)* $scope.pageSize-$rootScope.orderReportsDataiip.length); 
													 }else if($rootScope.orderReportsDataiip instanceof Object){
														 $scope.endlimit = (($scope.currentPage-1)* $scope.pageSize-1);
													 }
													 
													
												 }/*else if(undefined != $rootScope.currentEngineStatusList){
													 $scope.endlimit = (($scope.currentPage-1)* $scope.pageSize-$rootScope.currentEngineStatusList.length); 
												 } else if(undefined != $rootScope.shopVisitList){
													 $scope.endlimit = (($scope.currentPage-1)* $scope.pageSize-$rootScope.shopVisitList.length);
												 }*/
												// $scope.endlimit = (($scope.currentPage-1)* $scope.pageSize-$rootScope.orderReportsDataiip.length);
											 }
											 if ($scope.range.length > 1 && $scope.currentPage == 1){
												 $scope.nextPage=false;
												 $scope.prevPage=true;
											 } else if ($scope.range.length > 1 && $scope.currentPage == $scope.range.length){
												 $scope.nextPage=true;
												 $scope.prevPage=false;
											 }else if($scope.range.length > 1){
												 $scope.nextPage=false;
												 $scope.prevPage=false;
											 }
										 };
										 
										 $scope.prevPagination = function (currentPage){
											 $scope.tab = currentPage-1;
											 $scope.currentPage=currentPage-1;
											 $scope.currentPagination($scope.currentPage);
										 };
										 $scope.nextPagination = function (currentPage){
											 $scope.tab = currentPage+1;
											 $scope.currentPage=currentPage+1;
											 $scope.currentPagination($scope.currentPage);
										 };
										 
										 
										 $scope.getReusltinTabFormat = function (allList){
											// $rootScope.allList=$rootScope.currentEngineStatusList;
											 $("input:checkbox[name=checkbox]:checked").each(function () {
												  var selectedKey=$(this).attr("id");
												  finalKeys.push(selectedKey);
											  });
											 
											   angular.forEach($rootScope.allList, function(key, val){
												   var JsonData = {};
												   for(var i=0;i<finalKeys.length;i++){
													   JsonData[finalKeys[i]] = $rootScope.allList[val][finalKeys[i]];
													  // console.log(JsonData[finalKeys[i]]);
													   console.log(JsonData);
													 }
												   finalJson.push(JsonData);
											   });
											   
												  console.log(JSON.stringify(finalJson));
											
											    $scope.selectedCols=finalJson;
													
											    $('#tabDet').css('display','block');
											 
										 }
										 
										 $scope.checkAll = function () {
											
									             var checkAll = $("#selectAll").prop('checked');
									                 if (checkAll) {
									                     $(".checkbox1").prop("checked", true);
									                 } else {
									                     $(".checkbox1").prop("checked", false);
									                 }
									  
											 
										    }
										    $scope.check = function (event,item) {
										    
										             if($(".checkbox1").length == $(".checkbox1:checked").length) {
										                 $("#selectAll").prop("checked", true);
										             } else {
										                 $("#selectAll").prop("checked", false);
										             }

										        
										    }
										 
										 
										
										  $scope.getCustomColumns = function(item, event) {
											  $scope.selectedColumns = {};
											  console.log($scope.selectedColumns);
											  
										  }
										  
										  $scope.showNextPage = function (event){
											  $('#nav a').removeClass('active');
									             $(this).addClass('active');
									             var currPage = $(this).attr('rel');
									             var startItem = currPage * rowsShown;
									             var endItem = startItem + rowsShown;
									             $('#dataTab tbody tr').css('opacity','0.0').hide().slice(startItem, endItem).
									                     css('display','table-row').animate({opacity:1}, 300);
										  }
										  
								        // Retrieve datasource instances 
								        //var myDS = VRuntime.services.datasource.get("MyDatasource");             
								        
								        

								        /*  
								         * Override the below properties (widgetOptions,widgetOverwrite,widgetSettings) for custom implementation.
								         */
								        var widgetOptions1 = {
								            /*
								             * any options object to be passed into beforeRender method
								             */
								            beforeRender : {},

								            /*
								             * any options object to be passed into render method
								             * these options are widget-specific, but for example, for a Series or Scatter Chart you can
								             * pass in Highcharts configuration options to add to the default JSON object, such as:
								             * plotOptions: {
								             *     series: {
								             *         cursor: 'pointer',
								             *         point: {
								             *              events: {
								             *                 click: function(event) {
								             *                     console.log("clicked " + this.category);
								             *                 }
								             *             }
								             *         }
								             *     }                                 
								             * }
								             */
								            render: {},

								            /*
								             * any options object to be passed into afterRender method
								             */
								            afterRender: {}
								        };
								        
								        /*
								         * use the following object to alter the widget method implementation
								         */
								      /*  var widgetOverwrite1 = {
								        
								            
								             * method invoked before the render method
								             * this method sets the widget template into the container div of the widget and kicks off knockout data binding
								             * @param {options} - options would like to use for method
								             
								            beforeRender: function(options){
								                //call super class beforeRender method; comment out the following line to overwrite the super class method implementation
								                this._super.call(this,options);
								            },	

								            
								             * method to initialize the 3rd party component and render the 3rd party component into the container div
								             * @param {options} - options would like to use for method
								             
								            render: function(options){
								                //call super class render method; comment out the following line to overwrite super class method implementation
								                this._super.call(this,options);
								            },

								            
								             * method invoked after the widget is rendered on the DOM
								             * this method can be used to setup additional event handlers
								             * e.g. this.$view.on('click', handler); this setup a click handler delegate to the container div of the widget
								             * this.$view is the cached jquery object of the widget container div
								             * @param {options} - options would like to use for method
								             
								            afterRender: function(options){
								                //call super class afterRender method, comment out the following line to overwrite super class method implementation
								                this._super.call(this,options);
								            },

								            
								             * method invoked by the update method which should be used to convert web service data format into widget native format
								             * e.g. transform web service data into highchart series, or into datatables.net format
								             * @param {data} - raw data pass from update method, that need to transform into widget native data format
								             * @return - tranformed data object 
								             
								            _transformData: function(data){
								                //call super class _transformData method, comment out the following line to overwrite super class method implementation
								                return this._super.call(this,data);
								            },

								            
								             * method invoked by the data service to update the widget with new data
								             * @param {data} - raw data passed from external data source
								             
								            update: function(data){
								                //call super class update method, comment out the following line to overwrite super class method implementation
								                this._super.call(this,data);
								            }
								        };
								        
								        
								         * These settings are the properties that were defined in the property editor in Workbench.
								         * If you are hooking the widget up to a datasource, you need to define the datasource in the "global" property, and specify
								         * which fields to map to using $ref, e.g.
								         * {
								         *    "global": {
								         *        "datasource": {
								         *            "name": "line"
								         *         }
								         *     },
								         *     "properties": {
								         *         "chartType": {
								         *             "value": "Horizontal Bar"
								         *         },
								         *         "data": {
								         *            "$ref": "line" // use the "line" key in the datasource
								         *         }
								         *     }
								         * }
								         
								        console.log("Inside"+$scope.CustomerNames);
								        var widgetSettings1 = 
								       // {"global":{"datasource":{"name":"Table"}},"properties":{"tableName":{"$ref":"$rawData"},"showSearchField":{"$ref":"$rawData"},"paginate":{"$ref":"$rawData"},"columnNames":{},"columnKeys":{},"data":{{"$ref":$scope.CustomerNames}}}};	
								        //{"global":{},"datasource":[],"properties":{"columnKeys":{"$ref":"$CustomerNames"},"tableName":{"value":"Data Service Response Details"},"data":{"$ref":"$CustomerNames"},"showSearchField":{"value":"true"},"columnNames":{"value":["Esn","EngineTimeSinceNew","EngineCycleSinceNew","EngineTimeSinceShopVisit","EngineCycleSinceShopVisit","EngineStatusDate"]},"paginate":{"value":"true"}}};
								      {"global":{},"data":[],"properties":{"columnKeys":{"value":["esn","engineTimeSinceNew","engineCycleSinceNew","engineTimeSinceShopVisit","engineCycleSinceShopVisit","engineStatusDate"]},"tableName":{"value":"Data Service Response Details"},"data":{"value":[{"esn":"900339","engineTimeSinceNew":"63108","engineCycleSinceNew":"7467","engineTimeSinceShopVisit":"12936","engineCycleSinceShopVisit":"1435","engineStatusDate":"2014-12-02"},{"esn":"900334","engineTimeSinceNew":"32814","engineCycleSinceNew":"12233","engineTimeSinceShopVisit":"0","engineCycleSinceShopVisit":"0","engineStatusDate":"2014-12-02"}]},"showSearchField":{"value":"true"},"columnNames":{"value":["Esn","EngineTimeSinceNew","EngineCycleSinceNew","EngineTimeSinceShopVisit","EngineCycleSinceShopVisit","EngineStatusDate"]},"paginate":{"value":"true"}}};
								        // Create widget1
								        var widget1 = VRuntime.services.widget.create(Datagrid, "c0ba9e77-f920-49cb-aae6-bb70beac1a9c_", widgetSettings1, widgetOverwrite1);
								        
								        // Render widget1 through life cycle methods
								        VRuntime.services.widget.render(widget1, widgetOptions1, $('#module_1d717792f-0df2-4257-9acd-a11d1b383eda_'));

								        // Connect widget1 to event bus
								        VRuntime.services.binder.bind(widget1);
								        
								        // Cached jquery container div of the widget, events can be delegated to $view
								        var $view1 = widget1.$view;
								        
								        // 3rd party component of the widget (highchart, datatable.net, d3, etc.); 3rd party api can be accessed here
								        var component1 = widget1.getComponent();*/
								        
								        // Fetch data after all widgets are loaded, and bind to datasource or event bus
								        //myDS.trigger("FETCH");
								   
								    
									       
									   

									}]);
			
			
});