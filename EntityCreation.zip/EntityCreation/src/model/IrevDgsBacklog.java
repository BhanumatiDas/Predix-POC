package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the IREV_DGS_BACKLOG database table.
 * 
 */
@Entity
@Table(name="IREV_DGS_BACKLOG")
@NamedQuery(name="IrevDgsBacklog.findAll", query="SELECT i FROM IrevDgsBacklog i")
public class IrevDgsBacklog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="IREV_DGS_BACKLOG_ID_GENERATOR", sequenceName="IREV_BACKLOG")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="IREV_DGS_BACKLOG_ID_GENERATOR")
	private long id;

	private String accountreps;

	private String comments;

	private String construction;

	private String contractcustname;

	private String crd;

	private String creditstatus;

	private String estrevfq;

	private BigDecimal fset;

	private BigDecimal gon;

	private String govtvaso;

	private String h;

	private BigDecimal nevtt;

	private String orderchart;

	private String pmiscomment;

	private String pss;

	private String region;

	private String revrecqtr;

	private String revrecterms;

	@Temporal(TemporalType.DATE)
	private Date rosd;

	private String salesh;

	private String schedules;

	@Temporal(TemporalType.DATE)
	private Date sosd;

	@Column(name="ZONE")
	private String zone;

	public IrevDgsBacklog() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAccountreps() {
		return this.accountreps;
	}

	public void setAccountreps(String accountreps) {
		this.accountreps = accountreps;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getConstruction() {
		return this.construction;
	}

	public void setConstruction(String construction) {
		this.construction = construction;
	}

	public String getContractcustname() {
		return this.contractcustname;
	}

	public void setContractcustname(String contractcustname) {
		this.contractcustname = contractcustname;
	}

	public String getCrd() {
		return this.crd;
	}

	public void setCrd(String crd) {
		this.crd = crd;
	}

	public String getCreditstatus() {
		return this.creditstatus;
	}

	public void setCreditstatus(String creditstatus) {
		this.creditstatus = creditstatus;
	}

	public String getEstrevfq() {
		return this.estrevfq;
	}

	public void setEstrevfq(String estrevfq) {
		this.estrevfq = estrevfq;
	}

	public BigDecimal getFset() {
		return this.fset;
	}

	public void setFset(BigDecimal fset) {
		this.fset = fset;
	}

	public BigDecimal getGon() {
		return this.gon;
	}

	public void setGon(BigDecimal gon) {
		this.gon = gon;
	}

	public String getGovtvaso() {
		return this.govtvaso;
	}

	public void setGovtvaso(String govtvaso) {
		this.govtvaso = govtvaso;
	}

	public String getH() {
		return this.h;
	}

	public void setH(String h) {
		this.h = h;
	}

	public BigDecimal getNevtt() {
		return this.nevtt;
	}

	public void setNevtt(BigDecimal nevtt) {
		this.nevtt = nevtt;
	}

	public String getOrderchart() {
		return this.orderchart;
	}

	public void setOrderchart(String orderchart) {
		this.orderchart = orderchart;
	}

	public String getPmiscomment() {
		return this.pmiscomment;
	}

	public void setPmiscomment(String pmiscomment) {
		this.pmiscomment = pmiscomment;
	}

	public String getPss() {
		return this.pss;
	}

	public void setPss(String pss) {
		this.pss = pss;
	}

	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRevrecqtr() {
		return this.revrecqtr;
	}

	public void setRevrecqtr(String revrecqtr) {
		this.revrecqtr = revrecqtr;
	}

	public String getRevrecterms() {
		return this.revrecterms;
	}

	public void setRevrecterms(String revrecterms) {
		this.revrecterms = revrecterms;
	}

	public Date getRosd() {
		return this.rosd;
	}

	public void setRosd(Date rosd) {
		this.rosd = rosd;
	}

	public String getSalesh() {
		return this.salesh;
	}

	public void setSalesh(String salesh) {
		this.salesh = salesh;
	}

	public String getSchedules() {
		return this.schedules;
	}

	public void setSchedules(String schedules) {
		this.schedules = schedules;
	}

	public Date getSosd() {
		return this.sosd;
	}

	public void setSosd(Date sosd) {
		this.sosd = sosd;
	}

	public String getZone() {
		return this.zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

}