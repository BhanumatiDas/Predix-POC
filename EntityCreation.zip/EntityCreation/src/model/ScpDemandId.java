package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the SCP_DEMAND_ID database table.
 * 
 */
@Entity
@Table(name="SCP_DEMAND_ID")
@NamedQuery(name="ScpDemandId.findAll", query="SELECT s FROM ScpDemandId s")
public class ScpDemandId implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SCP_DEMAND_ID_ID_GENERATOR", sequenceName="SCP_DETAIL")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SCP_DEMAND_ID_ID_GENERATOR")
	private long id;

	@Column(name="DEMAND_ID")
	private String demandId;

	//bi-directional many-to-one association to GetsDemand
	@OneToMany(mappedBy="scpDemandId")
	private List<GetsDemand> getsDemands;

	public ScpDemandId() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDemandId() {
		return this.demandId;
	}

	public void setDemandId(String demandId) {
		this.demandId = demandId;
	}

	public List<GetsDemand> getGetsDemands() {
		return this.getsDemands;
	}

	public void setGetsDemands(List<GetsDemand> getsDemands) {
		this.getsDemands = getsDemands;
	}

	public GetsDemand addGetsDemand(GetsDemand getsDemand) {
		getGetsDemands().add(getsDemand);
		getsDemand.setScpDemandId(this);

		return getsDemand;
	}

	public GetsDemand removeGetsDemand(GetsDemand getsDemand) {
		getGetsDemands().remove(getsDemand);
		getsDemand.setScpDemandId(null);

		return getsDemand;
	}

}