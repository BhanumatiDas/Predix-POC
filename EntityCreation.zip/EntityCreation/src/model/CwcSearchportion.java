package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the CWC_SEARCHPORTION database table.
 * 
 */
@Entity
@Table(name="CWC_SEARCHPORTION")
@NamedQuery(name="CwcSearchportion.findAll", query="SELECT c FROM CwcSearchportion c")
public class CwcSearchportion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long georder;

	private String custitem;

	private String custpo;

	private String geitem;

	private String notification;

	private String operatingunit;

	@Temporal(TemporalType.DATE)
	@Column(name="ORDER_DT")
	private Date orderDt;

	private String ordertype;

	@Temporal(TemporalType.DATE)
	private Date scheduledate;

	private String shiptolocation;

	private String status;

	//bi-directional many-to-one association to CwcChildportion
	@OneToMany(mappedBy="cwcSearchportion")
	private List<CwcChildportion> cwcChildportions;

	public CwcSearchportion() {
	}

	public long getGeorder() {
		return this.georder;
	}

	public void setGeorder(long georder) {
		this.georder = georder;
	}

	public String getCustitem() {
		return this.custitem;
	}

	public void setCustitem(String custitem) {
		this.custitem = custitem;
	}

	public String getCustpo() {
		return this.custpo;
	}

	public void setCustpo(String custpo) {
		this.custpo = custpo;
	}

	public String getGeitem() {
		return this.geitem;
	}

	public void setGeitem(String geitem) {
		this.geitem = geitem;
	}

	public String getNotification() {
		return this.notification;
	}

	public void setNotification(String notification) {
		this.notification = notification;
	}

	public String getOperatingunit() {
		return this.operatingunit;
	}

	public void setOperatingunit(String operatingunit) {
		this.operatingunit = operatingunit;
	}

	public Date getOrderDt() {
		return this.orderDt;
	}

	public void setOrderDt(Date orderDt) {
		this.orderDt = orderDt;
	}

	public String getOrdertype() {
		return this.ordertype;
	}

	public void setOrdertype(String ordertype) {
		this.ordertype = ordertype;
	}

	public Date getScheduledate() {
		return this.scheduledate;
	}

	public void setScheduledate(Date scheduledate) {
		this.scheduledate = scheduledate;
	}

	public String getShiptolocation() {
		return this.shiptolocation;
	}

	public void setShiptolocation(String shiptolocation) {
		this.shiptolocation = shiptolocation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<CwcChildportion> getCwcChildportions() {
		return this.cwcChildportions;
	}

	public void setCwcChildportions(List<CwcChildportion> cwcChildportions) {
		this.cwcChildportions = cwcChildportions;
	}

	public CwcChildportion addCwcChildportion(CwcChildportion cwcChildportion) {
		getCwcChildportions().add(cwcChildportion);
		cwcChildportion.setCwcSearchportion(this);

		return cwcChildportion;
	}

	public CwcChildportion removeCwcChildportion(CwcChildportion cwcChildportion) {
		getCwcChildportions().remove(cwcChildportion);
		cwcChildportion.setCwcSearchportion(null);

		return cwcChildportion;
	}

}