package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the AREA_MASTER_TBL database table.
 * 
 */
@Entity
@Table(name="AREA_MASTER_TBL")
@NamedQuery(name="AreaMasterTbl.findAll", query="SELECT a FROM AreaMasterTbl a")
public class AreaMasterTbl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="AREA_MASTER_TBL_AREAID_GENERATOR", sequenceName="NEW_PARK_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AREA_MASTER_TBL_AREAID_GENERATOR")
	@Column(name="AREA_ID")
	private long areaId;

	@Column(name="AREA_NAME")
	private String areaName;

	private double latitude;

	private double longitude;

	//bi-directional many-to-one association to AreaParkingLocation
	@OneToMany(mappedBy="areaMasterTbl")
	private List<AreaParkingLocation> areaParkingLocations;

	public AreaMasterTbl() {
	}

	public long getAreaId() {
		return this.areaId;
	}

	public void setAreaId(long areaId) {
		this.areaId = areaId;
	}

	public String getAreaName() {
		return this.areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public double getLatitude() {
		return this.latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return this.longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public List<AreaParkingLocation> getAreaParkingLocations() {
		return this.areaParkingLocations;
	}

	public void setAreaParkingLocations(List<AreaParkingLocation> areaParkingLocations) {
		this.areaParkingLocations = areaParkingLocations;
	}

	public AreaParkingLocation addAreaParkingLocation(AreaParkingLocation areaParkingLocation) {
		getAreaParkingLocations().add(areaParkingLocation);
		areaParkingLocation.setAreaMasterTbl(this);

		return areaParkingLocation;
	}

	public AreaParkingLocation removeAreaParkingLocation(AreaParkingLocation areaParkingLocation) {
		getAreaParkingLocations().remove(areaParkingLocation);
		areaParkingLocation.setAreaMasterTbl(null);

		return areaParkingLocation;
	}

}