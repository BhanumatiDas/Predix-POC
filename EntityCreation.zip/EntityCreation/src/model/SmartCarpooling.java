package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the SMART_CARPOOLING database table.
 * 
 */
@Entity
@Table(name="SMART_CARPOOLING")
@NamedQuery(name="SmartCarpooling.findAll", query="SELECT s FROM SmartCarpooling s")
public class SmartCarpooling implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="CAR_NUM")
	private String carNum;

	private String coverage;

	//bi-directional many-to-one association to SmartParkingAggr
	@ManyToOne
	@JoinColumn(name="AREA_ID")
	private SmartParkingAggr smartParkingAggr;

	public SmartCarpooling() {
	}

	public String getCarNum() {
		return this.carNum;
	}

	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}

	public String getCoverage() {
		return this.coverage;
	}

	public void setCoverage(String coverage) {
		this.coverage = coverage;
	}

	public SmartParkingAggr getSmartParkingAggr() {
		return this.smartParkingAggr;
	}

	public void setSmartParkingAggr(SmartParkingAggr smartParkingAggr) {
		this.smartParkingAggr = smartParkingAggr;
	}

}