package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CWC_SEARCHPORTION_POC database table.
 * 
 */
@Entity
@Table(name="CWC_SEARCHPORTION_POC")
@NamedQuery(name="CwcSearchportionPoc.findAll", query="SELECT c FROM CwcSearchportionPoc c")
public class CwcSearchportionPoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CWC_ORDER")
	private long cwcOrder;

	private BigDecimal balancedue;

	private String colshipmentprioritycode;

	private String custitem;

	private String custline;

	private String custpo;

	private BigDecimal deliverynumber;

	private BigDecimal extendedsellingprice;

	@Column(name="GE_ORDER")
	private BigDecimal geOrder;

	private String geitem;

	private BigDecimal geline;

	private String item;

	private String itemdescription;

	@Column(name="OPERATING_UNIT")
	private String operatingUnit;

	@Temporal(TemporalType.DATE)
	@Column(name="ORD_DT")
	private Date ordDt;

	@Column(name="ORD_TYPE")
	private String ordType;

	@Temporal(TemporalType.DATE)
	private Date promisedate;

	private BigDecimal qtycancelled;

	private BigDecimal qtyordered;

	private BigDecimal qtyreserved;

	private String releasedflag;

	@Temporal(TemporalType.DATE)
	private Date requestdate;

	private String shipto;

	private String shiptolocation;

	private String unitvol;

	private String unitwt;

	private String uxpart;

	public CwcSearchportionPoc() {
	}

	public long getCwcOrder() {
		return this.cwcOrder;
	}

	public void setCwcOrder(long cwcOrder) {
		this.cwcOrder = cwcOrder;
	}

	public BigDecimal getBalancedue() {
		return this.balancedue;
	}

	public void setBalancedue(BigDecimal balancedue) {
		this.balancedue = balancedue;
	}

	public String getColshipmentprioritycode() {
		return this.colshipmentprioritycode;
	}

	public void setColshipmentprioritycode(String colshipmentprioritycode) {
		this.colshipmentprioritycode = colshipmentprioritycode;
	}

	public String getCustitem() {
		return this.custitem;
	}

	public void setCustitem(String custitem) {
		this.custitem = custitem;
	}

	public String getCustline() {
		return this.custline;
	}

	public void setCustline(String custline) {
		this.custline = custline;
	}

	public String getCustpo() {
		return this.custpo;
	}

	public void setCustpo(String custpo) {
		this.custpo = custpo;
	}

	public BigDecimal getDeliverynumber() {
		return this.deliverynumber;
	}

	public void setDeliverynumber(BigDecimal deliverynumber) {
		this.deliverynumber = deliverynumber;
	}

	public BigDecimal getExtendedsellingprice() {
		return this.extendedsellingprice;
	}

	public void setExtendedsellingprice(BigDecimal extendedsellingprice) {
		this.extendedsellingprice = extendedsellingprice;
	}

	public BigDecimal getGeOrder() {
		return this.geOrder;
	}

	public void setGeOrder(BigDecimal geOrder) {
		this.geOrder = geOrder;
	}

	public String getGeitem() {
		return this.geitem;
	}

	public void setGeitem(String geitem) {
		this.geitem = geitem;
	}

	public BigDecimal getGeline() {
		return this.geline;
	}

	public void setGeline(BigDecimal geline) {
		this.geline = geline;
	}

	public String getItem() {
		return this.item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItemdescription() {
		return this.itemdescription;
	}

	public void setItemdescription(String itemdescription) {
		this.itemdescription = itemdescription;
	}

	public String getOperatingUnit() {
		return this.operatingUnit;
	}

	public void setOperatingUnit(String operatingUnit) {
		this.operatingUnit = operatingUnit;
	}

	public Date getOrdDt() {
		return this.ordDt;
	}

	public void setOrdDt(Date ordDt) {
		this.ordDt = ordDt;
	}

	public String getOrdType() {
		return this.ordType;
	}

	public void setOrdType(String ordType) {
		this.ordType = ordType;
	}

	public Date getPromisedate() {
		return this.promisedate;
	}

	public void setPromisedate(Date promisedate) {
		this.promisedate = promisedate;
	}

	public BigDecimal getQtycancelled() {
		return this.qtycancelled;
	}

	public void setQtycancelled(BigDecimal qtycancelled) {
		this.qtycancelled = qtycancelled;
	}

	public BigDecimal getQtyordered() {
		return this.qtyordered;
	}

	public void setQtyordered(BigDecimal qtyordered) {
		this.qtyordered = qtyordered;
	}

	public BigDecimal getQtyreserved() {
		return this.qtyreserved;
	}

	public void setQtyreserved(BigDecimal qtyreserved) {
		this.qtyreserved = qtyreserved;
	}

	public String getReleasedflag() {
		return this.releasedflag;
	}

	public void setReleasedflag(String releasedflag) {
		this.releasedflag = releasedflag;
	}

	public Date getRequestdate() {
		return this.requestdate;
	}

	public void setRequestdate(Date requestdate) {
		this.requestdate = requestdate;
	}

	public String getShipto() {
		return this.shipto;
	}

	public void setShipto(String shipto) {
		this.shipto = shipto;
	}

	public String getShiptolocation() {
		return this.shiptolocation;
	}

	public void setShiptolocation(String shiptolocation) {
		this.shiptolocation = shiptolocation;
	}

	public String getUnitvol() {
		return this.unitvol;
	}

	public void setUnitvol(String unitvol) {
		this.unitvol = unitvol;
	}

	public String getUnitwt() {
		return this.unitwt;
	}

	public void setUnitwt(String unitwt) {
		this.unitwt = unitwt;
	}

	public String getUxpart() {
		return this.uxpart;
	}

	public void setUxpart(String uxpart) {
		this.uxpart = uxpart;
	}

}