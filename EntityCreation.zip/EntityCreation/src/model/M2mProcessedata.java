package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the M2M_PROCESSEDATA database table.
 * 
 */
@Entity
@Table(name="M2M_PROCESSEDATA")
@NamedQuery(name="M2mProcessedata.findAll", query="SELECT m FROM M2mProcessedata m")
public class M2mProcessedata implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="M2M_PROCESSEDATA_ID_GENERATOR", sequenceName="TT_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="M2M_PROCESSEDATA_ID_GENERATOR")
	private long id;

	@Column(name="OPERATION_QUALITY")
	private BigDecimal operationQuality;

	//bi-directional many-to-one association to M2mDevice
	@ManyToOne
	@JoinColumn(name="DEVICE_ID")
	private M2mDevice m2mDevice;

	public M2mProcessedata() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getOperationQuality() {
		return this.operationQuality;
	}

	public void setOperationQuality(BigDecimal operationQuality) {
		this.operationQuality = operationQuality;
	}

	public M2mDevice getM2mDevice() {
		return this.m2mDevice;
	}

	public void setM2mDevice(M2mDevice m2mDevice) {
		this.m2mDevice = m2mDevice;
	}

}