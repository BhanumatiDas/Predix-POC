package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the FLIGHT_MASTER database table.
 * 
 */
@Entity
@Table(name="FLIGHT_MASTER")
@NamedQuery(name="FlightMaster.findAll", query="SELECT f FROM FlightMaster f")
public class FlightMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="FLIGHT_MASTER_FLIGHTID_GENERATOR", sequenceName="FLEET_SEQ1")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="FLIGHT_MASTER_FLIGHTID_GENERATOR")
	@Column(name="FLIGHT_ID")
	private long flightId;

	@Column(name="START_DATE")
	private String startDate;

	@Column(name="START_TIME")
	private String startTime;

	//bi-directional many-to-one association to FleetData2
	@OneToMany(mappedBy="flightMaster")
	private List<FleetData2> fleetData2s;

	public FlightMaster() {
	}

	public long getFlightId() {
		return this.flightId;
	}

	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}

	public String getStartDate() {
		return this.startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStartTime() {
		return this.startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public List<FleetData2> getFleetData2s() {
		return this.fleetData2s;
	}

	public void setFleetData2s(List<FleetData2> fleetData2s) {
		this.fleetData2s = fleetData2s;
	}

	public FleetData2 addFleetData2(FleetData2 fleetData2) {
		getFleetData2s().add(fleetData2);
		fleetData2.setFlightMaster(this);

		return fleetData2;
	}

	public FleetData2 removeFleetData2(FleetData2 fleetData2) {
		getFleetData2s().remove(fleetData2);
		fleetData2.setFlightMaster(null);

		return fleetData2;
	}

}