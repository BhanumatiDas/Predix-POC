package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the PARKING_EVENT database table.
 * 
 */
@Entity
@Table(name="PARKING_EVENT")
@NamedQuery(name="ParkingEvent.findAll", query="SELECT p FROM ParkingEvent p")
public class ParkingEvent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.DATE)
	@Column(name="EVENT_DT")
	private Date eventDt;

	@Column(name="EVENT_NAME")
	private String eventName;

	//bi-directional many-to-one association to SmartParkingAggr
	@ManyToOne
	@JoinColumn(name="AREA_ID")
	private SmartParkingAggr smartParkingAggr;

	public ParkingEvent() {
	}

	public Date getEventDt() {
		return this.eventDt;
	}

	public void setEventDt(Date eventDt) {
		this.eventDt = eventDt;
	}

	public String getEventName() {
		return this.eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public SmartParkingAggr getSmartParkingAggr() {
		return this.smartParkingAggr;
	}

	public void setSmartParkingAggr(SmartParkingAggr smartParkingAggr) {
		this.smartParkingAggr = smartParkingAggr;
	}

}