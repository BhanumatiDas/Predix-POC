package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CWC_CHILDPORTION database table.
 * 
 */
@Entity
@Table(name="CWC_CHILDPORTION")
@NamedQuery(name="CwcChildportion.findAll", query="SELECT c FROM CwcChildportion c")
public class CwcChildportion implements Serializable {
	private static final long serialVersionUID = 1L;

	private BigDecimal balancedue;

	private String custitem;

	private String custline;

	private String custpo;

	private BigDecimal geline;

	private String item;

	private String itemdescription;

	private String notification;

	private String operatingunit;

	@Temporal(TemporalType.DATE)
	private Date orderdt;

	private String ordertype;

	@Temporal(TemporalType.DATE)
	private Date promisedate;

	private BigDecimal qtycancelled;

	private BigDecimal qtyordered;

	private BigDecimal qtyreserved;

	private String releasedflag;

	@Temporal(TemporalType.DATE)
	private Date requestdate;

	@Temporal(TemporalType.DATE)
	private Date scheduledate;

	private String shipmentprioritycode;

	private String shipto;

	private String status;

	private String unitwt;

	private String uxpart;

	//bi-directional many-to-one association to CwcSearchportion
	@ManyToOne
	@JoinColumn(name="GEORDER")
	private CwcSearchportion cwcSearchportion;

	public CwcChildportion() {
	}

	public BigDecimal getBalancedue() {
		return this.balancedue;
	}

	public void setBalancedue(BigDecimal balancedue) {
		this.balancedue = balancedue;
	}

	public String getCustitem() {
		return this.custitem;
	}

	public void setCustitem(String custitem) {
		this.custitem = custitem;
	}

	public String getCustline() {
		return this.custline;
	}

	public void setCustline(String custline) {
		this.custline = custline;
	}

	public String getCustpo() {
		return this.custpo;
	}

	public void setCustpo(String custpo) {
		this.custpo = custpo;
	}

	public BigDecimal getGeline() {
		return this.geline;
	}

	public void setGeline(BigDecimal geline) {
		this.geline = geline;
	}

	public String getItem() {
		return this.item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItemdescription() {
		return this.itemdescription;
	}

	public void setItemdescription(String itemdescription) {
		this.itemdescription = itemdescription;
	}

	public String getNotification() {
		return this.notification;
	}

	public void setNotification(String notification) {
		this.notification = notification;
	}

	public String getOperatingunit() {
		return this.operatingunit;
	}

	public void setOperatingunit(String operatingunit) {
		this.operatingunit = operatingunit;
	}

	public Date getOrderdt() {
		return this.orderdt;
	}

	public void setOrderdt(Date orderdt) {
		this.orderdt = orderdt;
	}

	public String getOrdertype() {
		return this.ordertype;
	}

	public void setOrdertype(String ordertype) {
		this.ordertype = ordertype;
	}

	public Date getPromisedate() {
		return this.promisedate;
	}

	public void setPromisedate(Date promisedate) {
		this.promisedate = promisedate;
	}

	public BigDecimal getQtycancelled() {
		return this.qtycancelled;
	}

	public void setQtycancelled(BigDecimal qtycancelled) {
		this.qtycancelled = qtycancelled;
	}

	public BigDecimal getQtyordered() {
		return this.qtyordered;
	}

	public void setQtyordered(BigDecimal qtyordered) {
		this.qtyordered = qtyordered;
	}

	public BigDecimal getQtyreserved() {
		return this.qtyreserved;
	}

	public void setQtyreserved(BigDecimal qtyreserved) {
		this.qtyreserved = qtyreserved;
	}

	public String getReleasedflag() {
		return this.releasedflag;
	}

	public void setReleasedflag(String releasedflag) {
		this.releasedflag = releasedflag;
	}

	public Date getRequestdate() {
		return this.requestdate;
	}

	public void setRequestdate(Date requestdate) {
		this.requestdate = requestdate;
	}

	public Date getScheduledate() {
		return this.scheduledate;
	}

	public void setScheduledate(Date scheduledate) {
		this.scheduledate = scheduledate;
	}

	public String getShipmentprioritycode() {
		return this.shipmentprioritycode;
	}

	public void setShipmentprioritycode(String shipmentprioritycode) {
		this.shipmentprioritycode = shipmentprioritycode;
	}

	public String getShipto() {
		return this.shipto;
	}

	public void setShipto(String shipto) {
		this.shipto = shipto;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUnitwt() {
		return this.unitwt;
	}

	public void setUnitwt(String unitwt) {
		this.unitwt = unitwt;
	}

	public String getUxpart() {
		return this.uxpart;
	}

	public void setUxpart(String uxpart) {
		this.uxpart = uxpart;
	}

	public CwcSearchportion getCwcSearchportion() {
		return this.cwcSearchportion;
	}

	public void setCwcSearchportion(CwcSearchportion cwcSearchportion) {
		this.cwcSearchportion = cwcSearchportion;
	}

}