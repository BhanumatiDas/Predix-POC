package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SUPPLIER_CONNECT_PAYMENTS database table.
 * 
 */
@Entity
@Table(name="SUPPLIER_CONNECT_PAYMENTS")
@NamedQuery(name="SupplierConnectPayment.findAll", query="SELECT s FROM SupplierConnectPayment s")
public class SupplierConnectPayment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SUPPLIER_CONNECT_PAYMENTS_PAYMENTNUMBER_GENERATOR", sequenceName="SUPP_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SUPPLIER_CONNECT_PAYMENTS_PAYMENTNUMBER_GENERATOR")
	@Column(name="PAYMENT_NUMBER")
	private String paymentNumber;

	private BigDecimal amount;

	@Column(name="BANK_ACCOUNT")
	private String bankAccount;

	private String currency;

	@Column(name="INVOICE_NUMBER")
	private String invoiceNumber;

	@Column(name="METHOD_OF_PAYMENT")
	private String methodOfPayment;

	@Temporal(TemporalType.DATE)
	@Column(name="PAYMENT_DATE")
	private Date paymentDate;

	@Column(name="PO_NUMBER")
	private String poNumber;

	@Column(name="REMIT_TO_SUPPLIER")
	private String remitToSupplier;

	@Column(name="REMIT_TO_SUPPLIER_SITE")
	private String remitToSupplierSite;

	private String status;

	@Temporal(TemporalType.DATE)
	@Column(name="STATUS_DATE")
	private Date statusDate;

	public SupplierConnectPayment() {
	}

	public String getPaymentNumber() {
		return this.paymentNumber;
	}

	public void setPaymentNumber(String paymentNumber) {
		this.paymentNumber = paymentNumber;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getBankAccount() {
		return this.bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getInvoiceNumber() {
		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getMethodOfPayment() {
		return this.methodOfPayment;
	}

	public void setMethodOfPayment(String methodOfPayment) {
		this.methodOfPayment = methodOfPayment;
	}

	public Date getPaymentDate() {
		return this.paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPoNumber() {
		return this.poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getRemitToSupplier() {
		return this.remitToSupplier;
	}

	public void setRemitToSupplier(String remitToSupplier) {
		this.remitToSupplier = remitToSupplier;
	}

	public String getRemitToSupplierSite() {
		return this.remitToSupplierSite;
	}

	public void setRemitToSupplierSite(String remitToSupplierSite) {
		this.remitToSupplierSite = remitToSupplierSite;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getStatusDate() {
		return this.statusDate;
	}

	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

}