package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the SCP_USER database table.
 * 
 */
@Entity
@Table(name="SCP_USER")
@NamedQuery(name="ScpUser.findAll", query="SELECT s FROM ScpUser s")
public class ScpUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SCP_USER_ID_GENERATOR", sequenceName="SCP_DETAIL")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SCP_USER_ID_GENERATOR")
	private long id;

	private String password;

	private String username;

	//bi-directional many-to-one association to ScpUserRole
	@ManyToOne
	@JoinColumn(name="ROLE_ID")
	private ScpUserRole scpUserRole;

	public ScpUser() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public ScpUserRole getScpUserRole() {
		return this.scpUserRole;
	}

	public void setScpUserRole(ScpUserRole scpUserRole) {
		this.scpUserRole = scpUserRole;
	}

}