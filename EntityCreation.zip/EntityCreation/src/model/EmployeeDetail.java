package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the EMPLOYEE_DETAILS database table.
 * 
 */
@Entity
@Table(name="EMPLOYEE_DETAILS")
@NamedQuery(name="EmployeeDetail.findAll", query="SELECT e FROM EmployeeDetail e")
public class EmployeeDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="EMPLOYEE_DETAILS_ID_GENERATOR", sequenceName="EMP_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="EMPLOYEE_DETAILS_ID_GENERATOR")
	private long id;

	private String details;

	@Column(name="FILE_PATH")
	private String filePath;

	private String gender;

	@Column(name="MAIL_ID")
	private String mailId;

	private String name;

	@Column(name="PHONE_NUM")
	private BigDecimal phoneNum;

	public EmployeeDetail() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDetails() {
		return this.details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getFilePath() {
		return this.filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMailId() {
		return this.mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getPhoneNum() {
		return this.phoneNum;
	}

	public void setPhoneNum(BigDecimal phoneNum) {
		this.phoneNum = phoneNum;
	}

}